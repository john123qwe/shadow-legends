extends CanvasLayer
class_name TouchControls
## Landscape multi-touch controls: left virtual joystick, right action buttons
## (Jump / Attack / Dash / Special). Adjustable size from settings.
## Keyboard also works for desktop testing (actions mapped in project.godot).

var btn_tex := {}
var scale_mul := 1.0
var _sticks := {}          # touch index -> data {base_pos, knob_pos}
var _base: Control
var _knob: Control
var _held_actions := {}    # action -> touch index
var _queue_press := {}     # action -> true (one-frame edge)
var _root: Control
var _joy_center := Vector2.ZERO
var _joy_radius := 120.0


func _ready() -> void:
	add_to_group("touch_controls")
	layer = 10
	scale_mul = float(SaveSystem.get_setting("button_scale", 1.0))
	for n in ["jump", "attack", "dash", "special", "pause"]:
		btn_tex[n] = load("res://assets/ui/rbtn_%s.png" % n)

	_root = Control.new()
	_root.set_anchors_preset(Control.PRESET_FULL_RECT)
	_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_root)

	_build_joystick()
	_build_buttons()


func _build_joystick() -> void:
	_base = Control.new()
	_base.custom_minimum_size = Vector2.ONE * 240 * scale_mul
	_base.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_base.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
	_base.position = Vector2(70, -320 * scale_mul)
	_base.modulate.a = 0.75
	_root.add_child(_base)

	var ring := TextureRect.new()
	ring.texture = load("res://assets/ui/rbtn_dash.png")  # ring look via round button tex
	ring.modulate = Color(0.4, 0.9, 0.9, 0.35)
	ring.custom_minimum_size = Vector2.ONE * 240 * scale_mul
	ring.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	ring.stretch_mode = TextureRect.STRETCH_SCALE
	ring.size = Vector2.ONE * 240 * scale_mul
	_base.add_child(ring)

	_knob = Control.new()
	_knob.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var kimg := TextureRect.new()
	kimg.texture = load("res://assets/ui/icon_coin.png")
	kimg.modulate = Color(0.5, 0.9, 0.9, 0.55)
	kimg.custom_minimum_size = Vector2.ONE * 96 * scale_mul
	kimg.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	kimg.stretch_mode = TextureRect.STRETCH_SCALE
	kimg.size = Vector2.ONE * 96 * scale_mul
	kimg.position = Vector2.ONE * (240 * scale_mul - 96 * scale_mul) / 2.0
	_knob.add_child(kimg)
	_base.add_child(_knob)
	_joy_center = _base.position + Vector2.ONE * 120 * scale_mul
	_joy_radius = 96.0 * scale_mul


func _build_buttons() -> void:
	# Layout (right-bottom corner), landscape-friendly.
	var defs := [
		["attack", Vector2(-250, -170), 180],
		["jump", Vector2(-420, -120), 150],
		["dash", Vector2(-330, -330), 120],
		["special", Vector2(-160, -350), 120],
	]
	for d in defs:
		var b := TextureButton.new()
		b.texture_normal = btn_tex[d[0]]
		b.ignore_texture_size = true
		b.stretch_mode = TextureButton.STRETCH_SCALE
		var sz: float = d[2] * scale_mul
		b.size = Vector2(sz, sz)
		b.position = d[1] * scale_mul + Vector2(get_viewport().get_visible_rect().size.x, 0)
		b.modulate.a = 0.85
		b.pressed.connect(func(): _queue_press[d[0]] = true)
		b.button_down.connect(func(): _held_actions[d[0]] = true)
		b.button_up.connect(func(): _held_actions[d[0]] = false)
		b.name = d[0].capitalize()
		_root.add_child(b)
		_anchor_right(b, d[1], Vector2(sz, sz))

	var pause_b := TextureButton.new()
	pause_b.texture_normal = btn_tex["pause"]
	pause_b.ignore_texture_size = true
	pause_b.stretch_mode = TextureButton.STRETCH_SCALE
	pause_b.size = Vector2(56, 56)
	pause_b.modulate.a = 0.7
	pause_b.pressed.connect(func(): _queue_press["pause"] = true)
	_root.add_child(pause_b)
	pause_b.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	pause_b.position = Vector2(get_viewport().get_visible_rect().size.x - 76, 20)
	_anchor_right(pause_b, Vector2(-76, 20), Vector2(56, 56))


func _anchor_right(c: Control, off: Vector2, size_v: Vector2) -> void:
	# Right-anchored positioning that follows viewport size on resize.
	c.set_anchors_preset(Control.PRESET_TOP_LEFT)
	c.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	c.grow_vertical = Control.GROW_DIRECTION_END
	var vp := get_viewport().get_visible_rect().size
	c.position = vp + off * scale_mul
	c.set_meta("off", off)
	c.set_meta("size_v", size_v)


func _process(_delta: float) -> void:
	var vp := get_viewport().get_visible_rect().size
	# viewport-relative joystick placement (bottom-left)
	_base.position = Vector2(70, vp.y - 320.0 * scale_mul)
	_joy_center = _base.position + Vector2.ONE * 120 * scale_mul
	# reposition right-anchored buttons if viewport changed
	for c in _root.get_children():
		if c.has_meta("off"):
			var off: Vector2 = c.get_meta("off")
			c.position = Vector2(vp.x + off.x * scale_mul, vp.y + off.y * scale_mul)
	# knob visuals follow active stick
	if _sticks.is_empty():
		_knob.position = Vector2.ONE * (240 * scale_mul - 96 * scale_mul) / 2.0
	else:
		var d: Vector2 = _sticks.values()[0]["offset"]
		_knob.position = Vector2.ONE * (240 * scale_mul - 96 * scale_mul) / 2.0 + d.limit_length(_joy_radius)


# ----------------------------------------------------------------------------
# Multi-touch joystick: any touch starting on the left third controls movement.
# ----------------------------------------------------------------------------
func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed:
			if event.position.x < get_viewport().get_visible_rect().size.x * 0.38:
				_sticks[event.index] = {"origin": event.position, "offset": Vector2.ZERO}
		else:
			_sticks.erase(event.index)
	elif event is InputEventScreenDrag and _sticks.has(event.index):
		var off: Vector2 = event.position - _sticks[event.index]["origin"]
		_sticks[event.index]["offset"] = off


func axis() -> float:
	if _sticks.is_empty():
		return 0.0
	var off: Vector2 = _sticks.values()[0]["offset"]
	return clampf(off.x / _joy_radius, -1.0, 1.0)


func consume_press(action: String) -> bool:
	if _queue_press.get(action, false):
		_queue_press[action] = false
		return true
	return false


func is_held(action: String) -> bool:
	return _held_actions.get(action, false)


func consume_pause() -> bool:
	return consume_press("pause")
