extends EnemyBase
class_name AbyssMage
## Floating caster: hovers, teleports away when cornered, slow homing orbs.
## No gravity — overrides physics integration.


func _ready() -> void:
	anim_attack = "cast"
	gravity = 0.0
	super._ready()
	# hover bob
	var tw := create_tween().set_loops()
	tw.tween_property(sprite, "position:y", _sprite_offset().y - 12, 1.4).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	tw.tween_property(sprite, "position:y", _sprite_offset().y + 6, 1.4).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)


func _body_size() -> Vector2:
	return Vector2(50, 92)


func _windup_time() -> float:
	return 0.7


func _apply_gravity(_delta: float) -> void:
	pass


func ai_chase(delta: float) -> void:
	# float toward a hover point near the player, keep some distance
	var want := player.global_position + Vector2(-facing * 300.0, -120.0)
	var d := want - global_position
	velocity = velocity.lerp(d.normalized() * speed, 3.0 * delta)
	# teleport away if player is very close
	if global_position.distance_to(player.global_position) < 170.0 and st == ST.CHASE:
		_teleport()


func _teleport() -> void:
	Vfx.shadow_puff(get_parent(), global_position)
	var candidates := [player.global_position + Vector2(-420, -160), player.global_position + Vector2(420, -160),
					   player.global_position + Vector2(-260, -260)]
	var dst: Vector2 = candidates[randi() % candidates.size()]
	# place on some free space — simple upward-safe fallback
	global_position = dst
	velocity = Vector2.ZERO
	Vfx.shadow_puff(get_parent(), global_position)
	AudioManager.sfx("ui_open", -8.0)


func _perform_attack() -> void:
	var from := global_position + Vector2(facing * 30, -60)
	Projectile.spawn(get_parent(), from,
		player.global_position + Vector2(0, -50) - from, damage, "orb", player)
	recover_t = 1.3
	st = ST.RECOVER
