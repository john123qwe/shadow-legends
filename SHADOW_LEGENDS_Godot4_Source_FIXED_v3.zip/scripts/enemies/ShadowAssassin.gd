extends EnemyBase
class_name ShadowAssassin
## Elusive duelist: telegraphed dash-through slash.


var _dashing := false


func _ready() -> void:
	anim_move = "run"
	super._ready()
	attack_area.get_child(0).shape.size = Vector2(110, 90)
	attack_area.get_child(0).position = Vector2(56, -48)


func _body_size() -> Vector2:
	return Vector2(46, 92)


func _windup_time() -> float:
	return 0.45


func ai_chase(delta: float) -> void:
	var dx := player.global_position.x - global_position.x
	velocity.x = move_toward(velocity.x, signf(dx) * speed, 1300.0 * delta)


func _perform_attack() -> void:
	# dash through the player position, damaging along the way
	_dashing = true
	var dir := signf(player.global_position.x - global_position.x)
	dir = dir if dir != 0.0 else float(facing)
	velocity = Vector2(dir * 880.0, -80.0)
	attack_area.set_deferred("monitoring", true)
	var hit_players := {}
	for i in range(16):
		await get_tree().create_timer(0.02).timeout
		if st == ST.DEAD or not is_instance_valid(self):
			return
		for body in attack_area.get_overlapping_bodies():
			if body is Player and not hit_players.has(body):
				hit_players[body] = true
				body.take_damage(damage, Vector2(dir * 300.0, -140.0))
	_dashing = false
	attack_area.set_deferred("monitoring", false)
	recover_t = 0.7
	st = ST.RECOVER


func _do_attack(delta: float) -> void:
	# keep dashing velocity; skip gravity while dashing
	if not _dashing:
		_apply_gravity(delta)
