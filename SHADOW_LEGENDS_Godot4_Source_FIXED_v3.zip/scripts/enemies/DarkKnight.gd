extends EnemyBase
class_name DarkKnight
## Slow armored tank: heavy overhead slam with small shockwave.


func _ready() -> void:
	anim_move = "walk"
	super._ready()
	attack_area.get_child(0).shape.size = Vector2(150, 110)
	attack_area.get_child(0).position = Vector2(84, -50)


func _body_size() -> Vector2:
	return Vector2(58, 100)


func _sprite_scale() -> Vector2:
	return Vector2(1.0, 1.0)


func _windup_time() -> float:
	return 0.55


func _perform_attack() -> void:
	attack_area.set_deferred("monitoring", true)
	var t := get_tree().create_timer(0.22)
	t.timeout.connect(func():
		if st == ST.DEAD:
			return
		for body in attack_area.get_overlapping_bodies():
			if body is Player:
				body.take_damage(damage, Vector2(facing * 300.0, -200.0))
		Vfx.shockwave(get_parent(), global_position + Vector2(facing * 40, -10))
		Vfx.dust(get_parent(), global_position)
		EventBus.screen_shake_requested.emit(5.0)
		AudioManager.sfx("boss_slam", -10.0)
		attack_area.set_deferred("monitoring", false)
		recover_t = 0.6
		st = ST.RECOVER)
