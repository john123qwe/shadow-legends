extends EnemyBase
class_name ShadowWolf
## Fast quadruped: patrol -> chase -> crouch windup -> lunge bite.


func _ready() -> void:
	anim_move = "run"
	super._ready()
	attack_area.get_child(0).shape.size = Vector2(130, 80)
	attack_area.get_child(0).position = Vector2(74, -40)


func _body_size() -> Vector2:
	return Vector2(72, 62)


func _sprite_offset() -> Vector2:
	return Vector2(0, -44)


func _windup_time() -> float:
	return 0.32


func ai_chase(delta: float) -> void:
	# wolves overshoot slightly for lunging feel
	var dx := player.global_position.x - global_position.x
	velocity.x = move_toward(velocity.x, signf(dx) * speed, 1400.0 * delta)


func _perform_attack() -> void:
	# lunge forward; ST.ATTACK keeps the momentum via base gravity handling
	velocity = Vector2(facing * 560.0, -140.0)
	attack_area.set_deferred("monitoring", true)
	var t := get_tree().create_timer(0.28)
	t.timeout.connect(func():
		if st != ST.DEAD:
			attack_area.set_deferred("monitoring", false)
			recover_t = 0.45
			st = ST.RECOVER)
	# manual damage check each frame during lunge
	var steps := 14
	for i in range(steps):
		await get_tree().create_timer(0.02).timeout
		if st == ST.DEAD or not is_instance_valid(self):
			return
		for body in attack_area.get_overlapping_bodies():
			if body is Player:
				body.take_damage(damage, Vector2(facing * 260.0, -160.0))
