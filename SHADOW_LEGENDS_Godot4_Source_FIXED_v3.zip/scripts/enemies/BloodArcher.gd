extends EnemyBase
class_name BloodArcher
## Ranged: keeps distance, telegraphed shots.


func _ready() -> void:
	anim_move = "walk"
	anim_attack = "shoot"
	super._ready()


func _windup_time() -> float:
	return 0.5


func ai_chase(delta: float) -> void:
	# maintain firing distance: retreat when too close
	var dist := player.global_position.distance_to(global_position)
	var dx := player.global_position.x - global_position.x
	var want := 0.0
	if dist < 300.0:
		want = -signf(dx) * speed
	elif dist > 520.0:
		want = signf(dx) * speed
	velocity.x = move_toward(velocity.x, want, 700.0 * delta)


func _perform_attack() -> void:
	var from := global_position + Vector2(facing * 34, -66)
	var dir := (player.global_position + Vector2(0, -60) - from)
	Projectile.spawn(get_parent(), from, dir, damage, "arrow", player)
	attack_area.set_deferred("monitoring", false)
	recover_t = 1.1
	st = ST.RECOVER
