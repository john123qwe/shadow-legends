class_name Vfx
## Static helpers spawning combat/environment effects. All use the generated
## effect textures in res://assets/effects/. Pooled where hot (ghosts, dust).

const FXD := "res://assets/effects/"

static var _tex_cache: Dictionary = {}


static func tex(name: String) -> Texture2D:
	if not _tex_cache.has(name):
		_tex_cache[name] = load(FXD + name + ".png")
	return _tex_cache[name]


static func _sprite(parent: Node, tex_name: String, pos: Vector2, rot := 0.0) -> Sprite2D:
	var s := Sprite2D.new()
	s.texture = tex(tex_name)
	s.global_position = pos
	s.rotation = rot
	s.z_index = 20
	parent.add_child(s)
	return s


## Katana slash arc. variant: 0/1/2 for combo stages. flip = facing.
static func slash(parent: Node, pos: Vector2, flip: int, variant: int) -> void:
	var s := _sprite(parent, "slash_%d" % clampi(variant, 0, 2), pos, randf_range(-0.15, 0.15))
	s.scale = Vector2(0.9 * flip, 0.9)
	s.modulate = Color(1, 1, 1, 0.95)
	var tw := s.create_tween()
	tw.set_parallel(true)
	tw.tween_property(s, "scale:x", 1.15 * flip, 0.16).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
	tw.tween_property(s, "modulate:a", 0.0, 0.18).set_delay(0.04)
	tw.chain().tween_callback(s.queue_free)


static func impact(parent: Node, pos: Vector2, crit := false) -> void:
	var s := _sprite(parent, "impact", pos, randf_range(0, TAU))
	s.scale = Vector2.ONE * (1.3 if crit else 1.0)
	if crit:
		s.modulate = Color(1.2, 0.9, 0.9)
	var tw := s.create_tween()
	tw.tween_property(s, "scale", s.scale * 1.5, 0.14).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.parallel().tween_property(s, "modulate:a", 0.0, 0.16)
	tw.tween_callback(s.queue_free)
	# sparks
	for i in range(6 if crit else 4):
		var p := _sprite(parent, "particle_red", pos, 0)
		var dir := Vector2.from_angle(randf_range(0, TAU)) * randf_range(90, 190)
		var pt := p.create_tween()
		pt.set_parallel(true)
		pt.tween_property(p, "global_position", pos + dir, 0.28).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
		pt.tween_property(p, "modulate:a", 0.0, 0.3)
		pt.tween_property(p, "scale", Vector2.ONE * 0.3, 0.3)
		pt.chain().tween_callback(p.queue_free)


static func shockwave(parent: Node, pos: Vector2) -> void:
	var s := _sprite(parent, "shockwave", pos)
	s.scale = Vector2(0.4, 0.4)
	var tw := s.create_tween()
	tw.set_parallel(true)
	tw.tween_property(s, "scale", Vector2(1.6, 1.6), 0.42).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
	tw.tween_property(s, "modulate:a", 0.0, 0.45)
	tw.chain().tween_callback(s.queue_free)


static func dash_ghost(parent: Node, pos: Vector2, facing: int) -> void:
	var s := _sprite(parent, "dash_ghost", pos + Vector2(0, -8))
	s.flip_h = facing < 0
	s.modulate = Color(1, 1, 1, 0.65)
	var tw := s.create_tween()
	tw.tween_property(s, "modulate:a", 0.0, 0.22)
	tw.tween_callback(s.queue_free)


static func shadow_puff(parent: Node, pos: Vector2) -> void:
	for i in range(5):
		var p := _sprite(parent, "particle_teal", pos + Vector2(randf_range(-14, 14), randf_range(-10, 10)))
		var tw := p.create_tween()
		tw.set_parallel(true)
		tw.tween_property(p, "global_position", p.global_position + Vector2(randf_range(-40, 40), randf_range(-60, -10)), 0.4)
		tw.tween_property(p, "modulate:a", 0.0, 0.4)
		tw.chain().tween_callback(p.queue_free)


static func dust(parent: Node, pos: Vector2) -> void:
	for i in range(3):
		var p := _sprite(parent, "smoke", pos + Vector2(randf_range(-10, 10), 0))
		p.scale = Vector2(0.5, 0.5)
		p.modulate.a = 0.6
		var tw := p.create_tween()
		tw.set_parallel(true)
		tw.tween_property(p, "global_position", p.global_position + Vector2(randf_range(-24, 24), -randf_range(6, 24)), 0.35)
		tw.tween_property(p, "modulate:a", 0.0, 0.38)
		tw.chain().tween_callback(p.queue_free)


static func heal_burst(parent: Node, pos: Vector2) -> void:
	for i in range(6):
		var p := _sprite(parent, "particle_teal", pos + Vector2(randf_range(-20, 20), randf_range(-30, 10)))
		var tw := p.create_tween()
		tw.tween_property(p, "global_position", p.global_position + Vector2(0, -70), 0.5)
		tw.parallel().tween_property(p, "modulate:a", 0.0, 0.5)
		tw.tween_callback(p.queue_free)


static func dissolve(parent: Node, pos: Vector2) -> void:
	for i in range(10):
		var p := _sprite(parent, "particle_red", pos + Vector2(randf_range(-24, 24), randf_range(-40, 6)))
		p.scale = Vector2.ONE * randf_range(0.5, 1.1)
		var tw := p.create_tween()
		tw.set_parallel(true)
		tw.tween_property(p, "global_position", p.global_position + Vector2(randf_range(-50, 50), randf_range(-90, -20)), 0.6)
		tw.tween_property(p, "modulate:a", 0.0, 0.62)
		tw.chain().tween_callback(p.queue_free)


## Floating damage number; crit styling in gold-red.
static func damage_number(parent: Node, pos: Vector2, amount: int, crit: bool, color: Color) -> void:
	var lbl := Label.new()
	lbl.text = Globals.num(int(amount))
	lbl.add_theme_font_override("font", load("res://assets/fonts/Vazirmatn-Bold.ttf"))
	lbl.add_theme_font_size_override("font_size", 46 if crit else 34)
	lbl.add_theme_color_override("font_color", color)
	if crit:
		lbl.add_theme_color_override("font_outline_color", Color(1, 0.85, 0.4))
		lbl.add_theme_constant_override("outline_size", 6)
	lbl.z_index = 60
	lbl.position = pos + Vector2(randf_range(-16, 16), 0)
	parent.add_child(lbl)
	var tw := lbl.create_tween()
	tw.set_parallel(true)
	tw.tween_property(lbl, "position:y", lbl.position.y - 70, 0.7).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
	tw.tween_property(lbl, "modulate:a", 0.0, 0.72)
	tw.chain().tween_callback(lbl.queue_free)
