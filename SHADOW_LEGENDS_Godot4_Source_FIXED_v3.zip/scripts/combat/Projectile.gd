extends Area2D
class_name Projectile
## Enemy projectiles (arrow / magic orb). Player projectiles are not needed in
## v1 (melee only) but the class supports a `targets_player` flag.

var direction := Vector2.RIGHT
var speed := 620.0
var damage := 12.0
var homing := 0.0
var life := 4.0
var target: Node2D


static func spawn(parent: Node, pos: Vector2, dir: Vector2, dmg: float, kind: String, tgt: Node2D = null) -> Projectile:
	var p := Projectile.new()
	p.global_position = pos
	p.direction = dir.normalized()
	p.damage = dmg
	p.homing = 2.2 if kind == "orb" else 0.0
	p.target = tgt
	p.collision_layer = Globals.L_PROJECTILE
	p.collision_mask = Globals.L_WORLD | Globals.L_PLAYER
	p.monitoring = true
	p.set_meta("damage", dmg)
	p.set_meta("source", pos)

	var s := Sprite2D.new()
	s.texture = Vfx.tex("arrow" if kind == "arrow" else "orb")
	s.rotation = dir.angle() if kind == "arrow" else 0.0
	p.add_child(s)

	var c := CollisionShape2D.new()
	var sh := CircleShape2D.new()
	sh.radius = 12.0
	c.shape = sh
	p.add_child(c)

	if kind == "orb":
		# trailing glow particles
		var pm := CPUParticles2D.new()
		pm.amount = 10
		pm.lifetime = 0.4
		pm.texture = Vfx.tex("particle_red")
		pm.emitting = true
		pm.local_coords = false
		p.add_child(pm)

	parent.add_child(p)
	if kind == "arrow":
		AudioManager.sfx("arrow", -6.0)
	else:
		AudioManager.sfx("orb", -6.0)
	return p


func _ready() -> void:
	body_entered.connect(_on_body)
	area_entered.connect(_on_area)


func _physics_process(delta: float) -> void:
	life -= delta
	if life <= 0.0:
		queue_free()
		return
	if homing > 0.0 and is_instance_valid(target):
		var want := (target.global_position + Vector2(0, -40) - global_position).normalized()
		direction = direction.lerp(want, homing * delta).normalized()
	global_position += direction * speed * delta
	if direction.x != 0.0:
		rotation = direction.angle()


func _on_body(body: Node) -> void:
	if body is Player:
		body.take_damage(damage, (direction + Vector2(0, -0.4)).normalized() * 240.0)
	_explode()


func _on_area(_area: Area2D) -> void:
	_explode()


func _explode() -> void:
	set_deferred("monitoring", false)
	Vfx.impact(get_parent(), global_position)
	queue_free()
