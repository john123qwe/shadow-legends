extends Node
class_name Main
## Main — boot flow and screen manager. The single root scene; swaps screens
## (menus) and gameplay scenes (GameWorld / EndlessRoom) with a fade.
## Every screen calls Main.change_scene(...) — the class_name makes the static
## API resolvable from any script (verified: no script references the scene
## node by name).

static var _instance: Node = null

var _holder: Control
var _game_holder: Node
var _fade: ColorRect
var _booting := true


func _ready() -> void:
	_instance = self
	get_tree().root.content_scale_factor = 1.0
	# fade layer on top
	var top := CanvasLayer.new()
	top.layer = 100
	add_child(top)
	_fade = ColorRect.new()
	_fade.color = Color(0.02, 0.04, 0.05, 1.0)
	_fade.set_anchors_preset(Control.PRESET_FULL_RECT)
	_fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	top.add_child(_fade)

	_game_holder = Node.new()
	add_child(_game_holder)
	_holder = Control.new()
	_holder.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(_holder)

	AudioManager.play_music("music_menu")
	_show_screen(MainMenuScreen.new())
	var tw := create_tween()
	tw.tween_property(_fade, "color:a", 0.0, 0.6)
	_booting = false


func _show_screen(s: Control) -> void:
	for c in _holder.get_children():
		c.queue_free()
	for c in _game_holder.get_children():
		c.queue_free()
	_holder.add_child(s)
	s.set_anchors_preset(Control.PRESET_FULL_RECT)


static func change_scene(node: Node) -> void:
	if _instance == null:
		return
	_instance._transition(node)


func _transition(node: Node) -> void:
	var tw := create_tween()
	tw.tween_property(_fade, "color:a", 1.0, 0.22)
	await tw.finished
	get_tree().paused = false
	for c in _holder.get_children():
		c.queue_free()
	for c in _game_holder.get_children():
		c.queue_free()
	if node is Control:
		node.set_anchors_preset(Control.PRESET_FULL_RECT)
		_holder.add_child(node)
	else:
		_game_holder.add_child(node)
	AudioManager.apply_volumes()
	var tw2 := create_tween()
	tw2.tween_property(_fade, "color:a", 0.0, 0.3)


## Modal overlay (pause/gameover/victory) above gameplay; returns the layer.
## The layer processes even while the tree is paused so buttons respond.
static func build_overlay(c: Control) -> CanvasLayer:
	var layer := CanvasLayer.new()
	layer.layer = 40
	layer.process_mode = Node.PROCESS_MODE_ALWAYS
	_instance.add_child(layer)
	c.set_anchors_preset(Control.PRESET_FULL_RECT)
	layer.add_child(c)
	return layer


static func close_overlay(layer: CanvasLayer) -> void:
	if layer:
		layer.queue_free()
