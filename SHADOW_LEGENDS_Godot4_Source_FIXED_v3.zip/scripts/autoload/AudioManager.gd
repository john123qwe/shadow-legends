extends Node
## AudioManager — music/ambience playback with crossfade + pooled SFX.
## Uses buses "Music" and "SFX" from default_bus_layout.tres.
## All audio files are original, procedurally generated (see /scripts/gen_audio.py).

const AUDIO_DIR := "res://assets/audio/"

var _music_a: AudioStreamPlayer
var _music_b: AudioStreamPlayer
var _active_is_a := true
var _current_track := ""
var _sfx_pool: Array[AudioStreamPlayer] = []
var _sfx_cache: Dictionary = {}
var _music_cache: Dictionary = {}


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS  # keep music alive while paused
	_music_a = AudioStreamPlayer.new()
	_music_b = AudioStreamPlayer.new()
	for p in [_music_a, _music_b]:
		p.bus = "Music"
		add_child(p)
	for i in range(8):
		var sp := AudioStreamPlayer.new()
		sp.bus = "SFX"
		add_child(sp)
		_sfx_pool.append(sp)
	apply_volumes()
	Globals.app_paused.connect(_on_app_paused)


func apply_volumes() -> void:
	var mv: float = SaveSystem.get_setting("music_vol", 0.8)
	var sv: float = SaveSystem.get_setting("sfx_vol", 1.0)
	_set_bus_linear("Music", mv)
	_set_bus_linear("SFX", sv)


func _set_bus_linear(bus_name: String, v: float) -> void:
	var idx := AudioServer.get_bus_index(bus_name)
	if idx >= 0:
		AudioServer.set_bus_volume_db(idx, linear_to_db(max(0.0001, v)))
		AudioServer.set_bus_mute(idx, v <= 0.001)


func _stream(name: String, looped: bool) -> AudioStream:
	var key := name + ("#loop" if looped else "")
	if _music_cache.has(key):
		return _music_cache[key]
	var path := AUDIO_DIR + name + ".wav"
	if not ResourceLoader.exists(path):
		push_warning("AudioManager: missing stream " + path)
		return null
	var s: AudioStream = load(path)
	if s is AudioStreamWAV and looped:
		s.loop_mode = AudioStreamWAV.LOOP_FORWARD
		s.loop_begin = 0
		s.loop_end = s.data.size() / 2  # 16-bit mono frames
	_music_cache[key] = s
	return s


func play_music(track: String, fade := 1.0) -> void:
	if _current_track == track:
		return
	_current_track = track
	# stings are one-shots; ambience/menu/boss loops seamlessly
	var s := _stream(track, not track.begins_with("sting_"))
	if s == null:
		return
	var from := _music_a if _active_is_a else _music_b
	var to := _music_b if _active_is_a else _music_a
	_active_is_a = not _active_is_a
	to.stream = s
	to.volume_db = -40.0
	to.play()
	var tw := create_tween()
	tw.set_parallel(true)
	tw.tween_property(to, "volume_db", -6.0, fade)
	if from.playing:
		tw.tween_property(from, "volume_db", -40.0, fade)
		tw.chain().tween_callback(from.stop)


func stop_music(fade := 0.8) -> void:
	_current_track = ""
	var from := _music_a if _active_is_a else _music_b
	var tw := create_tween()
	tw.tween_property(from, "volume_db", -40.0, fade)
	tw.tween_callback(from.stop)


func sfx(name: String, volume_db := 0.0, pitch_var := 0.06) -> void:
	if not _sfx_cache.has(name):
		var path := AUDIO_DIR + name + ".wav"
		if not ResourceLoader.exists(path):
			return
		_sfx_cache[name] = load(path)
	var stream: AudioStream = _sfx_cache[name]
	for sp in _sfx_pool:
		if not sp.playing:
			sp.stream = stream
			sp.pitch_scale = 1.0 + randf_range(-pitch_var, pitch_var)
			sp.volume_db = volume_db
			sp.play()
			return


func _on_app_paused() -> void:
	# Android lifecycle: silence while app is in background.
	_music_a.stop()
	_music_b.stop()
	for sp in _sfx_pool:
		sp.stop()
	_current_track = ""
