extends Node
## EventBus — global signal bus decoupling gameplay systems (autoload).

signal enemy_killed(enemy_id: String, pos: Vector2)
signal boss_defeated(boss_id: String)
signal level_completed(level_key: String, stars: int, gold: int, xp: int)
signal challenge_event(kind: String, amount: int)
signal abyss_depth_reached(depth: int)
signal request_player_heal(amount: float)

signal player_hurt(amount: int)
signal player_healed(amount: float)
signal player_died
signal combo_finished(hits: int)

signal achievement_unlocked(id: String)
signal boss_engaged(boss_name: String)
signal boss_health_changed(current: float, maximum: float)
signal boss_disengaged

signal screen_shake_requested(strength: float)
signal hitstop_requested(duration: float)
