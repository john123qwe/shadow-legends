extends Node
## Globals — project-wide constants and small helpers (autoload).

signal app_paused

const GAME_TITLE := "SHADOW LEGENDS"
const VERSION := "0.1.0-vertslice"

# Physics layers (matches project.godot layer_names)
const L_PLAYER := 1
const L_ENEMY := 2
const L_WORLD := 4
const L_PLATFORM := 8
const L_TRAP := 16
const L_PICKUP := 32
const L_PROJECTILE := 64
const L_TRIGGER := 128

# Palette (must mirror the generated art)
const COL_BG := Color("071014")
const COL_TEAL := Color("4a8a8a")
const COL_TEAL_DARK := Color("1e525c")
const COL_RED := Color("c1272d")
const COL_RED_HOT := Color("ff2e40")
const COL_GOLD := Color("dea83e")
const COL_TEXT := Color("dfe8e9")
const COL_TEXT_DIM := Color("8fa5a8")

# Rarity colors
const RARITY_COLORS := {
	"common": Color("9fb2b5"),
	"rare": Color("4aa3c7"),
	"epic": Color("a259d9"),
	"legendary": Color("dea83e"),
	"mythic": Color("ff2e40"),
}

const FA_DIGITS := ["۰", "۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹"]

## Convert integer to display string using Persian digits when enabled.
func num(n: int) -> String:
	var s := str(n)
	if SaveSystem.get_setting("persian_digits", true):
		var out := ""
		for ch in s:
			out += FA_DIGITS[int(ch)] if ch >= "0" and ch <= "9" else ch
		return out
	return s


func signed_num(n: int) -> String:
	return ("+" if n > 0 else "") + num(n)


func elapsed_string(sec: float) -> String:
	var s := int(sec)
	return "%d:%02d" % [s / 60, s % 60]


func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_WM_CLOSE_REQUEST:
		app_paused.emit()
