extends Control
class_name EndlessMenuScreen
## Endless Abyss menu: best depth/score + start.

func _ready() -> void:
	UIKit.root_rtl(self)
	UIKit.backdrop(self)
	var v := VBoxContainer.new()
	v.set_anchors_preset(Control.PRESET_FULL_RECT)
	v.alignment = BoxContainer.ALIGNMENT_CENTER
	v.add_theme_constant_override("separation", 12)
	add_child(v)

	var h := UIKit.header(func(): Main.change_scene(MainMenuScreen.new()))
	h["title"].text = L10N.t("menu.endless")
	v.add_child(h["row"])

	var p := UIKit.panel()
	var inner := VBoxContainer.new()
	inner.add_theme_constant_override("separation", 8)
	p.add_child(inner)
	var deepest: int = SaveSystem.data["abyss"]["deepest"]
	var best: int = SaveSystem.data["abyss"]["best_score"]
	inner.add_child(UIKit.label(L10N.t("game.abyss_best") + " — " + L10N.t("game.abyss_depth") + " " + Globals.num(deepest), 32, Globals.COL_TEXT, true))
	inner.add_child(UIKit.label(L10N.t("game.abyss_best") + " — Score: " + Globals.num(best), 28, Globals.COL_GOLD))
	inner.add_child(UIKit.label(L10N.t("ach.abyss_25_d"), 22, Globals.COL_TEXT_DIM))
	var wrap := HBoxContainer.new()
	wrap.alignment = BoxContainer.ALIGNMENT_CENTER
	wrap.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	wrap.add_child(p)
	v.add_child(wrap)

	var start := UIKit.button(L10N.t("common.play"), func():
		var room := EndlessRoom.new()
		room.depth = 1
		room.score = 0
		Main.change_scene(room), true)
	start.custom_minimum_size = Vector2(300, 74)
	var center := HBoxContainer.new()
	center.alignment = BoxContainer.ALIGNMENT_CENTER
	center.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	center.add_child(start)
	v.add_child(center)
