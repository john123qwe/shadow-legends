extends Control
class_name AchievementsScreen
## Achievements list with unlocked state and gem rewards.

func _ready() -> void:
	UIKit.root_rtl(self)
	UIKit.backdrop(self)
	var v := VBoxContainer.new()
	v.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(v)
	var h := UIKit.header(func(): Main.change_scene(MainMenuScreen.new()))
	h["title"].text = L10N.t("menu.achievements")
	v.add_child(h["row"])

	var sc := ScrollContainer.new()
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sc.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	v.add_child(sc)
	var list := VBoxContainer.new()
	list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	list.add_theme_constant_override("separation", 8)
	sc.add_child(list)

	for id in GameDB.ACHIEVEMENTS.keys():
		var def: Dictionary = GameDB.ACHIEVEMENTS[id]
		var unlocked: bool = SaveSystem.data["achievements"].has(id)
		var p := UIKit.panel()
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 10)
		p.add_child(row)
		var star := TextureRect.new()
		star.texture = load("res://assets/ui/icon_star_on.png" if unlocked else "res://assets/ui/icon_star_off.png")
		star.custom_minimum_size = Vector2(44, 44)
		star.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		star.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		row.add_child(star)
		var info := VBoxContainer.new()
		info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(info)
		info.add_child(UIKit.label(L10N.t(def["key"]), 26, Globals.COL_TEXT if unlocked else Globals.COL_TEXT_DIM, true))
		info.add_child(UIKit.label(L10N.t(def["dkey"]), 20, Globals.COL_TEXT_DIM))
		row.add_child(UIKit.label("+" + Globals.num(def["reward"]), 24, Globals.COL_RED_HOT, true))
		list.add_child(p)
