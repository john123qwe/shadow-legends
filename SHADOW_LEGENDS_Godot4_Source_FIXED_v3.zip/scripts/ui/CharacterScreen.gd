extends Control
class_name CharacterScreen
## Character screen: attributes summary + skill tree (3 branches).

var _points_lbl: Label


func _ready() -> void:
	_build()


func _build() -> void:
	for c in get_children():
		c.queue_free()
	UIKit.root_rtl(self)
	UIKit.backdrop(self)
	var v := VBoxContainer.new()
	v.set_anchors_preset(Control.PRESET_FULL_RECT)
	v.add_theme_constant_override("separation", 6)
	add_child(v)
	var h := UIKit.header(func(): Main.change_scene(MainMenuScreen.new()))
	h["title"].text = L10N.t("menu.character") + " — " + L10N.t("common.level") + " " + Globals.num(int(SaveSystem.p()["level"]))
	v.add_child(h["row"])

	_points_lbl = UIKit.label(L10N.t("char.skill_points") + ": " + Globals.num(int(SaveSystem.p()["skill_points"])), 30, Globals.COL_GOLD, true)
	_points_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(_points_lbl)

	var sc := ScrollContainer.new()
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sc.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	v.add_child(sc)

	var cols := HBoxContainer.new()
	cols.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	cols.add_theme_constant_override("separation", 14)
	sc.add_child(cols)

	# --- attributes panel ---
	var ap := UIKit.panel()
	var av := VBoxContainer.new()
	av.add_theme_constant_override("separation", 6)
	av.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	ap.add_child(av)
	av.add_child(UIKit.label(L10N.t("char.attributes"), 34, Globals.COL_TEAL, true))
	for attr in GameDB.ATTR_INFO.keys():
		var val := SaveSystem.attribute(attr)
		var shown: String
		if GameDB.ATTR_INFO[attr]["pct"]:
			shown = L10N.percent(val if attr != "crit_damage" else val - 1.0)
		else:
			shown = Globals.num(int(val))
		var row := HBoxContainer.new()
		var n := UIKit.label(L10N.t(GameDB.ATTR_INFO[attr]["key"]), 26)
		n.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(n)
		row.add_child(UIKit.label(shown, 26, Globals.COL_GOLD, true))
		av.add_child(row)
	cols.add_child(ap)

	# --- skill branches ---
	for branch in GameDB.SKILL_BRANCHES:
		var bp := UIKit.panel()
		var bv := VBoxContainer.new()
		bv.add_theme_constant_override("separation", 8)
		bv.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		bp.add_child(bv)
		bv.add_child(UIKit.label(L10N.t("char.branch_" + branch), 32, Globals.COL_TEAL, true))
		for sid in GameDB.SKILLS.keys():
			var def: Dictionary = GameDB.SKILLS[sid]
			if def["branch"] != branch:
				continue
			bv.add_child(_skill_row(sid, def))
		cols.add_child(bp)


func _skill_row(id: String, def: Dictionary) -> Control:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	var info := VBoxContainer.new()
	info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(info)
	var rank := SaveSystem.skill_rank(id)
	var name_l := UIKit.label("%s (%d/%d)" % [def["name"]["fa"], rank, def["max_rank"]],
		24, Globals.COL_TEXT if rank > 0 else Globals.COL_TEXT_DIM, true)
	info.add_child(name_l)
	info.add_child(UIKit.label(def["desc"]["fa"], 20, Globals.COL_TEXT_DIM))
	var chk := SaveSystem.can_learn_skill(id)
	var b := UIKit.button(L10N.t("common.upgrade") if rank > 0 else "+", func():
		if SaveSystem.learn_skill(id):
			AudioManager.sfx("level_up", -6.0)
			_refresh())
	if not chk["ok"]:
		b.disabled = true
		b.tooltip_text = chk["reason"]
	row.add_child(b)
	return row


func _refresh() -> void:
	_build()


func _process(_d: float) -> void:
	_points_lbl.text = L10N.t("char.skill_points") + ": " + Globals.num(int(SaveSystem.p()["skill_points"]))
