extends Control
class_name WorldSelectScreen
## World cards + per-world level selection (stars, locks).

var _list: VBoxContainer


func _ready() -> void:
	UIKit.root_rtl(self)
	UIKit.backdrop(self)

	var v := VBoxContainer.new()
	v.set_anchors_preset(Control.PRESET_FULL_RECT)
	v.add_theme_constant_override("separation", 8)
	add_child(v)

	var h := UIKit.header(func(): Main.change_scene(MainMenuScreen.new()))
	h["title"].text = L10N.t("common.play")
	v.add_child(h["row"])

	_scroll(v)


func _scroll(v: VBoxContainer) -> void:
	var sc := ScrollContainer.new()
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	v.add_child(sc)
	_list = VBoxContainer.new()
	_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_list.add_theme_constant_override("separation", 10)
	sc.add_child(_list)
	_refresh()


func _refresh() -> void:
	for c in _list.get_children():
		c.queue_free()
	var unlocked := SaveSystem.worlds_unlocked()
	for w in GameDB.WORLDS:
		var p := UIKit.panel()
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 16)
		p.add_child(row)
		var info := VBoxContainer.new()
		info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(info)
		var locked: bool = int(w["id"]) > unlocked
		info.add_child(UIKit.label(L10N.t("world." + String(w["key"])), 34, Globals.COL_TEXT if not locked else Globals.COL_TEXT_DIM, true))
		var stars := 0
		for i in range(1, int(w["levels"]) + 1):
			stars += int(SaveSystem.data["progress"]["levels_completed"].get("w%d_l%d" % [w["id"], i], 0))
		info.add_child(UIKit.label("%s %d / %d" % [L10N.t("common.stars"), stars, int(w["levels"]) * 3], 24, Globals.COL_GOLD))
		var btn: Button
		if locked:
			btn = UIKit.button(L10N.t("common.locked"), func(): pass)
			btn.disabled = true
		else:
			var wid: int = w["id"]
			btn = UIKit.button(L10N.t("common.play"), func(): Main.change_scene(LevelSelectScreen.new(wid)), true)
		row.add_child(btn)
		_list.add_child(p)


class LevelSelectScreen extends Control:
	var world := 1
	var _list: VBoxContainer

	func _init(w: int = 1) -> void:
		world = w

	func _ready() -> void:
		UIKit.root_rtl(self)
		UIKit.backdrop(self)
		var v := VBoxContainer.new()
		v.set_anchors_preset(Control.PRESET_FULL_RECT)
		add_child(v)
		var h := UIKit.header(func(): Main.change_scene(WorldSelectScreen.new()))
		h["title"].text = L10N.t("world.w%d" % world)
		v.add_child(h["row"])
		var sc := ScrollContainer.new()
		sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
		v.add_child(sc)
		_list = VBoxContainer.new()
		_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		_list.add_theme_constant_override("separation", 10)
		sc.add_child(_list)
		var wdef: Dictionary = GameDB.WORLDS[world - 1]
		var unlocked := SaveSystem.worlds_unlocked()
		for i in range(1, int(wdef["levels"]) + 1):
			var key := "w%d_l%d" % [world, i]
			var prev_key := "w%d_l%d" % [world, i - 1]
			var is_locked := (i > 1 and not SaveSystem.is_level_completed(prev_key)) \
				or (i == 1 and world > unlocked)
			var p := UIKit.panel()
			var row := HBoxContainer.new()
			p.add_child(row)
			var info := VBoxContainer.new()
			info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			row.add_child(info)
			info.add_child(UIKit.label(GameDB.LEVEL_NAMES[key]["fa"], 32, Globals.COL_TEXT if not is_locked else Globals.COL_TEXT_DIM, true))
			var st := int(SaveSystem.data["progress"]["levels_completed"].get(key, 0))
			var star_row := HBoxContainer.new()
			for si in range(3):
				var sr := TextureRect.new()
				sr.texture = load("res://assets/ui/icon_star_on.png" if si < st else "res://assets/ui/icon_star_off.png")
				sr.custom_minimum_size = Vector2(30, 30)
				sr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
				sr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
				star_row.add_child(sr)
			info.add_child(star_row)
			var b: Button
			if is_locked:
				b = UIKit.button(L10N.t("common.locked"), func(): pass)
				b.disabled = true
			else:
				var lvl := i
				b = UIKit.button(L10N.t("common.play"), func():
					var gw := GameWorld.new()
					gw.setup_campaign(world, lvl)
					Main.change_scene(gw), true)
			row.add_child(b)
			_list.add_child(p)
