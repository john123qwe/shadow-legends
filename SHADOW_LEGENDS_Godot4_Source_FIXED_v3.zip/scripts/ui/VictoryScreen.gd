extends Control
class_name VictoryScreen
## Level-clear overlay: stars, rewards, next level / world / menu.

var def: Dictionary
var stars := 3
var world: GameWorld


func _init(d: Dictionary, s: int, w: GameWorld) -> void:
	def = d
	stars = s
	world = w


func _ready() -> void:
	UIKit.root_rtl(self)
	var dim := ColorRect.new()
	dim.color = Color(0.02, 0.06, 0.05, 0.82)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(dim)
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(center)
	var p := UIKit.panel()
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 10)
	p.add_child(v)

	var t := UIKit.title(L10N.t("game.victory"))
	t.add_theme_color_override("font_color", Globals.COL_GOLD)
	v.add_child(t)
	v.add_child(UIKit.label(GameDB.LEVEL_NAMES.get(def["key"], {"fa": def["key"]})["fa"], 30, Globals.COL_TEXT, true))
	var star_row := HBoxContainer.new()
	star_row.alignment = BoxContainer.ALIGNMENT_CENTER
	star_row.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	for si in range(3):
		var sr := TextureRect.new()
		sr.texture = load("res://assets/ui/icon_star_on.png" if si < stars else "res://assets/ui/icon_star_off.png")
		sr.custom_minimum_size = Vector2(64, 64)
		sr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		sr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		star_row.add_child(sr)
	v.add_child(star_row)
	v.add_child(UIKit.label("%s: %s    %s: %s" % [L10N.t("game.reward_gold"), Globals.num(def["gold_reward"]),
		L10N.t("game.reward_xp"), Globals.num(def["xp_reward"])], 26, Globals.COL_TEXT_DIM))

	var next_w := int(def["world"])
	var next_l := 0
	var key := String(def["key"])
	next_l = int(key.substr(4)) + 1
	if next_l > GameDB.WORLDS[next_w - 1]["levels"]:
		# world complete → next world's first level
		if next_w < GameDB.WORLDS.size():
			v.add_child(UIKit.button(L10N.t("world.w%d" % (next_w + 1)), func():
				var gw := GameWorld.new()
				gw.setup_campaign(next_w + 1, 1)
				Main.change_scene(gw), true))
		else:
			v.add_child(UIKit.label(L10N.t("common.done"), 30, Globals.COL_GOLD))
	else:
		v.add_child(UIKit.button(L10N.t("game.next_level"), func():
			var gw := GameWorld.new()
			gw.setup_campaign(next_w, next_l)
			Main.change_scene(gw), true))

	v.add_child(UIKit.button(L10N.t("game.quit_to_menu"), func():
		SaveSystem.save_game()
		Main.change_scene(MainMenuScreen.new())))
	center.add_child(p)
	AudioManager.sfx("level_up")
