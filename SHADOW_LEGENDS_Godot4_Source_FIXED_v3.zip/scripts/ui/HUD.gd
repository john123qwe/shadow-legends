extends CanvasLayer
class_name HUD
## In-game HUD: health, XP bar, level chip, gold/gems, boss bar,
## special-charge ring, dash cooldown, pause button.

var player: Player
var _hp_bar: TextureProgressBar
var _xp_bar: TextureProgressBar
var _level_lbl: Label
var _gold_lbl: Label
var _gems_lbl: Label
var _boss_bar: TextureProgressBar
var _boss_title: Label
var _boss_root: Control
var _special_icon: TextureRect
var _dash_icon: TextureRect
var _toast: Label
var _root: Control
var font_bold: FontFile


func _ready() -> void:
	layer = 9
	font_bold = load("res://assets/fonts/Vazirmatn-Bold.ttf")
	_root = Control.new()
	_root.set_anchors_preset(Control.PRESET_FULL_RECT)
	_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_root)

	_build_top_left()
	_build_top_right()
	_build_boss_bar()
	_build_status_icons()
	_build_toast()

	SaveSystem.gold_changed.connect(_on_gold)
	SaveSystem.gems_changed.connect(_on_gems)
	SaveSystem.xp_changed.connect(_on_xp)
	SaveSystem.leveled_up.connect(_on_level_up)
	EventBus.boss_engaged.connect(_on_boss_engaged)
	EventBus.boss_health_changed.connect(_on_boss_hp)
	EventBus.boss_disengaged.connect(func(): _boss_root.visible = false)
	EventBus.achievement_unlocked.connect(_on_achievement)
	_refresh_currencies()
	_refresh_level()


func _mk_bar(fill: String) -> TextureProgressBar:
	var b := TextureProgressBar.new()
	b.texture_under = load("res://assets/ui/bar_bg.png")
	b.texture_progress = load("res://assets/ui/bar_%s.png" % fill)
	b.nine_patch_stretch = false
	b.fill_mode = TextureProgressBar.FILL_LEFT_TO_RIGHT
	b.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return b


func _build_top_left() -> void:
	var box := VBoxContainer.new()
	box.position = Vector2(24, 18)
	box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.add_child(box)

	_hp_bar = _mk_bar("red")
	_hp_bar.custom_minimum_size = Vector2(420, 30)
	box.add_child(_hp_bar)

	var xp_row := HBoxContainer.new()
	xp_row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	box.add_child(xp_row)
	_xp_bar = _mk_bar("gold")
	_xp_bar.custom_minimum_size = Vector2(340, 16)
	_xp_bar.max_value = 100.0
	xp_row.add_child(_xp_bar)
	_level_lbl = _mk_label("")
	_level_lbl.add_theme_font_size_override("font_size", 26)
	xp_row.add_child(_level_lbl)


func _build_top_right() -> void:
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_END
	row.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.add_child(row)
	row.add_child(_chip(load("res://assets/ui/icon_coin.png")))
	_gold_lbl = _mk_label("")
	_gold_lbl.custom_minimum_size = Vector2(120, 0)
	row.add_child(_gold_lbl)
	row.add_child(_chip(load("res://assets/ui/icon_gem.png")))
	_gems_lbl = _mk_label("")
	_gems_lbl.custom_minimum_size = Vector2(120, 0)
	row.add_child(_gems_lbl)


func _chip(tex: Texture2D) -> TextureRect:
	var c := TextureRect.new()
	c.texture = tex
	c.custom_minimum_size = Vector2(44, 44)
	c.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	c.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	c.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return c


func _mk_label(txt: String) -> Label:
	var l := Label.new()
	l.text = txt
	l.add_theme_font_override("font", font_bold)
	l.add_theme_font_size_override("font_size", 30)
	l.add_theme_color_override("font_color", Globals.COL_TEXT)
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.7))
	l.add_theme_constant_override("outline_size", 5)
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l


func _build_boss_bar() -> void:
	_boss_root = VBoxContainer.new()
	_boss_root.set_anchors_preset(Control.PRESET_CENTER_TOP)
	_boss_root.position = Vector2(get_viewport().get_visible_rect().size.x / 2.0 - 320, 26)
	_boss_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_boss_root.visible = false
	_root.add_child(_boss_root)
	_boss_title = _mk_label("")
	_boss_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_boss_root.add_child(_boss_title)
	_boss_bar = _mk_bar("red")
	_boss_bar.custom_minimum_size = Vector2(640, 26)
	_boss_root.add_child(_boss_bar)


func _build_status_icons() -> void:
	# special charge + dash cooldown icons above the action buttons (right side)
	var vp := get_viewport().get_visible_rect().size
	var box := HBoxContainer.new()
	box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	box.position = Vector2(vp.x - 330, vp.y - 500)
	_root.add_child(box)
	_special_icon = TextureRect.new()
	_special_icon.texture = load("res://assets/ui/rbtn_special.png")
	_special_icon.custom_minimum_size = Vector2(70, 70)
	_special_icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_special_icon.modulate = Color(0.4, 0.4, 0.4)
	box.add_child(_special_icon)
	_dash_icon = TextureRect.new()
	_dash_icon.texture = load("res://assets/ui/rbtn_dash.png")
	_dash_icon.custom_minimum_size = Vector2(70, 70)
	_dash_icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_dash_icon.modulate = Color(0.4, 0.4, 0.4)
	box.add_child(_dash_icon)


func _build_toast() -> void:
	_toast = _mk_label("")
	_toast.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_toast.set_anchors_preset(Control.PRESET_CENTER_TOP)
	_toast.add_theme_font_size_override("font_size", 34)
	_toast.modulate.a = 0.0
	_toast.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.add_child(_toast)


func bind_player(p: Player) -> void:
	player = p
	p.health_changed.connect(_on_hp)
	p.special_changed.connect(_on_special)
	p.dash_cd_changed.connect(_on_dash_cd)
	p.health_changed.emit(p.hp, p.max_hp)


func _on_hp(hp: float, mx: float) -> void:
	_hp_bar.max_value = mx
	var tw := create_tween()
	tw.tween_property(_hp_bar, "value", hp, 0.25).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)


func _on_special(charge: float) -> void:
	_special_icon.modulate = Color(1, 1, 1) if charge >= 1.0 else Color(0.4, 0.4, 0.4)
	_special_icon.scale = Vector2.ONE * (1.0 + 0.15 * charge)


func _on_dash_cd(frac: float) -> void:
	_dash_icon.modulate = Color(1, 1, 1) if frac >= 1.0 else Color(0.4, 0.4, 0.4)


func _on_gold(v: int) -> void:
	_gold_lbl.text = Globals.num(v)


func _on_gems(v: int) -> void:
	_gems_lbl.text = Globals.num(v)


func _on_xp(xp: int, level: int, need: int) -> void:
	_xp_bar.value = 100.0 * xp / float(need)


func _refresh_currencies() -> void:
	_on_gold(int(SaveSystem.p()["gold"]))
	_on_gems(int(SaveSystem.p()["gems"]))


func _refresh_level() -> void:
	_level_lbl.text = L10N.t("common.level") + " " + Globals.num(int(SaveSystem.p()["level"]))


func _on_level_up(_lv: int) -> void:
	_refresh_level()
	toast(L10N.t("common.level") + " " + Globals.num(int(SaveSystem.p()["level"])) + "!")
	AudioManager.sfx("level_up")


func _on_boss_engaged(title: String) -> void:
	_boss_title.text = title
	_boss_root.visible = true
	_boss_bar.value = _boss_bar.max_value


func _on_boss_hp(hp: float, mx: float) -> void:
	_boss_bar.max_value = mx
	_boss_bar.value = hp


func _on_achievement(id: String) -> void:
	var def: Dictionary = GameDB.ACHIEVEMENTS.get(id, {})
	toast("+ " + L10N.t(def.get("key", id)))


func toast(msg: String) -> void:
	_toast.text = msg
	_toast.modulate.a = 0.0
	var tw := create_tween()
	tw.tween_property(_toast, "modulate:a", 1.0, 0.25)
	tw.tween_interval(1.4)
	tw.tween_property(_toast, "modulate:a", 0.0, 0.5)


func _process(_delta: float) -> void:
	var vp := get_viewport().get_visible_rect().size
	_boss_root.position = Vector2(vp.x / 2.0 - 320, 26)
	_toast.position = Vector2(vp.x / 2.0 - 220, 90)
