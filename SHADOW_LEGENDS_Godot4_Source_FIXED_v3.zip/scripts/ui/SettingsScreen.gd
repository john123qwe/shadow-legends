extends Control
class_name SettingsScreen
## Settings: audio volumes, language, Persian digits, touch size, shake, reset.

func _ready() -> void:
	_build()


func _build() -> void:
	# Rebuild the whole screen (used on language change).
	for c in get_children():
		remove_child(c)
		c.queue_free()
	UIKit.root_rtl(self)
	UIKit.backdrop(self)
	var v := VBoxContainer.new()
	v.set_anchors_preset(Control.PRESET_FULL_RECT)
	v.add_theme_constant_override("separation", 8)
	add_child(v)
	var h := UIKit.header(func(): Main.change_scene(MainMenuScreen.new()))
	h["title"].text = L10N.t("set.title")
	v.add_child(h["row"])

	var sc := ScrollContainer.new()
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sc.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	v.add_child(sc)
	var box := VBoxContainer.new()
	box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	box.add_theme_constant_override("separation", 10)
	sc.add_child(box)

	var p := UIKit.panel()
	box.add_child(p)
	var inner := VBoxContainer.new()
	inner.add_theme_constant_override("separation", 12)
	inner.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	p.add_child(inner)

	inner.add_child(_slider(L10N.t("set.music"), "music_vol"))
	inner.add_child(_slider(L10N.t("set.sfx"), "sfx_vol"))
	inner.add_child(_slider(L10N.t("set.button_scale"), "button_scale", 0.7, 1.5))
	inner.add_child(_toggle(L10N.t("set.persian_digits"), "persian_digits"))
	inner.add_child(_toggle(L10N.t("set.shake"), "screen_shake"))

	# language row
	var lang_row := HBoxContainer.new()
	lang_row.add_theme_constant_override("separation", 10)
	lang_row.add_child(UIKit.label(L10N.t("set.language"), 26))
	lang_row.add_child(UIKit.button("فارسی", func():
		L10N.set_locale("fa")
		_build()))
	lang_row.add_child(UIKit.button("English", func():
		L10N.set_locale("en")
		_build()))
	inner.add_child(lang_row)

	# danger zone
	var reset_row := HBoxContainer.new()
	reset_row.add_child(UIKit.button(L10N.t("set.reset"), func():
		_confirm_reset()))
	box.add_child(reset_row)

	var about := UIKit.label("SHADOW LEGENDS — Godot 4 - %s\n%s" % [Globals.VERSION, L10N.t("menu.subtitle")], 20, Globals.COL_TEXT_DIM)
	box.add_child(about)


func _slider(label_txt: String, key: String, lo := 0.0, hi := 1.0) -> Control:
	var row := VBoxContainer.new()
	var top := HBoxContainer.new()
	top.add_child(UIKit.label(label_txt, 26))
	row.add_child(top)
	var s := HSlider.new()
	s.min_value = lo
	s.max_value = hi
	s.step = 0.05
	s.value = float(SaveSystem.get_setting(key, 1.0))
	s.custom_minimum_size = Vector2(520, 30)
	s.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	s.value_changed.connect(func(v: float):
		SaveSystem.set_setting(key, v)
		AudioManager.apply_volumes())
	row.add_child(s)
	return row


func _toggle(label_txt: String, key: String) -> Control:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	row.add_child(UIKit.label(label_txt, 26))
	var cb := CheckButton.new()
	cb.button_pressed = bool(SaveSystem.get_setting(key, true))
	cb.toggled.connect(func(v: bool):
		SaveSystem.set_setting(key, v)
		AudioManager.sfx("ui_click", -6.0))
	row.add_child(cb)
	return row


func _confirm_reset() -> void:
	var layer := Main.build_overlay(_confirm_panel())
	AudioManager.sfx("ui_open", -4.0)


func _confirm_panel() -> Control:
	var c := Control.new()
	c.set_anchors_preset(Control.PRESET_FULL_RECT)
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.7)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	c.add_child(dim)
	var center := VBoxContainer.new()
	center.set_anchors_preset(Control.PRESET_CENTER)
	center.alignment = BoxContainer.ALIGNMENT_CENTER
	var p := UIKit.panel()
	var inner := VBoxContainer.new()
	inner.add_theme_constant_override("separation", 12)
	p.add_child(inner)
	inner.add_child(UIKit.label(L10N.t("set.reset_confirm"), 30, Globals.COL_TEXT, true))
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 14)
	inner.add_child(row)
	row.add_child(UIKit.button(L10N.t("common.confirm"), func():
		SaveSystem.wipe_save()
		Main.close_overlay(c.get_parent())))
	row.add_child(UIKit.button(L10N.t("common.cancel"), func(): Main.close_overlay(c.get_parent())))
	center.add_child(p)
	c.add_child(center)
	return c
