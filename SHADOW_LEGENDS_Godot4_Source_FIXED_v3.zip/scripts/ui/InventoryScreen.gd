extends Control
class_name InventoryScreen
## Inventory + equipment: tabs per slot, item detail (equip/upgrade/sell/use).

var _tabs: HBoxContainer
var _list: BoxContainer
var _detail: VBoxContainer
var _current_slot := "weapon"


func _ready() -> void:
	UIKit.root_rtl(self)
	UIKit.backdrop(self)
	var v := VBoxContainer.new()
	v.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(v)
	var h := UIKit.header(func(): Main.change_scene(MainMenuScreen.new()))
	h["title"].text = L10N.t("inv.title")
	v.add_child(h["row"])

	_tabs = HBoxContainer.new()
	_tabs.alignment = BoxContainer.ALIGNMENT_CENTER
	_tabs.add_theme_constant_override("separation", 10)
	v.add_child(_tabs)
	for slot in ["weapon", "armor", "accessory", "potion"]:
		var key: String = "inv." + slot
		_tabs.add_child(UIKit.button(L10N.t(key), func(): _select_slot(slot)))

	var body := HBoxContainer.new()
	body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	body.add_theme_constant_override("separation", 14)
	v.add_child(body)

	_list = VBoxContainer.new()
	var sc := ScrollContainer.new()
	sc.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sc.add_child(_list)
	body.add_child(sc)

	var dp := UIKit.panel()
	_detail = VBoxContainer.new()
	_detail.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_detail.add_theme_constant_override("separation", 8)
	dp.add_child(_detail)
	body.add_child(dp)

	SaveSystem.inventory_changed.connect(_rebuild)
	_rebuild()


func _select_slot(slot: String) -> void:
	_current_slot = slot
	_rebuild()


func _rebuild() -> void:
	for c in _list.get_children():
		c.queue_free()
	for c in _detail.get_children():
		c.queue_free()
	_detail.add_child(UIKit.label(L10N.t("inv.title"), 30, Globals.COL_TEAL, true))

	var items := []
	for it in SaveSystem.p()["inventory"]:
		var def: Dictionary = GameDB.ITEMS.get(it["id"], {})
		if def.get("slot", "") == _current_slot:
			items.append(it)
	if items.is_empty():
		_detail.add_child(UIKit.label(L10N.t("inv.empty"), 24, Globals.COL_TEXT_DIM))

	for it in items:
		_item_row(it)


func _item_row(inst: Dictionary) -> void:
	var def: Dictionary = GameDB.ITEMS[inst["id"]]
	var rc: Color = Globals.RARITY_COLORS[inst["rarity"]]
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)

	var icon := TextureRect.new()
	icon.texture = load("res://assets/ui/item_%s.png" % def["type"])
	icon.custom_minimum_size = Vector2(56, 56)
	icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	icon.modulate = rc
	row.add_child(icon)

	var info := VBoxContainer.new()
	info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(info)
	var equipped: bool = SaveSystem.p()["equipped"].get(def["slot"], "") == inst["uid"]
	var plus := int(inst["plus"])
	var title_txt: String = String(def["name"]["fa"])
	if plus > 0:
		title_txt += " +" + Globals.num(plus)
	if def["slot"] == "potion":
		title_txt += " x" + Globals.num(int(inst["count"]))
	info.add_child(UIKit.label(title_txt, 26, rc if equipped else Globals.COL_TEXT, true))
	# stat line
	var parts: Array[String] = []
	for st in def["stats"].keys():
		var v: float = GameDB.stat_value(def, st, inst["rarity"], plus)
		var key: String = GameDB.ATTR_INFO.get(st, {}).get("key", "inv.title")
		parts.append("%s %s" % [L10N.t(key), Globals.num(int(v))])
	info.add_child(UIKit.label("  |  ".join(parts), 20, Globals.COL_TEXT_DIM))
	var rarity_l := UIKit.label(_rarity_fa(inst["rarity"]), 18, rc)
	info.add_child(rarity_l)

	if def["slot"] == "potion":
		row.add_child(UIKit.button(L10N.t("common.use"), func(): SaveSystem.use_potion(inst["uid"])))
	else:
		var eq := UIKit.button(L10N.t("common.equip"), func():
			SaveSystem.equip_item(inst["uid"]))
		eq.disabled = equipped
		row.add_child(eq)
		var up := UIKit.button(L10N.t("common.upgrade"), func():
			if SaveSystem.upgrade_item(inst["uid"]):
				AudioManager.sfx("level_up", -6.0)
			else:
				AudioManager.sfx("ui_click", -8.0))
		up.disabled = plus >= 10
		row.add_child(up)
		row.add_child(UIKit.button(L10N.t("common.sell"), func():
			SaveSystem.sell_item(inst["uid"])))
	_list.add_child(row)


func _rarity_fa(r: String) -> String:
	match r:
		"common": return "معمولی"
		"rare": return "کمیاب"
		"epic": return "حماسی"
		"legendary": return "افسانه‌ای"
		"mythic": return "اسطوره‌ای"
	return r
