extends Control
class_name MainMenuScreen
## Main menu: title, animated ninja silhouette preview, navigation.

func _ready() -> void:
	UIKit.root_rtl(self)
	UIKit.backdrop(self)

	var v := VBoxContainer.new()
	v.set_anchors_preset(Control.PRESET_FULL_RECT)
	v.add_theme_constant_override("separation", 10)
	v.alignment = BoxContainer.ALIGNMENT_CENTER
	add_child(v)

	var t := UIKit.title("SHADOW LEGENDS")
	v.add_child(t)
	var sub := UIKit.label(L10N.t("menu.subtitle"), 30, Globals.COL_TEAL, true)
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(sub)

	# animated ninja silhouette in the menu
	var wrap := Control.new()
	wrap.custom_minimum_size = Vector2(0, 190)
	wrap.mouse_filter = Control.MOUSE_FILTER_IGNORE
	v.add_child(wrap)
	var ninja := AnimatedSprite2D.new()
	ninja.sprite_frames = SpriteLib.ninja()
	ninja.position = Vector2(get_viewport_rect().size.x / 2.0, 90)
	ninja.scale = Vector2(1.4, 1.4)
	ninja.animation = "idle"
	wrap.add_child(ninja)
	ninja.play("idle")
	var slashfx := TextureRect.new()
	slashfx.texture = Vfx.tex("slash_0")
	slashfx.position = Vector2(get_viewport_rect().size.x / 2.0 + 40, 60)
	slashfx.custom_minimum_size = Vector2(110, 110)
	slashfx.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	slashfx.modulate.a = 0.75
	wrap.add_child(slashfx)

	var buttons := GridContainer.new()
	buttons.columns = 3
	buttons.add_theme_constant_override("h_separation", 18)
	buttons.add_theme_constant_override("v_separation", 14)
	buttons.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	v.add_child(buttons)

	buttons.add_child(UIKit.button(L10N.t("menu.start"), func(): Main.change_scene(WorldSelectScreen.new()), true))
	buttons.add_child(UIKit.button(L10N.t("menu.endless"), func(): Main.change_scene(EndlessMenuScreen.new())))
	buttons.add_child(UIKit.button(L10N.t("menu.character"), func(): Main.change_scene(CharacterScreen.new())))
	buttons.add_child(UIKit.button(L10N.t("menu.inventory"), func(): Main.change_scene(InventoryScreen.new())))
	buttons.add_child(UIKit.button(L10N.t("menu.shop"), func(): Main.change_scene(ShopScreen.new())))
	buttons.add_child(UIKit.button(L10N.t("menu.achievements"), func(): Main.change_scene(AchievementsScreen.new())))
	buttons.add_child(UIKit.button(L10N.t("menu.settings"), func(): Main.change_scene(SettingsScreen.new())))

	# daily challenge strip
	var d: Dictionary = SaveSystem.daily_status()
	var dc := UIKit.label("%s: %s (%s)" % [L10N.t("menu.shop"), d["challenge"], Globals.num(int(d["progress"]))],
		22, Globals.COL_TEXT_DIM)
	dc.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(dc)

	var ver := UIKit.label("v" + Globals.VERSION + "  -  Cafe Bazaar / Myket ready", 18, Globals.COL_TEXT_DIM)
	ver.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(ver)

	AudioManager.play_music("music_menu")
