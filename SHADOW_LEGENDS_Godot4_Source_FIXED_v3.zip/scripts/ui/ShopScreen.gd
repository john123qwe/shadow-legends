extends Control
class_name ShopScreen
## Shop: gold potions (soft currency) + IAP gem packs & cosmetics via
## Billing (Cafe Bazaar Poolakey / Myket). Real prices come from the market;
## when billing is unavailable the IAP section explains why.

var _iap_box: VBoxContainer
var _note: Label


func _ready() -> void:
	UIKit.root_rtl(self)
	UIKit.backdrop(self)
	var v := VBoxContainer.new()
	v.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(v)
	var h := UIKit.header(func(): Main.change_scene(MainMenuScreen.new()))
	h["title"].text = L10N.t("shop.title")
	v.add_child(h["row"])

	var sc := ScrollContainer.new()
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sc.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	v.add_child(sc)
	var box := VBoxContainer.new()
	box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	box.add_theme_constant_override("separation", 10)
	sc.add_child(box)

	# ---- soft currency section ----
	box.add_child(_section(L10N.t("shop.potions")))
	var potion_row := HBoxContainer.new()
	potion_row.add_theme_constant_override("separation", 8)
	var potion_p := UIKit.panel()
	potion_p.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	potion_row.add_child(potion_p)
	var pv := VBoxContainer.new()
	pv.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	potion_p.add_child(pv)
	pv.add_child(UIKit.label(GameDB.ITEMS["potion_health"]["name"]["fa"], 26, Globals.COL_TEXT, true))
	pv.add_child(UIKit.label(GameDB.ITEMS["potion_health"]["desc"]["fa"], 20, Globals.COL_TEXT_DIM))
	potion_row.add_child(UIKit.button("%s — %s" % [L10N.t("common.buy"), Globals.num(GameDB.ITEMS["potion_health"]["price"])], func():
		if SaveSystem.buy_potion():
			AudioManager.sfx("coin")))
	box.add_child(potion_row)

	# ---- IAP section ----
	box.add_child(_section(L10N.t("shop.gems") + " / " + L10N.t("shop.cosmetics")))
	_iap_box = VBoxContainer.new()
	_iap_box.add_theme_constant_override("separation", 8)
	box.add_child(_iap_box)

	_note = UIKit.label("", 20, Globals.COL_TEXT_DIM)
	box.add_child(_note)

	Billing.state_changed.connect(func(_s): _refresh_billing())
	Billing.products_loaded.connect(func(_p): _refresh_billing())
	Billing.purchase_succeeded.connect(_on_purchase_ok)
	Billing.purchase_failed.connect(_on_purchase_fail)
	Billing.purchase_canceled.connect(func(_p): _note.text = L10N.t("common.cancel"))
	_refresh_billing()


func _section(title: String) -> Control:
	var l := UIKit.label(title, 32, Globals.COL_TEAL, true)
	return l


func _refresh_billing() -> void:
	for c in _iap_box.get_children():
		c.queue_free()
	if Billing.is_disabled():
		_note.text = L10N.t("shop.billing_unavailable")
		for pid in ["gems_100", "gems_500", "gems_2500"]:
			_iap_box.add_child(_iap_row(pid, "—", true))
		return
	if Billing.products.is_empty():
		_note.text = L10N.t("shop.price_pending")
		Billing.request_products()
		return
	_note.text = ""
	for pid in GameDB.SHOP_PRODUCT_ORDER:
		var def: Dictionary = GameDB.PRODUCTS[pid]
		var owned: bool = def["type"] == "non_consumable" and SaveSystem.has_entitlement(pid)
		var price := Billing.product_price(pid)
		_iap_box.add_child(_iap_row(pid, price if price != "" else L10N.t("shop.price_pending"), owned))


func _iap_row(pid: String, price: String, owned: bool) -> Control:
	var def: Dictionary = GameDB.PRODUCTS[pid]
	var p := UIKit.panel()
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	p.add_child(row)
	var icon := TextureRect.new()
	icon.texture = load("res://assets/ui/icon_gem.png") if def["grant"].has("gems") else load("res://assets/ui/item_skin.png")
	icon.custom_minimum_size = Vector2(46, 46)
	icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	row.add_child(icon)
	var info := VBoxContainer.new()
	info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(info)
	var shop_key: String = {
		"gems_100": "shop.gems", "gems_500": "shop.gems", "gems_1200": "shop.gems",
		"gems_2500": "shop.gems", "gold_10000": "shop.gold_pack", "gold_50000": "shop.gold_pack",
		"remove_ads": "shop.remove_ads", "shadow_ninja_premium_skin": "shop.premium_skin",
		"legendary_katana_skin": "shop.katana_skin", "premium_cosmetic_bundle": "shop.bundle",
	}[pid]
	var grant_txt := ""
	if def["grant"].has("gems"):
		grant_txt = " +%s" % Globals.num(def["grant"]["gems"])
	if def["grant"].has("gold"):
		grant_txt = " +%s" % Globals.num(def["grant"]["gold"])
	info.add_child(UIKit.label(L10N.t(shop_key) + grant_txt, 26, Globals.COL_TEXT, true))
	var b := UIKit.button(price, func(): Billing.purchase(pid), true)
	if owned:
		b.disabled = true
		b.text = L10N.t("shop.purchased_before")
	elif Billing.is_disabled():
		b.disabled = true
	row.add_child(b)
	return p


func _on_purchase_ok(pid: String) -> void:
	_note.text = L10N.t("shop.purchased")
	AudioManager.sfx("level_up")
	_refresh_billing()


func _on_purchase_fail(_pid: String, reason: String) -> void:
	_note.text = L10N.t("common.cancel") if reason == "user_canceled" else reason
