class_name UIKit
## Shared UI kit: dark-fantasy styled panels, buttons, headers, chips.
## All text goes through L10N; roots get RTL layout for Persian.

const FONT := "res://assets/fonts/Vazirmatn-Medium.ttf"
const FONT_BOLD := "res://assets/fonts/Vazirmatn-Bold.ttf"
const FONT_BLACK := "res://assets/fonts/Vazirmatn-Black.ttf"

const C_BG := Color(0.03, 0.06, 0.07, 0.92)
const C_PANEL := Color(0.05, 0.10, 0.12, 0.96)
const C_EDGE := Color(0.23, 0.43, 0.44, 1.0)
const C_EDGE_HI := Color(0.35, 0.62, 0.62, 1.0)


static func style_panel() -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = C_PANEL
	sb.border_color = C_EDGE
	sb.set_border_width_all(2)
	sb.set_corner_radius_all(14)
	sb.set_content_margin_all(18)
	return sb


static func style_button(hi := false) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.07, 0.13, 0.15, 1.0) if not hi else Color(0.10, 0.20, 0.22, 1.0)
	sb.border_color = C_EDGE_HI if hi else C_EDGE
	sb.set_border_width_all(2)
	sb.set_corner_radius_all(12)
	sb.content_margin_left = 26
	sb.content_margin_right = 26
	sb.content_margin_top = 12
	sb.content_margin_bottom = 12
	return sb


static func root_rtl(c: Control) -> void:
	c.layout_direction = Control.LAYOUT_DIRECTION_RTL if L10N.locale == "fa" else Control.LAYOUT_DIRECTION_LTR


static func label(txt: String, size := 30, color := Globals.COL_TEXT, bold := false) -> Label:
	var l := Label.new()
	l.text = txt
	l.add_theme_font_override("font", load(FONT_BOLD if bold else FONT))
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	return l


static func title(txt: String) -> Label:
	var l := label(txt, 58, Globals.COL_TEXT, true)
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.8))
	l.add_theme_constant_override("outline_size", 8)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	return l


static func button(txt: String, cb: Callable, hi := false) -> Button:
	var b := Button.new()
	b.text = txt
	b.add_theme_font_override("font", load(FONT_BOLD))
	b.add_theme_font_size_override("font_size", 30)
	b.add_theme_color_override("font_color", Globals.COL_TEXT)
	b.add_theme_color_override("font_hover_color", Color(1, 1, 1))
	b.add_theme_color_override("font_pressed_color", Globals.COL_GOLD)
	b.add_theme_stylebox_override("normal", style_button(hi))
	b.add_theme_stylebox_override("hover", style_button(true))
	b.add_theme_stylebox_override("pressed", style_button(true))
	b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	b.custom_minimum_size = Vector2(220, 64)
	b.pressed.connect(func():
		AudioManager.sfx("ui_click", -6.0)
		cb.call())
	return b


static func panel() -> PanelContainer:
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", style_panel())
	return p


## Top navigation header: back button + title + currency chips.
static func header(on_back: Callable) -> Dictionary:
	var row := HBoxContainer.new()
	row.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	var back := button(L10N.t("common.back"), on_back)
	row.add_child(back)
	var t := label("", 34, Globals.COL_TEXT_DIM, true)
	t.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	row.add_child(t)
	var chips := HBoxContainer.new()
	chips.add_theme_constant_override("separation", 10)
	row.add_child(chips)
	var gold_icon := TextureRect.new()
	gold_icon.texture = load("res://assets/ui/icon_coin.png")
	gold_icon.custom_minimum_size = Vector2(36, 36)
	gold_icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	gold_icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	chips.add_child(gold_icon)
	var gold_l := label(Globals.num(int(SaveSystem.p()["gold"])), 26, Globals.COL_GOLD, true)
	chips.add_child(gold_l)
	var gem_icon := TextureRect.new()
	gem_icon.texture = load("res://assets/ui/icon_gem.png")
	gem_icon.custom_minimum_size = Vector2(36, 36)
	gem_icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	gem_icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	chips.add_child(gem_icon)
	var gem_l := label(Globals.num(int(SaveSystem.p()["gems"])), 26, Globals.COL_RED_HOT, true)
	chips.add_child(gem_l)
	SaveSystem.gold_changed.connect(func(v): gold_l.text = Globals.num(v))
	SaveSystem.gems_changed.connect(func(v): gem_l.text = Globals.num(v))
	return {"row": row, "title": t}


static func currency_chip(tex_path: String, getter: Callable) -> HBoxContainer:
	var h := HBoxContainer.new()
	var icon := TextureRect.new()
	icon.texture = load(tex_path)
	icon.custom_minimum_size = Vector2(40, 40)
	icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	h.add_child(icon)
	var l := label(Globals.num(int(getter.call())), 26, Globals.COL_TEXT, true)
	h.add_child(l)
	return h


## Fullscreen dark backdrop used by every screen.
static func backdrop(parent: Control, with_bg_image := true) -> Control:
	var c := Control.new()
	c.set_anchors_preset(Control.PRESET_FULL_RECT)
	parent.add_child(c)
	var rect := ColorRect.new()
	rect.color = C_BG
	rect.set_anchors_preset(Control.PRESET_FULL_RECT)
	c.add_child(rect)
	if with_bg_image:
		var s := TextureRect.new()
		s.texture = load("res://assets/backgrounds/sky_w1.png")
		s.set_anchors_preset(Control.PRESET_FULL_RECT)
		s.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		s.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
		s.modulate = Color(0.55, 0.62, 0.66)
		c.add_child(s)
		var fog := TextureRect.new()
		fog.texture = load("res://assets/backgrounds/fog_w1.png")
		fog.set_anchors_preset(Control.PRESET_FULL_RECT)
		fog.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		fog.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
		fog.modulate.a = 0.6
		c.add_child(fog)
	return c
