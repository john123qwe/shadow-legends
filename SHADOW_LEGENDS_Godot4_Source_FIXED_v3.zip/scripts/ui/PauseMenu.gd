extends Control
class_name PauseMenu
## In-game pause overlay.

var world: GameWorld


func _init(w: GameWorld = null) -> void:
	world = w


func _ready() -> void:
	UIKit.root_rtl(self)
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.72)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(dim)

	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(center)
	var p := UIKit.panel()
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 12)
	p.add_child(v)
	v.add_child(UIKit.title(L10N.t("game.pause")))
	v.add_child(UIKit.button(L10N.t("game.resume"), func(): _resume(), true))
	v.add_child(UIKit.button(L10N.t("game.restart"), func():
		get_tree().paused = false
		world.retry()))
	v.add_child(UIKit.button(L10N.t("game.quit_to_menu"), func():
		get_tree().paused = false
		SaveSystem.save_game()
		Main.change_scene(MainMenuScreen.new())))
	center.add_child(p)


func _resume() -> void:
	AudioManager.sfx("ui_click")
	get_tree().paused = false
	if world:
		world._pause_layer = null
	Main.close_overlay(get_parent())
