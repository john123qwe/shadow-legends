extends Control
class_name GameOverScreen
## Defeat overlay: retry / menu; shows abyss stats in endless mode.

var mode := "campaign"
var depth := 0
var score := 0
var world: GameWorld


func _init(m: String = "campaign", d: int = 0, s: int = 0, w: GameWorld = null) -> void:
	mode = m
	depth = d
	score = s
	world = w


func _ready() -> void:
	UIKit.root_rtl(self)
	var dim := ColorRect.new()
	dim.color = Color(0.08, 0.02, 0.03, 0.85)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(dim)
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(center)
	var p := UIKit.panel()
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 12)
	p.add_child(v)
	var t := UIKit.title(L10N.t("game.game_over"))
	t.add_theme_color_override("font_color", Globals.COL_RED_HOT)
	v.add_child(t)
	if mode == "endless":
		v.add_child(UIKit.label("%s: %s — %s: %s" % [L10N.t("game.abyss_depth"), Globals.num(depth), L10N.t("game.abyss_best"), Globals.num(score)], 28, Globals.COL_GOLD))
	v.add_child(UIKit.button(L10N.t("game.retry"), func(): world.retry(), true))
	v.add_child(UIKit.button(L10N.t("game.quit_to_menu"), func():
		SaveSystem.save_game()
		Main.change_scene(MainMenuScreen.new())))
	center.add_child(p)
