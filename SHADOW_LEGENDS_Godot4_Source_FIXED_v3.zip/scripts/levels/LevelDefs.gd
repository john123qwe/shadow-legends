class_name LevelDefs
## Authored level data for the campaign. Ground line y=900.
## Platform positions are top-left anchors of the silhouette sprites.
## Gap rules honor LevelBuilder.MAX_* so every jump is reachable.

const GY := 900.0


static func w1_l1() -> Dictionary:
	# Tutorial-ish approach through the forest: movement, double jump,
	# first wolves, one archer tower, spike flora, checkpoint, portal.
	return {
		"key": "w1_l1", "world": 1, "theme": "w1",
		"ground_y": GY, "length": 7600,
		"gold_reward": 120, "xp_reward": 60,
		"props": [
			[900, 480, "ruin_column"], [2600, 500, "ruin_column"],
			[4300, 540, "ruin_arch"], [6200, 500, "ruin_column"],
			[5200, 400, "vine_0"], [1500, 380, "vine_1"],
		],
		"platforms": [
			[-200, GY, "plat_wide"],
			[780, GY, "plat_mid"],
			[1420, GY, "plat_wide"],
			[2060, 700, "plat_float"],
			[2480, GY, "plat_wide"],
			[3120, GY, "plat_wide"],
			[3760, GY, "plat_edge_r"],
			[4180, 660, "plat_float"],
			[4620, GY, "plat_wide"],
			[5260, GY, "plat_mid"],
			[5900, GY, "plat_wide"],
			[6540, GY, "plat_edge_r"],
			[6960, GY, "plat_wide"],
		],
		"floats": [
			[2340, 560, "plat_float2"],
			[3320, 540, "plat_float"],
			[5560, 600, "plat_float2"],
		],
		"spikes": [
			[1180, 730, "spike_plant_small"],
			[2600, 730, "spike_plant"],
			[4200, 736, "spike_plant_small"],
			[5700, 730, "spike_plant"],
		],
		"floor_spikes": [
			[3480, GY - 84],
		],
		"enemies": [
			[1300, GY - 30, "shadow_wolf", 260],
			[2250, 640, "shadow_wolf", 200],
			[3300, GY - 30, "blood_archer", 160],
			[4900, GY - 30, "shadow_wolf", 300],
			[5400, GY - 30, "shadow_assassin", 240],
			[6300, GY - 30, "shadow_wolf", 220],
		],
		"coins": [
			[820, 800], [900, 800], [980, 800],
			[2200, 620], [2280, 620],
			[3380, 460], [3460, 460], [3540, 460],
			[4300, 580], [4380, 580],
			[6000, 800], [6080, 800],
		],
		"gems": [[2700, 780], [6100, 700]],
		"checkpoints": [[2480, GY - 60], [4620, GY - 60]],
		"portal": [7300, GY - 30],
	}


static func w1_l2() -> Dictionary:
	# Thorn Path: vertical float sections + more archers/assassins.
	return {
		"key": "w1_l2", "world": 1, "theme": "w1",
		"ground_y": GY, "length": 8200,
		"gold_reward": 180, "xp_reward": 90,
		"props": [
			[1200, 470, "ruin_column"], [3900, 520, "ruin_arch"],
			[6600, 480, "ruin_column"], [2400, 360, "vine_2"],
		],
		"platforms": [
			[-200, GY, "plat_wide"],
			[700, GY, "plat_mid"],
			[1300, 720, "plat_float"],
			[1700, 560, "plat_float"],
			[2100, GY, "plat_wide"],
			[2750, GY, "plat_edge_r"],
			[3150, 640, "plat_float"],
			[3560, GY, "plat_wide"],
			[4200, GY, "plat_wide"],
			[4840, GY, "plat_edge_r"],
			[5240, 620, "plat_float"],
			[5650, GY, "plat_wide"],
			[6300, GY, "plat_mid"],
			[6940, GY, "plat_edge_r"],
			[7000, GY, "plat_wide"],
		],
		"floats": [
			[900, 600, "plat_float2"],
			[4400, 560, "plat_float2"],
			[6000, 580, "plat_float"],
		],
		"spikes": [
			[900, 730, "spike_plant_small"],
			[2500, 736, "spike_plant"],
			[4600, 730, "spike_plant_small"],
			[6000, 736, "spike_plant"],
		],
		"floor_spikes": [
			[1580, GY - 84], [4020, GY - 84],
		],
		"enemies": [
			[950, GY - 30, "shadow_wolf", 240],
			[1900, 500, "blood_archer", 140],
			[2400, GY - 30, "shadow_assassin", 260],
			[3300, 580, "blood_archer", 140],
			[3900, GY - 30, "shadow_wolf", 320],
			[4500, 500, "shadow_assassin", 180],
			[5300, GY - 30, "blood_archer", 160],
			[6100, GY - 30, "shadow_wolf", 280],
			[6800, GY - 30, "shadow_assassin", 200],
		],
		"coins": [
			[1000, 520], [1080, 520],
			[1400, 640], [1480, 640],
			[1800, 480], [1880, 480],
			[3250, 560], [3330, 560],
			[5320, 540], [5400, 540],
			[6100, 500], [6180, 500],
		],
		"gems": [[1760, 480], [5900, 760]],
		"checkpoints": [[2100, GY - 60], [5650, GY - 60]],
		"portal": [7900, GY - 30],
	}


static func w1_l3() -> Dictionary:
	# The Lord's Approach: gauntlet + boss arena at the end.
	return {
		"key": "w1_l3", "world": 1, "theme": "w1",
		"ground_y": GY, "length": 5600,
		"gold_reward": 260, "xp_reward": 150,
		"props": [
			[800, 460, "ruin_arch"], [2200, 470, "ruin_column"],
			[3400, 480, "ruin_arch"], [4900, 460, "ruin_column"],
		],
		"platforms": [
			[-200, GY, "plat_wide"],
			[620, GY, "plat_mid"],
			[1180, 680, "plat_float"],
			[1580, GY, "plat_wide"],
			[2200, GY, "plat_wide"],
			[2840, GY, "plat_edge_r"],
			[3240, 640, "plat_float"],
			[3640, GY, "plat_wide"],
			[4280, GY, "plat_wide"],
			[4920, GY, "plat_edge_r"],
			[5200, GY, "plat_wide"],
			[5840, GY, "plat_edge_r"],
		],
		"floats": [
			[2700, 560, "plat_float2"],
			[4600, 580, "plat_float"],
		],
		"spikes": [
			[800, 730, "spike_plant_small"],
			[2000, 736, "spike_plant"],
			[3600, 730, "spike_plant_small"],
			[4400, 736, "spike_plant"],
		],
		"floor_spikes": [[1020, GY - 84], [3060, GY - 84]],
		"enemies": [
			[900, GY - 30, "shadow_wolf", 220],
			[1700, GY - 30, "shadow_assassin", 240],
			[2100, 620, "blood_archer", 150],
			[3000, GY - 30, "dark_knight", 200],
			[3900, GY - 30, "shadow_wolf", 260],
			[4700, GY - 30, "shadow_assassin", 220],
		],
		"coins": [
			[1300, 600], [1380, 600],
			[2800, 480], [2880, 480],
			[5000, 800], [5080, 800],
		],
		"gems": [[3350, 560], [5100, 760]],
		"checkpoints": [[1580, GY - 60], [3640, GY - 60]],
		"boss": [6300, GY - 120],
		"portal": null,
	}


static func get_campaign(world: int, level: int) -> Dictionary:
	match "%d_%d" % [world, level]:
		"1_1": return w1_l1()
		"1_2": return w1_l2()
		"1_3": return w1_l3()
	return w1_l1()
