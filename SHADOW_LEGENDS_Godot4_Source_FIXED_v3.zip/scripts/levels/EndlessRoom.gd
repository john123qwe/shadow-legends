extends GameWorld
class_name EndlessRoom
## One Endless Abyss room. Chains portal -> next room, carrying score/hp.

var depth := 1
var score := 0
var hp_frac := 1.0


func _init() -> void:
	mode = "endless"
	abyss_depth = depth
	abyss_score = score


func _ready() -> void:
	abyss_depth = depth
	abyss_score = score
	super._ready()
	if hp_frac < 1.0:
		player.hp = clampf(player.max_hp * hp_frac, 20.0, player.max_hp)
		player.health_changed.emit(player.hp, player.max_hp)


func portal_entered() -> void:
	if _finished:
		return
	_finished = true
	var next := EndlessRoom.new()
	next.depth = abyss_depth + 1
	next.score = abyss_score + GameDB.ABYSS["score_per_room"]
	next.hp_frac = player.hp / player.max_hp
	SaveSystem.record_abyss_run(abyss_depth, abyss_score)
	AudioManager.sfx("portal", -4.0)
	Main.change_scene(next)


func _on_player_died() -> void:
	if _finished:
		return
	_finished = true
	SaveSystem.record_abyss_run(abyss_depth, abyss_score)
	AudioManager.play_music("sting_defeat", 0.5)
	await get_tree().create_timer(1.6).timeout
	_overlay_layer = Main.build_overlay(GameOverScreen.new("endless", abyss_depth, abyss_score, self))
