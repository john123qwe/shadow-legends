class_name LevelBuilder
## Builds a playable level (platforms, traps, enemies, pickups, checkpoints,
## exit portal) from a LevelDef dictionary. Levels are data-driven so the
## Endless Abyss can assemble rooms from the same primitives.

const ENV := "res://assets/environments/"
const BG := "res://assets/backgrounds/"

## Jump reach budgets (px), derived from Player.gd physics constants
## (JUMP_V=1180, GRAVITY=2000, FALL_MULT=1.35, move_speed=420, dash
## 1300px/s for 0.17s) with a ~10% safety margin, then verified by
## tests/run_checks.gd against every campaign level and abyss room:
##   single jump: airtime 0.837s -> 352px gap, 202px rise
##   double jump: airtime 1.287s -> 541px gap, 405px rise
##   double jump + mid-air dash: ~762px gap
const MAX_SINGLE_JUMP_GAP := 360.0
const MAX_DOUBLE_JUMP_GAP := 540.0
const MAX_CHAIN_GAP := 760.0
const MAX_DOUBLE_JUMP_RISE := 430.0

## Collision widths (px) of the platform sprites — platforms are placed by
## TOP-LEFT corner (see _make_platform), and the collision box is
## texture_width - 8 wide. Validation must measure real gaps, not the
## distance between platform left edges.
const PLATFORM_WIDTHS := {
	"plat_wide": 1016.0, "plat_wide2": 1016.0,
	"plat_mid": 632.0, "plat_small": 312.0,
	"plat_float": 352.0, "plat_float2": 292.0,
	"plat_edge_l": 504.0, "plat_edge_r": 504.0,
}


static func tex(env_name: String) -> Texture2D:
	return load(ENV + env_name + ".png")


static func platform_texture(name: String) -> Texture2D:
	return load(ENV + name + ".png")


static func build(root: Node2D, def: Dictionary) -> Dictionary:
	# returns {portal: Area2D, checkpoints: [Area2D], player_start: Vector2}
	var out := {"portal": null, "checkpoints": [], "player_start": Vector2(200, def.get("ground_y", 900) - 40)}
	var gy: float = def.get("ground_y", 900)

	# ---- decorative props behind gameplay ----
	for p in def.get("props", []):
		var s := Sprite2D.new()
		s.texture = tex(p[2])
		s.position = Vector2(p[0], p[1])
		s.z_index = -5
		root.add_child(s)

	# ---- ground platforms: [x, y, texture, mirrored] ----
	for pl in def.get("platforms", []):
		_make_platform(root, Vector2(pl[0], pl[1]), pl[2], pl.size() > 3 and pl[3])

	for fl in def.get("floats", []):
		_make_platform(root, Vector2(fl[0], fl[1]), fl[2], false)

	# ---- traps ----
	for sp in def.get("spikes", []):
		_make_spike(root, Vector2(sp[0], sp[1]), sp[2])

	for fs in def.get("floor_spikes", []):
		_make_floor_spikes(root, Vector2(fs[0], fs[1]))

	# ---- pickups ----
	for c in def.get("coins", []):
		var coin := Area2D.new()
		coin.collision_layer = Globals.L_PICKUP
		coin.collision_mask = Globals.L_PLAYER
		coin.position = Vector2(c[0], c[1])
		var s := Sprite2D.new()
		s.texture = load("res://assets/ui/icon_coin.png")
		coin.add_child(s)
		var col := CollisionShape2D.new()
		var sh := CircleShape2D.new()
		sh.radius = 30.0
		col.shape = sh
		coin.add_child(col)
		coin.body_entered.connect(func(body):
			if body is Player:
				SaveSystem.add_gold(25)
				AudioManager.sfx("coin", -4.0)
				coin.queue_free())
		_place_coin_float(coin)
		root.add_child(coin)

	for g in def.get("gems", []):
		var gem := Area2D.new()
		gem.collision_layer = Globals.L_PICKUP
		gem.collision_mask = Globals.L_PLAYER
		gem.position = Vector2(g[0], g[1])
		var gs := Sprite2D.new()
		gs.texture = load("res://assets/ui/icon_gem.png")
		gem.add_child(gs)
		var gcol := CollisionShape2D.new()
		var gsh := CircleShape2D.new()
		gsh.radius = 30.0
		gcol.shape = gsh
		gem.add_child(gcol)
		gem.body_entered.connect(func(body):
			if body is Player:
				SaveSystem.add_gems(1)
				AudioManager.sfx("gem", -4.0)
				gem.queue_free())
		root.add_child(gem)

	# ---- checkpoints ----
	for cp in def.get("checkpoints", []):
		var a := _make_checkpoint(root, Vector2(cp[0], cp[1]))
		out["checkpoints"].append(a)

	# ---- exit portal ----
	if def.has("portal"):
		var portal := _make_portal(root, Vector2(def["portal"][0], def["portal"][1]))
		out["portal"] = portal

	# ---- enemies: [x, y, kind, patrol_span] ----
	out["enemy_spawns"] = def.get("enemies", [])
	out["boss_spawn"] = def.get("boss", null)
	out["bounds"] = Vector2(-400, def.get("length", 6000) + 400)
	return out


static func _place_coin_float(_c: Area2D) -> void:
	pass


static func _make_platform(root: Node2D, pos: Vector2, tex_name: String, mirrored: bool) -> void:
	var s := Sprite2D.new()
	var texture := platform_texture(tex_name)
	s.texture = texture
	s.centered = true
	s.position = pos + Vector2(texture.get_width() / 2.0, texture.get_height() / 2.0 - 0)  # pos = top-left
	s.z_index = 2
	if mirrored:
		s.flip_h = true
	root.add_child(s)

	var body := StaticBody2D.new()
	body.collision_layer = Globals.L_WORLD
	body.position = pos + Vector2(texture.get_width() / 2.0, 0)
	var col := CollisionShape2D.new()
	var shape := RectangleShape2D.new()
	# collision covers the upper mass of the silhouette art
	var h := minf(texture.get_height() * 0.55, 130.0)
	shape.size = Vector2(texture.get_width() - 8, h)
	col.shape = shape
	col.position = Vector2(0, h / 2.0)
	body.add_child(col)
	root.add_child(body)


static func _make_spike(root: Node2D, pos: Vector2, tex_name: String) -> void:
	var s := Sprite2D.new()
	var texture := tex(tex_name)
	s.texture = texture
	s.position = pos + Vector2(texture.get_width() / 2.0, texture.get_height() / 2.0)
	s.z_index = 3
	root.add_child(s)
	var area := Area2D.new()
	area.collision_layer = Globals.L_TRAP
	area.collision_mask = Globals.L_PLAYER
	area.position = s.position + Vector2(0, -texture.get_height() * 0.3)
	var col := CollisionShape2D.new()
	var shape := RectangleShape2D.new()
	shape.size = Vector2(texture.get_width() * 0.6, texture.get_height() * 0.55)
	col.shape = shape
	area.add_child(col)
	area.set_meta("damage", 22.0)
	area.set_meta("source", area.global_position)
	root.add_child(area)


static func _make_floor_spikes(root: Node2D, pos: Vector2) -> void:
	var texture := tex("floor_spikes")
	var s := Sprite2D.new()
	s.texture = texture
	s.position = pos + Vector2(texture.get_width() / 2.0, texture.get_height() / 2.0)
	s.z_index = 3
	root.add_child(s)
	var area := Area2D.new()
	area.collision_layer = Globals.L_TRAP
	area.collision_mask = Globals.L_PLAYER
	area.position = s.position + Vector2(0, -14)
	var col := CollisionShape2D.new()
	var shape := RectangleShape2D.new()
	shape.size = Vector2(texture.get_width() - 10, 56)
	col.shape = shape
	area.add_child(col)
	area.set_meta("damage", 26.0)
	area.set_meta("source", area.global_position)
	root.add_child(area)


static func _make_checkpoint(root: Node2D, pos: Vector2) -> Area2D:
	var area := Area2D.new()
	area.collision_layer = Globals.L_TRIGGER
	area.collision_mask = Globals.L_PLAYER
	area.position = pos
	var s := Sprite2D.new()
	s.texture = tex("checkpoint_off")
	s.position = Vector2(0, -80)
	area.add_child(s)
	var col := CollisionShape2D.new()
	var shape := RectangleShape2D.new()
	shape.size = Vector2(160, 220)
	col.shape = shape
	col.position = Vector2(0, -80)
	area.add_child(col)
	area.set_meta("activated", false)
	area.set_meta("sprite", s)
	area.body_entered.connect(func(body):
		if body is Player and not area.get_meta("activated"):
			area.set_meta("activated", true)
			s.texture = tex("checkpoint_on")
			AudioManager.sfx("checkpoint", -4.0)
			area.get_parent().get_parent().set_checkpoint(pos))
	root.add_child(area)
	return area


static func _make_portal(root: Node2D, pos: Vector2) -> Area2D:
	var area := Area2D.new()
	area.collision_layer = Globals.L_TRIGGER
	area.collision_mask = Globals.L_PLAYER
	area.position = pos
	var s := Sprite2D.new()
	s.texture = Vfx.tex("portal")
	s.position = Vector2(0, -100)
	area.add_child(s)
	var col := CollisionShape2D.new()
	var shape := RectangleShape2D.new()
	shape.size = Vector2(130, 220)
	col.shape = shape
	col.position = Vector2(0, -100)
	area.add_child(col)
	# idle swirl
	var tw := s.create_tween().set_loops()
	tw.tween_property(s, "rotation", PI * 2.0, 8.0).from(0.0)
	area.set_meta("sprite", s)
	area.body_entered.connect(func(body):
		if body is Player:
			area.set_deferred("monitoring", false)
			var gp := area.get_parent().get_parent()
			if gp.has_method("portal_entered"):
				gp.portal_entered())
	root.add_child(area)
	return area


## Static parallax background stack for a theme.
static func build_background(parent: Node, theme_tag: String) -> void:
	var pb := ParallaxBackground.new()
	parent.add_child(pb)
	var defs := [
		["sky_" + theme_tag, 0.0, 0, true],
		["far_" + theme_tag, 0.15, -6, false],
		["mid_" + theme_tag, 0.3, -12, false],
		["fog_" + theme_tag, 0.55, -4, false],
	]
	for d in defs:
		var layer := ParallaxLayer.new()
		layer.motion_scale = Vector2(d[1], d[1] * 0.4)
		layer.motion_mirroring = Vector2(1920, 0) if d[3] else Vector2.ZERO
		var spr := Sprite2D.new()
		spr.texture = load(BG + d[0] + ".png")
		spr.centered = false
		spr.position = Vector2(0, d[2])
		# Lift dark-fantasy backgrounds so platforms and enemies remain readable
		# on phone screens without washing out the red/teal effects.
		if str(d[0]).begins_with("sky_"):
			spr.modulate = Color(1.28, 1.28, 1.28, 1.0)
		elif str(d[0]).begins_with("far_"):
			spr.modulate = Color(1.55, 1.55, 1.55, 1.0)
		elif str(d[0]).begins_with("mid_"):
			spr.modulate = Color(1.65, 1.65, 1.65, 1.0)
		else:
			spr.modulate = Color(1.35, 1.35, 1.35, 1.0)
		layer.add_child(spr)
		pb.add_child(layer)


## Foreground near-foliage layer (drawn over the action, thin alpha).
static func build_foreground(parent: Node) -> void:
	var fl := ParallaxLayer.new()
	fl.motion_scale = Vector2(0.85, 0.5)
	fl.motion_mirroring = Vector2(1920, 0)
	var spr := Sprite2D.new()
	spr.texture = load(BG + "near_w1.png")
	spr.centered = false
	spr.modulate.a = 0.38
	fl.add_child(spr)
	parent.find_children("*", "ParallaxBackground", true, false)[0].add_child(fl)


## Fairness validation: consecutive platform gaps must be reachable.
## Prints warnings (CI/test script calls this; see tests/).
static func validate(def: Dictionary) -> Array[String]:
	var issues: Array[String] = []
	var tops: Array = []
	for pl in def.get("platforms", []):
		var w: float = PLATFORM_WIDTHS.get(pl[2], 320.0)
		tops.append({"x": float(pl[0]), "y": float(pl[1]), "w": w})
	for fl in def.get("floats", []):
		var w: float = PLATFORM_WIDTHS.get(fl[2], 320.0)
		tops.append({"x": float(fl[0]), "y": float(fl[1]), "w": w})
	tops.sort_custom(func(a, b): return a["x"] < b["x"])
	for i in range(tops.size() - 1):
		var a: Dictionary = tops[i]
		var b: Dictionary = tops[i + 1]
		# real gap: from the right edge of a's collision box to b's left edge
		var gap: float = b["x"] - (a["x"] + a["w"])
		var dy: float = a["y"] - b["y"]  # positive = next platform is higher
		var limit: float = MAX_DOUBLE_JUMP_GAP
		if dy <= -300.0:
			limit = MAX_CHAIN_GAP  # dropping far: airtime (and reach) grows
		elif dy > 0.0:
			# rising costs horizontal reach: subtract the rise from the budget
			limit = MAX_DOUBLE_JUMP_GAP - dy
		if gap > limit:
			issues.append("gap too large at x=%d -> %d (%dpx)" % [a["x"], b["x"], gap])
		if dy > MAX_DOUBLE_JUMP_RISE:
			issues.append("rise too high at x=%d -> %d (%dpx)" % [a["x"], b["x"], dy])
	return issues
