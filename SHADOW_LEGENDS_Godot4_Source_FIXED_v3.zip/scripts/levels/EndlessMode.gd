class_name EndlessMode
## Endless Abyss room generator. Rooms are stitched from hand-authored
## templates; every room is validated for reachability (fair jumps only),
## difficulty scales with depth, every 4th room spawns the boss.

const GY := 900.0

## Room templates. Each is a platform/enemy/trap layout in local coords.
## Rooms always end with flat ground so the exit portal sits on solid floor.
const TEMPLATES := [
	{
		"len": 3200, "w": 1,
		"platforms": [
			[-200, GY, "plat_wide"], [880, GY, "plat_mid"],
			[1560, 660, "plat_float"], [2000, GY, "plat_wide"],
			[2640, GY, "plat_wide"],
		],
		"floats": [[1240, 540, "plat_float2"]],
		"enemies": [[1100, GY - 30, "shadow_wolf", 220], [2300, GY - 30, "blood_archer", 160]],
		"spikes": [[1800, 730, "spike_plant_small"]],
	},
	{
		"len": 3400, "w": 2,
		"platforms": [
			[-200, GY, "plat_wide"], [760, GY, "plat_edge_r"],
			[1160, 620, "plat_float"], [1560, GY, "plat_wide"],
			[2200, GY, "plat_wide"], [2840, GY, "plat_wide"],
		],
		"floats": [[2680, 560, "plat_float"]],
		"enemies": [[1800, GY - 30, "shadow_assassin", 240], [2500, GY - 30, "dark_knight", 200]],
		"spikes": [[2100, 730, "spike_plant"]],
		"floor_spikes": [[1000, GY - 84]],
	},
	{
		"len": 3600, "w": 2,
		"platforms": [
			[-200, GY, "plat_wide"], [820, GY, "plat_mid"],
			[1500, 700, "plat_float"], [1500, GY, "plat_wide"],
			[2140, 600, "plat_float"], [2580, GY, "plat_wide"],
			[3220, GY, "plat_mid"],
		],
		"enemies": [[1200, GY - 30, "abyss_mage", 180], [2300, GY - 30, "shadow_wolf", 260],
					[2900, GY - 30, "blood_archer", 180]],
		"spikes": [[900, 730, "spike_plant_small"], [2400, 730, "spike_plant"]],
	},
	{
		"len": 3200, "w": 1,
		"platforms": [
			[-200, GY, "plat_wide"], [700, 640, "plat_float"],
			[1100, 500, "plat_float"], [1500, 640, "plat_float"],
			[1900, GY, "plat_wide"], [2540, GY, "plat_wide"],
		],
		"enemies": [[1000, 440, "blood_archer", 120], [2200, GY - 30, "shadow_assassin", 220]],
		"coins": [[780, 560], [1180, 420], [1580, 560]],
	},
	{
		"len": 3000, "w": 1,
		"platforms": [
			[-200, GY, "plat_wide"], [840, GY, "plat_wide"],
			[1480, GY, "plat_mid"], [2040, GY, "plat_wide"],
		],
		"enemies": [[1200, GY - 30, "dark_knight", 200], [1800, GY - 30, "shadow_wolf", 200],
					[2300, GY - 30, "shadow_wolf", 180]],
		"spikes": [[1000, 730, "spike_plant"], [1700, 730, "spike_plant_small"]],
	},
	{
		"len": 3800, "w": 3,
		"platforms": [
			[-200, GY, "plat_wide"], [620, GY, "plat_mid"],
			[1180, 660, "plat_float"], [1620, GY, "plat_wide"],
			[2260, GY, "plat_edge_r"], [2660, 580, "plat_float"],
			[3060, GY, "plat_wide"], [3700, GY, "plat_wide"],
		],
		"enemies": [[1000, GY - 30, "abyss_mage", 180], [1900, GY - 30, "shadow_assassin", 220],
					[2800, 520, "blood_archer", 140], [3400, GY - 30, "dark_knight", 200]],
		"spikes": [[800, 730, "spike_plant_small"], [2000, 730, "spike_plant"]],
		"floor_spikes": [[1440, GY - 84]],
	},
]


static func room_def(depth: int) -> Dictionary:
	var rng := RandomNumberGenerator.new()
	rng.seed = hash("abyss-%d" % depth)
	var template: Dictionary = TEMPLATES[rng.randi_range(0, TEMPLATES.size() - 1)]
	var is_boss_room := depth % GameDB.ABYSS["rooms_per_boss"] == 0
	var def := {
		"key": "abyss_%d" % depth, "world": 2, "theme": "w2",
		"ground_y": GY, "length": template["len"],
		"gold_reward": 0, "xp_reward": 0,
		"props": [],
		"platforms": [],
		"floats": [],
		"spikes": [],
		"floor_spikes": [],
		"enemies": [],
		"coins": [],
		"gems": [],
		"checkpoints": [],
		"portal": [template["len"] - 200, GY - 30],
	}
	# copy layout, shifting platforms to guarantee portal ground continuity
	for p in template.get("platforms", []):
		def["platforms"].append([p[0], p[1], p[2]])
	for f in template.get("floats", []):
		def["floats"].append([f[0], f[1], f[2]])
	for s in template.get("spikes", []):
		def["spikes"].append([s[0], s[1], s[2]])
	for fs in template.get("floor_spikes", []):
		def["floor_spikes"].append([fs[0], fs[1]])
	for c in template.get("coins", []):
		def["coins"].append([c[0], c[1]])
	if is_boss_room:
		def["enemies"] = []
		def["boss"] = [template["len"] - 700, GY - 120]
		def["portal"] = [template["len"] - 120, GY - 30]
		# guaranteed flat runway for the boss
		def["platforms"].append([template["len"] - 1400, GY, "plat_wide"])
		def["platforms"].append([template["len"] - 764, GY, "plat_wide"])
		def["spikes"] = []
		def["floor_spikes"] = []
	else:
		# scaled enemy pool: mix per depth band
		var pool: Array = ["shadow_wolf", "blood_archer", "shadow_assassin"]
		if depth >= 3:
			pool.append("abyss_mage")
		if depth >= 5:
			pool.append("dark_knight")
		var n := clampi(2 + depth / 2, 2, 5)
		for i in range(n):
			var ex: float = template["len"] * (0.25 + 0.15 * i) + rng.randf_range(-60, 60)
			var ek: String = pool[rng.randi_range(0, pool.size() - 1)]
			def["enemies"].append([ex, GY - 30, ek, 240])
	# coin sprinkle
	for i in range(3 + rng.randi_range(0, 3)):
		def["coins"].append([rng.randf_range(300, template["len"] - 400), GY - 160])
	if depth % 2 == 0:
		def["gems"].append([template["len"] - 600, GY - 120])
	return def


static func validate_room(def: Dictionary) -> Array[String]:
	return LevelBuilder.validate(def)


static func score_for(depth: int, kills: int) -> int:
	return depth * GameDB.ABYSS["score_per_room"] + kills * 40
