extends Node2D
class_name GameWorld
## Gameplay scene root: builds the level, spawns the player/camera/HUD/controls,
## and owns the campaign <-> endless flows, pause, checkpoints, victory/defeat.

var mode := "campaign"            # "campaign" | "endless"
var world_idx := 1
var level_idx := 1
var abyss_depth := 1
var abyss_score := 0
var abyss_run_kills := 0

var level_root: Node2D
var player: Player
var camera: CameraController
var hud: HUD
var touch: TouchControls
var def: Dictionary
var checkpoint_pos := Vector2.ZERO
var deaths_this_run := 0
var _paused := false
var _finished := false
var _pause_layer: CanvasLayer
var _overlay_layer: CanvasLayer
var enemies_alive := 0


func setup_campaign(w: int, l: int) -> void:
	mode = "campaign"
	world_idx = w
	level_idx = l


func setup_endless(depth: int, score: int, keep_hp: float) -> void:
	mode = "endless"
	abyss_depth = depth
	abyss_score = score


func _ready() -> void:
	if mode == "campaign":
		def = LevelDefs.get_campaign(world_idx, level_idx)
	else:
		def = EndlessMode.room_def(abyss_depth)
	AudioManager.play_music(GameDB.WORLDS[world_idx - 1]["ambience"] if mode == "campaign" else "amb_cave")

	level_root = Node2D.new()
	add_child(level_root)
	LevelBuilder.build_background(self, GameDB.WORLDS[world_idx - 1]["theme"])
	var built := LevelBuilder.build(level_root, def)
	LevelBuilder.build_foreground(self)
	if mode == "endless":
		EventBus.abyss_depth_reached.emit(abyss_depth)

	# world bounds walls
	_make_wall(built["bounds"].x - 200)
	_make_wall(built["bounds"].y + 200)

	# player
	player = Player.new()
	player.add_to_group("player")
	player.global_position = built["player_start"]
	player.died.connect(_on_player_died)
	add_child(player)
	checkpoint_pos = player.global_position

	camera = CameraController.new()
	add_child(camera)
	camera.set_target(player)
	player.set_camera(camera)
	camera.limit_left = int(built["bounds"].x)
	camera.limit_right = int(built["bounds"].y)

	# enemies
	for e in built["enemy_spawns"]:
		_spawn_enemy(e[0], e[1], e[2], e[3])

	# boss (campaign w1_l3 / endless boss rooms)
	if built["boss_spawn"] != null and not _finished:
		var bs: Array = built["boss_spawn"]
		_spawn_boss(bs[0], bs[1])

	# touch controls + HUD
	touch = TouchControls.new()
	add_child(touch)
	hud = HUD.new()
	add_child(hud)
	hud.bind_player(player)

	EventBus.hitstop_requested.connect(_hitstop)
	SaveSystem.add_playtime(0.0)

	# tutorial hints on the first level
	if mode == "campaign" and world_idx == 1 and level_idx == 1:
		hud.toast(L10N.t("game.tutorial_move"))
		get_tree().create_timer(3.5).timeout.connect(func(): hud.toast(L10N.t("game.tutorial_attack")))

	if mode == "endless":
		hud.toast(L10N.t("game.abyss_depth") + " " + Globals.num(abyss_depth))


func _make_wall(x: float) -> void:
	var body := StaticBody2D.new()
	body.collision_layer = Globals.L_WORLD
	body.global_position = Vector2(x, 0)
	var col := CollisionShape2D.new()
	var shape := RectangleShape2D.new()
	shape.size = Vector2(80, 4000)
	col.shape = shape
	body.add_child(col)
	add_child(body)


func _spawn_enemy(x: float, y: float, kind: String, span: float) -> void:
	var scale_mult := 1.0
	if mode == "endless":
		scale_mult = GameDB.enemy_scale(1, 1, abyss_depth)
	else:
		scale_mult = GameDB.enemy_scale(world_idx, level_idx)
	var e := _enemy_node(kind)
	if e == null:
		return
	e.configure(kind, scale_mult, float(span))
	e.global_position = Vector2(x, y)
	e.player = player
	e.died_signal.connect(func():
		abyss_run_kills += 1
		if mode == "endless":
			abyss_score += GameDB.ABYSS["score_per_room"] / 4)
	add_child(e)


func _enemy_node(kind: String) -> EnemyBase:
	match kind:
		"shadow_wolf": return ShadowWolf.new()
		"dark_knight": return DarkKnight.new()
		"blood_archer": return BloodArcher.new()
		"abyss_mage": return AbyssMage.new()
		"shadow_assassin": return ShadowAssassin.new()
		_: return null


func _spawn_boss(x: float, y: float) -> void:
	var b := AbyssLord.new()
	b.configure("abyss_lord", 1.0, 600.0)
	b.global_position = Vector2(x, y)
	b.player = player
	add_child(b)
	camera.pan_to(Vector2(x, y - 140), 1.6)
	b.entrance()


func set_checkpoint(pos: Vector2) -> void:
	checkpoint_pos = pos
	hud.toast(L10N.t("game.checkpoint"))


func _hitstop(dur: float) -> void:
	Engine.time_scale = 0.05
	get_tree().create_timer(dur, true, false, true).timeout.connect(func():
		Engine.time_scale = 1.0)


func portal_entered() -> void:
	if _finished:
		return
	_finished = true
	if mode == "campaign":
		var stars := 3 if deaths_this_run == 0 else (2 if deaths_this_run <= 2 else 1)
		SaveSystem.complete_level(def["key"], stars, int(def["gold_reward"]), int(def["xp_reward"]))
		AudioManager.play_music("sting_victory", 0.4)
		player.set_victory()
		_overlay_layer = Main.build_overlay(VictoryScreen.new(def, stars, self))
	else:
		AudioManager.play_music("sting_victory", 0.4)
		SaveSystem.record_abyss_run(abyss_depth, abyss_score)
		var keep_hp := player.hp / player.max_hp
		var next := EndlessRoom.new()
		next.depth = abyss_depth + 1
		next.score = abyss_score + GameDB.ABYSS["score_per_room"]
		next.hp_frac = keep_hp
		Main.change_scene(next)


func _on_player_died() -> void:
	if _finished:
		return
	_finished = true
	deaths_this_run += 1
	SaveSystem.record_abyss_run(abyss_depth, abyss_score) if mode == "endless" else null
	AudioManager.play_music("sting_defeat", 0.5)
	await get_tree().create_timer(1.6).timeout
	var over := GameOverScreen.new(mode, abyss_depth, abyss_score, self)
	_overlay_layer = Main.build_overlay(over)


func retry() -> void:
	var next: GameWorld
	if mode == "campaign":
		next = GameWorld.new()
		next.setup_campaign(world_idx, level_idx)
	else:
		next = EndlessRoom.new()
		next.depth = 1
		next.score = 0
		next.hp_frac = 1.0
	Main.change_scene(next)


func to_menu() -> void:
	Main.change_scene(MainMenuScreen.new())


# ---------------------------------------------------------------------------
# pause handling
# ---------------------------------------------------------------------------
func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("pause") or (touch and touch.consume_pause()):
		_toggle_pause()


func _toggle_pause() -> void:
	if _finished:
		return
	_paused = not _paused
	get_tree().paused = _paused
	if _paused:
		AudioManager.sfx("ui_click")
		_pause_layer = Main.build_overlay(PauseMenu.new(self))
	else:
		if _pause_layer:
			_pause_layer.queue_free()
			_pause_layer = null
