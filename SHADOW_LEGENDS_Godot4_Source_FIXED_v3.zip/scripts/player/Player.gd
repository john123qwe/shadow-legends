extends CharacterBody2D
class_name Player
## SHADOW NINJA — movement, double jump, shadow dash, 3-hit katana combo,
## special attack, hurt/death/victory. Stats come from SaveSystem attributes.

signal health_changed(hp: float, max_hp: float)
signal special_changed(charge: float)      # 0..1
signal dash_cd_changed(frac: float)        # 0..1 (1 = ready)
signal died
signal combo_changed(hits: int)

enum ST { MOVE, DASH, ATTACK, SPECIAL, HURT, DEAD, VICTORY }

const SF := "res://assets/characters/ninja_sheet.png"

# --- movement tuning ---
const ACCEL := 3000.0
const AIR_ACCEL := 2100.0
const FRICTION := 3400.0
const JUMP_V := -1180.0
const JUMP_CUT := 0.72
const GRAVITY := 2000.0
const FALL_MULT := 1.35
const MAX_FALL := 1500.0
const COYOTE := 0.11
const BUFFER := 0.13
const DASH_SPEED := 1300.0
const DASH_TIME := 0.17
const DASH_CD := 1.0
const COMBO_WINDOW := 0.42

# --- combat ---
var max_hp := 100.0
var hp := 100.0
var defense := 4.0
var crit_chance := 0.08
var crit_damage := 1.6
var move_speed := 420.0
var invuln_t := 0.0
var dash_cd_t := 0.0
var special_charge := 0.0
const SPECIAL_COST := 100.0
const SPECIAL_GAIN_PER_HIT := 12.0
const SPECIAL_GAIN_ON_KILL := 22.0

# --- state ---
var st: int = ST.MOVE
var facing := 1
var coyote_t := 0.0
var jump_buffer_t := 0.0
var jumps_left := 2
var dash_t := 0.0
var dash_dir := Vector2.RIGHT
var attack_index := 0
var attack_buffered := false
var combo_reset_t := 0.0
var combo_hits := 0
var _hit_this_swing: Array = []
var _spawn_ghost_t := 0.0
var dead_handled := false
var victory := false

var sprite: AnimatedSprite2D
var hitbox: Area2D
var hurtbox: Area2D
var trail: Line2D
var camera: CameraController


func _ready() -> void:
	collision_layer = Globals.L_PLAYER
	collision_mask = Globals.L_WORLD
	floor_snap_length = 8.0

	sprite = AnimatedSprite2D.new()
	sprite.sprite_frames = SpriteLib.ninja()
	sprite.position = Vector2(0, -50)
	sprite.scale = Vector2(1.05, 1.05)
	sprite.animation_finished.connect(_on_anim_finished)
	sprite.frame_changed.connect(_on_frame_changed)
	add_child(sprite)
	sprite.play("idle")

	var col := CollisionShape2D.new()
	var shape := RectangleShape2D.new()
	shape.size = Vector2(40, 96)
	col.shape = shape
	col.position = Vector2(0, -48)
	add_child(col)

	# attack hitbox (enabled during swings)
	hitbox = Area2D.new()
	hitbox.collision_layer = 0
	hitbox.collision_mask = Globals.L_ENEMY
	hitbox.monitoring = false
	var hcol := CollisionShape2D.new()
	var hshape := RectangleShape2D.new()
	hshape.size = Vector2(168, 104)
	hcol.shape = hshape
	hcol.position = Vector2(82, -50)
	hitbox.add_child(hcol)
	add_child(hitbox)

	# hurtbox — enemy attacks & projectiles & traps target this
	hurtbox = Area2D.new()
	hurtbox.collision_layer = Globals.L_PLAYER
	hurtbox.collision_mask = Globals.L_ENEMY | Globals.L_PROJECTILE | Globals.L_TRAP
	hurtbox.monitoring = true
	var ucol := CollisionShape2D.new()
	var ushape := RectangleShape2D.new()
	ushape.size = Vector2(34, 88)
	ucol.shape = ushape
	ucol.position = Vector2(0, -48)
	hurtbox.add_child(ucol)
	add_child(hurtbox)
	hurtbox.area_entered.connect(_on_hurt_area_entered)

	_add_stats()
	health_changed.emit(hp, max_hp)
	EventBus.request_player_heal.connect(_heal)


func _add_stats() -> void:
	max_hp = SaveSystem.attribute("max_hp")
	hp = max_hp * SaveSystem.p()["hp_restore"]
	defense = SaveSystem.attribute("defense")
	crit_chance = SaveSystem.attribute("crit_chance")
	crit_damage = SaveSystem.attribute("crit_damage")
	move_speed = SaveSystem.attribute("move_speed")


func set_camera(cam: CameraController) -> void:
	camera = cam


# ----------------------------------------------------------------------------
# input helpers — touch controls OR keyboard
# ----------------------------------------------------------------------------
func _axis() -> float:
	var tc := _touch_controls()
	var v := Input.get_axis("move_left", "move_right")
	if tc and absf(tc.axis()) > 0.15:
		v = tc.axis()
	return v


func _pressed(action: String) -> bool:
	var tc := _touch_controls()
	return Input.is_action_just_pressed(action) or (tc and tc.consume_press(action))


func _held(action: String) -> bool:
	var tc := _touch_controls()
	return Input.is_action_pressed(action) or (tc and tc.is_held(action))


func _touch_controls() -> TouchControls:
	var n := get_tree().get_first_node_in_group("touch_controls")
	return n as TouchControls


# ----------------------------------------------------------------------------
# main loop
# ----------------------------------------------------------------------------
func _physics_process(delta: float) -> void:
	if st == ST.DEAD or st == ST.VICTORY:
		velocity.x = move_toward(velocity.x, 0, FRICTION * delta)
		if st == ST.DEAD:
			velocity.y = minf(velocity.y + GRAVITY * delta, MAX_FALL)
		move_and_slide()
		return

	invuln_t = maxf(0.0, invuln_t - delta)
	dash_cd_t = maxf(0.0, dash_cd_t - delta)
	dash_cd_changed.emit(1.0 - dash_cd_t / DASH_CD)
	combo_reset_t = maxf(0.0, combo_reset_t - delta)
	if combo_reset_t == 0.0 and combo_hits > 0:
		combo_hits = 0
		combo_changed.emit(0)

	jump_buffer_t = maxf(0.0, jump_buffer_t - delta)
	if _pressed("jump"):
		jump_buffer_t = BUFFER

	match st:
		ST.MOVE:
			_do_move(delta)
		ST.DASH:
			_do_dash(delta)
		ST.ATTACK:
			_do_attack(delta)
		ST.SPECIAL:
			_do_special(delta)
		ST.HURT:
			_do_hurt(delta)

	# trail behind dash
	if st == ST.DASH:
		_spawn_ghost_t -= delta
		if _spawn_ghost_t <= 0.0:
			_spawn_ghost_t = 0.03
			Vfx.dash_ghost(get_parent(), global_position, facing)

	move_and_slide()
	_update_animation()
	_blink()


func _do_move(delta: float) -> void:
	var ax := _axis()
	var on_floor := is_on_floor()
	var want_attack := _pressed("attack")
	var want_dash := _pressed("dash")
	var want_special := _pressed("special")

	# horizontal
	if absf(ax) > 0.15:
		var accel := ACCEL if on_floor else AIR_ACCEL
		velocity.x = move_toward(velocity.x, ax * move_speed, accel * delta)
		facing = 1 if ax > 0 else -1
	else:
		velocity.x = move_toward(velocity.x, 0, (FRICTION if on_floor else FRICTION * 0.45) * delta)

	# gravity
	var g := GRAVITY * (FALL_MULT if velocity.y > 0 else 1.0)
	velocity.y = minf(velocity.y + g * delta, MAX_FALL)

	# coyote + jump
	coyote_t = COYOTE if on_floor else maxf(0.0, coyote_t - delta)
	if on_floor:
		jumps_left = 2
	if jump_buffer_t > 0.0:
		if coyote_t > 0.0:
			velocity.y = JUMP_V
			jumps_left = 1
			coyote_t = 0.0
			jump_buffer_t = 0.0
			AudioManager.sfx("jump")
			Vfx.dust(get_parent(), global_position + Vector2(0, 0))
		elif jumps_left > 0:
			velocity.y = JUMP_V * 0.9 + SaveSystem.skill_bonus("double_jump")
			jumps_left -= 1
			jump_buffer_t = 0.0
			AudioManager.sfx("double_jump", -4.0)
			Vfx.shadow_puff(get_parent(), global_position + Vector2(0, -20))

	# variable jump: release early -> cut
	if not _held("jump") and velocity.y < JUMP_V * JUMP_CUT and jump_buffer_t == 0.0:
		velocity.y = JUMP_V * JUMP_CUT

	# dash
	if want_dash and dash_cd_t <= 0.0:
		_start_dash()
		return
	# special
	if want_special and special_charge >= SPECIAL_COST:
		_start_special()
		return
	# attack
	if want_attack:
		_start_attack()
		return

	# falling into the abyss
	if global_position.y > 2400.0:
		hp = 0.0
		health_changed.emit(hp, max_hp)
		_die()


func _start_dash() -> void:
	st = ST.DASH
	dash_t = DASH_TIME
	dash_cd_t = DASH_CD
	var ax := _axis()
	dash_dir = Vector2(ax, 0) if absf(ax) > 0.15 else Vector2(facing, 0)
	facing = 1 if dash_dir.x > 0 else -1
	velocity = dash_dir.normalized() * DASH_SPEED
	velocity.y = 0
	invuln_t = maxf(invuln_t, DASH_TIME + 0.05)
	_hit_this_swing.clear()
	hitbox.monitoring = true
	sprite.play("dash")
	AudioManager.sfx("dash")
	EventBus.screen_shake_requested.emit(3.0)


func _do_dash(delta: float) -> void:
	dash_t -= delta
	velocity = dash_dir.normalized() * DASH_SPEED
	velocity.y = 0
	# dash damages enemies along the path (hitbox stays enabled from _start_dash)
	hitbox.get_child(0).position.x = 40 * facing
	_swing_damage(int(SaveSystem.attribute("attack") * 0.75 + SaveSystem.skill_bonus("dash_damage")), 90.0)
	if dash_t <= 0.0:
		hitbox.monitoring = false
		st = ST.MOVE


func _start_attack() -> void:
	st = ST.ATTACK
	attack_buffered = false
	_hit_this_swing.clear()
	hitbox.get_child(0).position.x = 82 * facing
	hitbox.monitoring = true  # enabled for the whole swing; damage lands on strike frames
	var anim := "attack%d" % (attack_index + 1)
	sprite.play(anim)
	AudioManager.sfx("swish_%d" % (attack_index + 1), -2.0)


func _do_attack(delta: float) -> void:
	# keep momentum, allow slight drift
	var ax := _axis()
	if absf(ax) > 0.15:
		velocity.x = move_toward(velocity.x, ax * move_speed * 0.55, AIR_ACCEL * delta)
	velocity.y = minf(velocity.y + GRAVITY * delta, MAX_FALL)
	if _pressed("attack"):
		attack_buffered = true


func _on_frame_changed() -> void:
	# strike lands on these frames per combo stage
	if st == ST.ATTACK:
		var strike_frames := {0: 2, 1: 2, 2: 3}
		if sprite.animation.begins_with("attack"):
			var idx := int(sprite.animation.substr(6)) - 1
			if sprite.frame == strike_frames.get(idx, 2):
				hitbox.get_child(0).position.x = 82 * facing
				var dmg := SaveSystem.attribute("attack") * (1.25 + 0.22 * idx)
				if idx == 2:
					dmg *= 1.0 + SaveSystem.skill_bonus("combo3_damage")
				_swing_damage(dmg, 130.0 + 40.0 * idx)
				Vfx.slash(get_parent(), global_position + Vector2(56 * facing, -50), facing, idx)
		elif sprite.animation == "special" and sprite.frame == 3:
			_special_burst()


func _on_anim_finished() -> void:
	match sprite.animation:
		"attack1", "attack2", "attack3":
			hitbox.monitoring = false
			var idx := int(sprite.animation.substr(6)) - 1
			if attack_buffered and idx < 2:
				attack_index = idx + 1
				combo_hits = idx + 2
				combo_changed.emit(combo_hits)
				_start_attack()
			else:
				if attack_buffered:
					attack_index = 0
					combo_hits = 0
					combo_changed.emit(0)
				else:
					attack_index = (idx + 1) % 3
					combo_reset_t = COMBO_WINDOW
					if idx == 2:
						combo_hits = 3
						EventBus.combo_finished.emit(3)
						combo_hits = 0
						combo_changed.emit(0)
				st = ST.MOVE
		"special":
			st = ST.MOVE
		"hurt":
			st = ST.MOVE
		"dash":
			st = ST.MOVE


func _start_special() -> void:
	st = ST.SPECIAL
	special_charge -= SPECIAL_COST
	special_changed.emit(special_charge / SPECIAL_COST)
	sprite.play("special")
	AudioManager.sfx("special")
	EventBus.hitstop_requested.emit(0.06)


func _special_burst() -> void:
	# AoE burst around the player
	var r := 220.0
	var dmg := SaveSystem.attribute("attack") * 2.2
	var mult := 1.0 + SaveSystem.skill_bonus("special_damage")
	var box := Area2D.new()
	box.collision_layer = 0
	box.collision_mask = Globals.L_ENEMY
	var c := CollisionShape2D.new()
	var s := CircleShape2D.new()
	s.radius = r
	c.shape = s
	box.add_child(c)
	add_child(box)
	box.force_update_transform()
	await get_tree().physics_frame
	for body in box.get_overlapping_bodies():
		if body is EnemyBase and not body.is_dead():
			var kb := (body.global_position - global_position).normalized() * 260.0
			body.hurt(dmg * mult, kb, false)
			if body.is_dead():
				gain_special(SPECIAL_GAIN_ON_KILL)
	box.queue_free()
	Vfx.shockwave(get_parent(), global_position + Vector2(0, -40))
	Vfx.shadow_puff(get_parent(), global_position)
	EventBus.screen_shake_requested.emit(9.0)


func _do_special(_delta: float) -> void:
	velocity.x = move_toward(velocity.x, 0, FRICTION * _delta)
	velocity.y = minf(velocity.y + GRAVITY * _delta, MAX_FALL)


func _do_hurt(delta: float) -> void:
	velocity.y = minf(velocity.y + GRAVITY * delta, MAX_FALL)


func _swing_damage(dmg: float, knock: float) -> void:
	for body in hitbox.get_overlapping_bodies():
		if body is EnemyBase and not body.is_dead() and not _hit_this_swing.has(body):
			_hit_this_swing.append(body)
			var is_crit := randf() < crit_chance
			var final := dmg * (crit_damage if is_crit else 1.0)
			var kb := Vector2(facing * knock, -120.0)
			body.hurt(final, kb, is_crit)
			gain_special(SPECIAL_GAIN_PER_HIT)
			if body.is_dead():
				gain_special(SPECIAL_GAIN_ON_KILL)
			if is_crit:
				EventBus.hitstop_requested.emit(0.05)


func _on_hurt_area_entered(area: Area2D) -> void:
	if area.has_meta("owner") and area.get_meta("owner") is EnemyBase:
		var e: EnemyBase = area.get_meta("owner")
		if area.get_meta("kind", "") == "attack":
			take_damage(e.damage, (global_position - e.global_position).normalized() * 240.0)
	elif area.has_meta("damage"):
		var dmg: float = area.get_meta("damage")
		var src: Vector2 = area.get_meta("source", global_position)
		take_damage(dmg, (global_position - src).normalized() * 260.0)


# ----------------------------------------------------------------------------
# damage / heal / death
# ----------------------------------------------------------------------------
func take_damage(amount: float, knockback: Vector2) -> void:
	if invuln_t > 0.0 or st == ST.DEAD or victory:
		return
	var reduced := maxf(4.0, amount - defense)
	hp = maxf(0.0, hp - reduced)
	health_changed.emit(hp, max_hp)
	EventBus.player_hurt.emit(int(reduced))
	Vfx.damage_number(get_parent(), global_position + Vector2(0, -90), int(reduced), false, Globals.COL_RED_HOT)
	AudioManager.sfx("hurt")
	EventBus.screen_shake_requested.emit(7.0)
	EventBus.hitstop_requested.emit(0.04)
	if hp <= 0.0:
		_die()
		return
	st = ST.HURT
	invuln_t = 0.9
	velocity = knockback
	velocity.y = minf(velocity.y, -180.0)
	sprite.play("hurt")


func _heal(amount: float) -> void:
	if st == ST.DEAD:
		return
	hp = minf(max_hp, hp + amount)
	health_changed.emit(hp, max_hp)
	EventBus.player_healed.emit(amount)
	Vfx.heal_burst(get_parent(), global_position)


func _die() -> void:
	if dead_handled:
		return
	dead_handled = true
	st = ST.DEAD
	velocity = Vector2.ZERO
	sprite.play("death")
	AudioManager.sfx("death")
	EventBus.screen_shake_requested.emit(10.0)
	SaveSystem.data["stats"]["deaths"] += 1
	SaveSystem.mark_dirty()
	# fade out after animation
	await sprite.animation_finished
	var tw := create_tween()
	tw.tween_property(sprite, "modulate:a", 0.0, 0.8)
	died.emit()


func gain_special(v: float) -> void:
	if st == ST.DEAD:
		return
	var rate := 1.0 + SaveSystem.skill_bonus("special_rate")
	special_charge = minf(SPECIAL_COST, special_charge + v * rate)
	special_changed.emit(special_charge / SPECIAL_COST)


func set_victory() -> void:
	victory = true
	st = ST.VICTORY
	sprite.play("victory")


func respawn_at(pos: Vector2) -> void:
	global_position = pos
	velocity = Vector2.ZERO
	hp = max_hp
	dead_handled = false
	st = ST.MOVE
	sprite.modulate.a = 1.0
	invuln_t = 1.2
	special_charge = 0.0
	health_changed.emit(hp, max_hp)
	sprite.play("idle")


# ----------------------------------------------------------------------------
# visuals
# ----------------------------------------------------------------------------
func _update_animation() -> void:
	if st != ST.MOVE:
		sprite.flip_h = facing < 0
		return
	sprite.flip_h = facing < 0
	if is_on_floor():
		if absf(velocity.x) > 30.0:
			_play_if_new("run")
		else:
			_play_if_new("idle")
	else:
		_play_if_new("fall" if velocity.y > 0 else "jump")


func _play_if_new(anim: String) -> void:
	if sprite.animation != anim:
		sprite.play(anim)


func _blink() -> void:
	if invuln_t > 0.0 and st != ST.DEAD:
		sprite.modulate.a = 0.5 + 0.5 * sin(Time.get_ticks_msec() * 0.04)
	elif st != ST.DEAD:
		sprite.modulate.a = 1.0
