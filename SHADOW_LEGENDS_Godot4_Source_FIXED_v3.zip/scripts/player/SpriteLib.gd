class_name SpriteLib
## SpriteLib — builds SpriteFrames from the generated horizontal-strip sheets.
## Frame metadata mirrors /scripts/art_*.py outputs exactly.

const CHAR := "res://assets/characters/"
const ENEM := "res://assets/enemies/"
const BOSS := "res://assets/bosses/"
const FX := "res://assets/effects/"

# {anim: [start, count, fps, loop]}
const NINJA := {
	"idle": [0, 4, 6.0, true], "run": [4, 8, 13.0, true],
	"jump": [12, 2, 8.0, false], "fall": [14, 2, 8.0, true],
	"attack1": [16, 4, 16.0, false], "attack2": [20, 4, 16.0, false],
	"attack3": [24, 5, 15.0, false], "dash": [29, 3, 12.0, false],
	"special": [32, 6, 12.0, false], "hurt": [38, 2, 10.0, false],
	"death": [40, 6, 9.0, false], "victory": [46, 4, 6.0, true],
}
const SHADOW_WOLF := {
	"idle": [0, 4, 6.0, true], "run": [4, 8, 12.0, true],
	"attack": [12, 4, 12.0, false], "hurt": [16, 2, 10.0, false],
	"death": [18, 6, 9.0, false],
}
const DARK_KNIGHT := {
	"idle": [0, 4, 6.0, true], "walk": [4, 6, 9.0, true],
	"attack": [10, 5, 10.0, false], "hurt": [15, 2, 10.0, false],
	"death": [17, 6, 9.0, false],
}
const BLOOD_ARCHER := {
	"idle": [0, 4, 6.0, true], "walk": [4, 6, 9.0, true],
	"shoot": [10, 4, 9.0, false], "hurt": [14, 2, 10.0, false],
	"death": [16, 6, 9.0, false],
}
const ABYSS_MAGE := {
	"idle": [0, 4, 6.0, true], "cast": [4, 4, 8.0, false],
	"hurt": [8, 2, 10.0, false], "death": [10, 6, 9.0, false],
}
const SHADOW_ASSASSIN := {
	"idle": [0, 4, 6.0, true], "run": [4, 8, 12.0, true],
	"attack": [12, 4, 12.0, false], "hurt": [16, 2, 10.0, false],
	"death": [18, 6, 9.0, false],
}
const ABYSS_LORD := {
	"idle": [0, 6, 7.0, true], "walk": [6, 6, 8.0, true],
	"slam": [12, 6, 10.0, false], "charge": [18, 6, 10.0, false],
	"cast": [24, 6, 9.0, false], "hurt": [30, 2, 10.0, false],
	"death": [32, 8, 8.0, false],
}


static func build(path: String, frame_w: int, anims: Dictionary) -> SpriteFrames:
	var tex: Texture2D = load(path)
	var sf := SpriteFrames.new()
	sf.remove_animation("default")
	for anim in anims.keys():
		var a: Array = anims[anim]
		var start: int = a[0]
		var count: int = a[1]
		sf.add_animation(anim)
		sf.set_animation_speed(anim, a[2])
		sf.set_animation_loop(anim, a[3])
		for i in range(count):
			var at := AtlasTexture.new()
			at.atlas = tex
			at.region = Rect2((start + i) * frame_w, 0, frame_w, tex.get_height())
			sf.add_frame(anim, at)
	return sf


static func ninja() -> SpriteFrames:
	return build(CHAR + "ninja_sheet.png", 128, NINJA)


static func enemy_sheet(kind: String) -> SpriteFrames:
	match kind:
		"shadow_wolf": return build(ENEM + "shadow_wolf_sheet.png", 128, SHADOW_WOLF)
		"dark_knight": return build(ENEM + "dark_knight_sheet.png", 128, DARK_KNIGHT)
		"blood_archer": return build(ENEM + "blood_archer_sheet.png", 128, BLOOD_ARCHER)
		"abyss_mage": return build(ENEM + "abyss_mage_sheet.png", 128, ABYSS_MAGE)
		"shadow_assassin": return build(ENEM + "shadow_assassin_sheet.png", 128, SHADOW_ASSASSIN)
		"abyss_lord": return build(BOSS + "abyss_lord_sheet.png", 256, ABYSS_LORD)
	push_error("unknown enemy kind " + kind)
	return null


static func tex(path: String) -> Texture2D:
	return load(path)
