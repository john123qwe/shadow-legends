extends Camera2D
class_name CameraController
## Smooth follow camera with lookahead, screen shake, and boss framing.

var target: Node2D
var lookahead := Vector2(140, -60)
var shake_amt := 0.0
var shake_enabled := true
var _noise_t := 0.0
var forced_center: Vector2 = Vector2.ZERO
var use_forced := false


func _ready() -> void:
	position_smoothing_enabled = true
	position_smoothing_speed = 7.0
	zoom = Vector2.ONE
	EventBus.screen_shake_requested.connect(shake)
	make_current()


func set_target(t: Node2D) -> void:
	target = t
	global_position = t.global_position


func shake(strength: float) -> void:
	if not shake_enabled:
		return
	shake_amt = minf(24.0, shake_amt + strength)


func _process(delta: float) -> void:
	if use_forced:
		global_position = global_position.lerp(forced_center, 1.0 - pow(0.001, delta))
	elif target:
		var face: int = 1
		if target is Player:
			face = target.facing
		global_position = target.global_position + Vector2(lookahead.x * face, lookahead.y)
	if shake_amt > 0.01:
		_noise_t += delta * 34.0
		var n := Vector2(sin(_noise_t * 1.7), cos(_noise_t * 2.3)) * shake_amt
		offset = n
		shake_amt = lerpf(shake_amt, 0.0, 1.0 - pow(0.0002, delta))
	else:
		offset = Vector2.ZERO


func pan_to(pos: Vector2, hold := 1.4) -> void:
	# brief cinematic focus (boss entrance)
	forced_center = pos
	use_forced = true
	get_tree().create_timer(hold).timeout.connect(func(): use_forced = false)
