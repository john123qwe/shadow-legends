extends Node
## SaveSystem — versioned, checksummed, atomic local save + progression API.
## Offline-first. No network dependency for normal gameplay.

signal gold_changed(v: int)
signal gems_changed(v: int)
signal xp_changed(xp: int, into_level: int, need: int)
signal leveled_up(new_level: int)
signal skill_learned(id: String)
signal item_acquired(item_id: String, rarity: String)
signal achievement_unlocked(id: String)
signal inventory_changed

const SAVE_PATH := "user://shadow_legends_save.json"
const BAK_PATH := "user://shadow_legends_save.bak"
const TMP_PATH := "user://shadow_legends_save.tmp"
const SCHEMA_VERSION := 1

var data: Dictionary = {}
var _dirty := false
var _autosave_accum := 0.0


func _ready() -> void:
	_load_or_init()
	EventBus.enemy_killed.connect(_on_enemy_killed)
	EventBus.level_completed.connect(_on_level_completed)
	EventBus.boss_defeated.connect(_on_boss_defeated)
	EventBus.challenge_event.connect(_on_challenge_event)
	EventBus.abyss_depth_reached.connect(_on_abyss_depth)
	_connect_combo_tracking()


func _process(delta: float) -> void:
	# Debounced autosave for gameplay-driven changes.
	if _dirty:
		_autosave_accum += delta
		if _autosave_accum >= 4.0:
			save_game()
	else:
		_autosave_accum = 0.0


func _exit_tree() -> void:
	# flush on app shutdown
	save_game()


func mark_dirty() -> void:
	_dirty = true


# ----------------------------------------------------------------------------
# Persistence (atomic + backup + checksum)
# ----------------------------------------------------------------------------
func _checksum(payload: Dictionary) -> String:
	# payload IS the inner data dictionary here (both call sites pass the inner
	# dict: save path passes `data`, load path passes the parsed `data` field).
	return Marshalls.utf8_to_base64(JSON.stringify(payload)).substr(0, 16)


func _serialize() -> String:
	data["updated_at"] = Time.get_datetime_string_from_system(false, true)
	var wrapper := {"version": SCHEMA_VERSION, "checksum": _checksum(data), "data": data}
	return JSON.stringify(wrapper, "\t")


func save_game() -> void:
	var payload := _serialize()
	var f := FileAccess.open(TMP_PATH, FileAccess.WRITE)
	if f == null:
		push_error("SaveSystem: cannot open temp file")
		return
	f.store_string(payload)
	f.flush()
	# Atomic swap: tmp -> main, previous main -> backup.
	if FileAccess.file_exists(SAVE_PATH):
		DirAccess.rename_absolute(SAVE_PATH, BAK_PATH)
	DirAccess.rename_absolute(ProjectSettings.globalize_path(TMP_PATH), ProjectSettings.globalize_path(SAVE_PATH))
	_dirty = false
	_autosave_accum = 0.0


func _valid_json(raw: String) -> Dictionary:
	var parsed = JSON.parse_string(raw)
	if typeof(parsed) != TYPE_DICTIONARY:
		return {}
	if int(parsed.get("version", 0)) != SCHEMA_VERSION:
		return {}
	var d = parsed.get("data")
	if typeof(d) != TYPE_DICTIONARY:
		return {}
	if parsed.get("checksum", "") != _checksum(d):
		return {}
	return _migrated(d)


func _migrated(d: Dictionary) -> Dictionary:
	# Future schema migrations go here (v1 is initial). Merge missing keys.
	var def := _default_data()
	for k in def.keys():
		if not d.has(k):
			d[k] = def[k]
	for k in def["player"].keys():
		if not d["player"].has(k):
			d["player"][k] = def["player"][k]
	return d


func _load_or_init() -> void:
	data = _try_load(SAVE_PATH)
	if data.is_empty():
		data = _try_load(BAK_PATH)
		if not data.is_empty():
			push_warning("SaveSystem: main save corrupt, restored from backup")
	if data.is_empty():
		data = _default_data()
		save_game()


func _try_load(path: String) -> Dictionary:
	if not FileAccess.file_exists(path):
		return {}
	var f := FileAccess.open(path, FileAccess.READ)
	if f == null:
		return {}
	return _valid_json(f.get_as_text())


func wipe_save() -> void:
	data = _default_data()
	save_game()
	gold_changed.emit(data["player"]["gold"])
	gems_changed.emit(data["player"]["gems"])


func _default_data() -> Dictionary:
	return {
		"created_at": Time.get_datetime_string_from_system(false, true),
		"player": {
			"level": 1, "xp": 0, "gold": 150, "gems": 20, "skill_points": 1,
			"hp_restore": 1.0,
			"skills": {},              # id -> rank
			"equipped": {"weapon": "katana_basic", "armor": "cloak_basic", "accessory": ""},
			"inventory": [{"id": "katana_basic", "rarity": "common", "plus": 0, "count": 1}],
		},
		"progress": {
			"levels_completed": {},    # "w1_l1" -> stars 1..3
			"worlds_unlocked": 1,
			"total_stars": 0,
		},
		"abyss": {"deepest": 0, "best_score": 0},
		"achievements": {},
		"stats": {"kills": 0, "boss_kills": 0, "deaths": 0, "playtime_sec": 0.0,
				  "gold_earned_total": 0, "combos_finished": 0},
		"purchases": {
			"entitlements": [],         # non-consumable product ids granted
			"consumed_tx": [],          # transaction ids already granted+consumed
			"pending_tx": {},           # tx_id -> product_id (crash recovery)
		},
		"settings": {
			"music_vol": 0.8, "sfx_vol": 1.0, "persian_digits": true,
			"locale": "fa", "button_scale": 1.0, "joystick_side": "left",
			"quality": "high", "screen_shake": true,
		},
		"daily": {"date": "", "challenge": "", "progress": 0, "claimed": false},
	}


# ----------------------------------------------------------------------------
# Settings
# ----------------------------------------------------------------------------
func get_setting(key: String, fallback: Variant = null) -> Variant:
	return data["settings"].get(key, fallback)


func set_setting(key: String, value: Variant) -> void:
	data["settings"][key] = value
	mark_dirty()
	save_game()


# ----------------------------------------------------------------------------
# Currency / XP / level
# ----------------------------------------------------------------------------
func p() -> Dictionary:
	return data["player"]


func add_gold(amount: int) -> void:
	p()["gold"] = max(0, int(p()["gold"]) + amount)
	data["stats"]["gold_earned_total"] += max(0, amount)
	gold_changed.emit(p()["gold"])
	_check_achievement("rich", int(p()["gold"]) >= 5000)
	mark_dirty()


func add_gems(amount: int) -> void:
	p()["gems"] = max(0, int(p()["gems"]) + amount)
	gems_changed.emit(p()["gems"])
	mark_dirty()


func xp_needed(level: int) -> int:
	return int(round(90.0 * pow(level, 1.32)))


func add_xp(amount: int) -> void:
	var pl := p()
	pl["xp"] += amount
	var need := xp_needed(pl["level"])
	while pl["xp"] >= need and pl["level"] < 80:
		pl["xp"] -= need
		pl["level"] += 1
		pl["skill_points"] += 2
		leveled_up.emit(pl["level"])
		need = xp_needed(pl["level"])
	xp_changed.emit(pl["xp"], pl["level"], need)
	mark_dirty()


# ----------------------------------------------------------------------------
# Attributes — base + level growth + skills + equipment
# ----------------------------------------------------------------------------
func attribute(attr: String) -> float:
	var lv := int(p()["level"])
	var base := 0.0
	var growth := 0.0
	match attr:
		"max_hp":
			base = 100.0; growth = 12.0
		"attack":
			base = 18.0; growth = 2.2
		"defense":
			base = 4.0; growth = 0.9
		"crit_chance":
			base = 0.08; growth = 0.004
		"crit_damage":
			base = 1.6; growth = 0.01
		"move_speed":
			base = 420.0; growth = 1.6
	var v := base + growth * (lv - 1)
	v += skill_bonus(attr)
	v += equipment_bonus(attr)
	return v


func skill_bonus(attr: String) -> float:
	var bonus := 0.0
	for id in p()["skills"].keys():
		var rank := int(p()["skills"][id])
		var def: Dictionary = GameDB.SKILLS.get(id, {})
		for eff in def.get("effects", []):
			if eff.get("attr", "") == attr:
				bonus += eff.get("per_rank", 0.0) * rank
	return bonus


func equipment_bonus(attr: String) -> float:
	var bonus := 0.0
	for slot in p()["equipped"].keys():
		var iid = p()["equipped"][slot]
		if iid == null or iid == "":
			continue
		var inst := find_item(iid)
		if inst.is_empty():
			continue
		var def: Dictionary = GameDB.ITEMS.get(inst["id"], {})
		for st in def.get("stats", {}).keys():
			if st == attr:
				bonus += GameDB.stat_value(def, st, inst["rarity"], int(inst["plus"]))
	return bonus


func max_hp() -> float:
	return attribute("max_hp")


# ----------------------------------------------------------------------------
# Skills
# ----------------------------------------------------------------------------
func skill_rank(id: String) -> int:
	return int(p()["skills"].get(id, 0))


func can_learn_skill(id: String) -> Dictionary:
	# returns {ok: bool, reason: String}
	var def: Dictionary = GameDB.SKILLS.get(id, {})
	if def.is_empty():
		return {"ok": false, "reason": "unknown"}
	if skill_rank(id) >= int(def.get("max_rank", 1)):
		return {"ok": false, "reason": "max"}
	for pre in def.get("requires", []):
		if skill_rank(pre) < 1:
			return {"ok": false, "reason": "locked"}
	if int(p()["skill_points"]) < int(def.get("cost", 1)):
		return {"ok": false, "reason": "points"}
	return {"ok": true, "reason": ""}


func learn_skill(id: String) -> bool:
	var chk := can_learn_skill(id)
	if not chk["ok"]:
		return false
	p()["skills"][id] = skill_rank(id) + 1
	p()["skill_points"] -= int(GameDB.SKILLS[id]["cost"])
	save_game()
	skill_learned.emit(id)
	return true


# ----------------------------------------------------------------------------
# Inventory / equipment
# ----------------------------------------------------------------------------
func find_item(unique_id: String) -> Dictionary:
	for it in p()["inventory"]:
		if it["uid"] == unique_id:
			return it
	return {}


func add_item(item_id: String, rarity: String) -> void:
	var uid := item_id + "_" + str(Time.get_ticks_msec()) + "_" + str(p()["inventory"].size())
	p()["inventory"].append({"uid": uid, "id": item_id, "rarity": rarity, "plus": 0, "count": 1})
	_check_achievement("mythic", rarity == "legendary" or rarity == "mythic")
	mark_dirty()
	item_acquired.emit(item_id, rarity)
	inventory_changed.emit()


func equip_item(unique_id: String) -> void:
	var inst := find_item(unique_id)
	if inst.is_empty():
		return
	var slot: String = GameDB.ITEMS[inst["id"]]["slot"]
	p()["equipped"][slot] = unique_id
	save_game()
	inventory_changed.emit()


func upgrade_cost(inst: Dictionary) -> int:
	return GameDB.upgrade_cost(inst)


func upgrade_item(unique_id: String) -> bool:
	var inst := find_item(unique_id)
	if inst.is_empty():
		return false
	var cost := upgrade_cost(inst)
	if int(p()["gold"]) < cost:
		return false
	add_gold(-cost)
	inst["plus"] = int(inst["plus"]) + 1
	save_game()
	inventory_changed.emit()
	return true


func sell_item(unique_id: String) -> bool:
	var inst := find_item(unique_id)
	if inst.is_empty():
		return false
	for slot in p()["equipped"].keys():
		if p()["equipped"][slot] == unique_id:
			return false  # cannot sell equipped
	var value: int = GameDB.ITEMS[inst["id"]].get("sell", 25) * (1 + int(inst["plus"]))
	add_gold(value)
	p()["inventory"].erase(inst)
	save_game()
	inventory_changed.emit()
	return true


func use_potion(unique_id: String) -> bool:
	var inst := find_item(unique_id)
	if inst.is_empty() or inst["id"] != "potion_health":
		return false
	var heal: float = GameDB.ITEMS["potion_health"]["stats"].get("heal", 60.0)
	EventBus.request_player_heal.emit(heal)
	inst["count"] = int(inst["count"]) - 1
	if int(inst["count"]) <= 0:
		p()["inventory"].erase(inst)
	save_game()
	inventory_changed.emit()
	return true


func buy_potion() -> bool:
	var cost: int = GameDB.ITEMS["potion_health"]["price"]
	if int(p()["gold"]) < cost:
		return false
	add_gold(-cost)
	# stack potions
	for it in p()["inventory"]:
		if it["id"] == "potion_health":
			it["count"] = int(it["count"]) + 1
			save_game()
			inventory_changed.emit()
			return true
	add_item("potion_health", "common")
	return true


# ----------------------------------------------------------------------------
# Level progress
# ----------------------------------------------------------------------------
func is_level_completed(level_key: String) -> bool:
	return data["progress"]["levels_completed"].has(level_key)


func complete_level(level_key: String, stars: int, gold: int, xp: int) -> void:
	var prev: int = int(data["progress"]["levels_completed"].get(level_key, 0))
	if stars > prev:
		data["progress"]["levels_completed"][level_key] = stars
		data["progress"]["total_stars"] += (stars - prev)
	add_gold(gold)
	add_xp(xp)
	save_game()
	EventBus.level_completed.emit(level_key, stars, gold, xp)
	# unlock next world when a world is fully cleared (3 levels per world)
	var w := int(level_key.substr(1, 1))
	var all_done := true
	for i in range(1, GameDB.WORLDS[w - 1]["levels"] + 1):
		if not data["progress"]["levels_completed"].has("w%d_l%d" % [w, i]):
			all_done = false
			break
	if all_done and data["progress"]["worlds_unlocked"] < w + 1 and w < GameDB.WORLDS.size():
		data["progress"]["worlds_unlocked"] = w + 1
		save_game()


func worlds_unlocked() -> int:
	return int(data["progress"]["worlds_unlocked"])


func record_abyss_run(depth: int, score: int) -> void:
	if depth > int(data["abyss"]["deepest"]):
		data["abyss"]["deepest"] = depth
	if score > int(data["abyss"]["best_score"]):
		data["abyss"]["best_score"] = score
	save_game()


# ----------------------------------------------------------------------------
# Achievements + daily challenge (EventBus driven)
# ----------------------------------------------------------------------------
func _on_enemy_killed(enemy_id: String, _pos: Vector2) -> void:
	data["stats"]["kills"] += 1
	EventBus.challenge_event.emit("kills", 1)
	_check_achievement("first_blood", data["stats"]["kills"] >= 1)
	_check_achievement("slayer_100", data["stats"]["kills"] >= 100)
	_check_achievement("slayer_1000", data["stats"]["kills"] >= 1000)


func _connect_combo_tracking() -> void:
	EventBus.combo_finished.connect(func(hits: int):
		if hits >= 3:
			_check_achievement("combo_master", true))


func _on_boss_defeated(_boss_id: String) -> void:
	data["stats"]["boss_kills"] += 1
	_check_achievement("boss_slayer", data["stats"]["boss_kills"] >= 1)


func _on_level_completed(_key: String, _stars: int, _gold: int, _xp: int) -> void:
	var done: int = data["progress"]["levels_completed"].size()
	_check_achievement("wayfarer", done >= 3)
	_check_achievement("w1_clear", data["progress"]["levels_completed"].has("w1_l3"))
	_check_achievement("w3_clear", data["progress"]["levels_completed"].has("w3_l3"))


func _on_abyss_depth(depth: int) -> void:
	_check_achievement("abyss_10", depth >= 10)
	_check_achievement("abyss_25", depth >= 25)


func _on_challenge_event(kind: String, amount: int) -> void:
	var d: Dictionary = data["daily"]
	_ensure_daily()
	if d["challenge"].begins_with(kind) and not d["claimed"]:
		d["progress"] = int(d["progress"]) + amount
		mark_dirty()


func _check_achievement(id: String, cond: bool) -> void:
	if cond and not data["achievements"].has(id):
		data["achievements"][id] = true
		add_gems(GameDB.ACHIEVEMENTS[id]["reward"])
		save_game()
		achievement_unlocked.emit(id)


func _ensure_daily() -> void:
	var d: Dictionary = data["daily"]
	var today := Time.get_date_string_from_system()
	if d["date"] != today:
		d["date"] = today
		d["challenge"] = GameDB.daily_challenge(today)
		d["progress"] = 0
		d["claimed"] = false
		mark_dirty()


func claim_daily() -> bool:
	_ensure_daily()
	var d: Dictionary = data["daily"]
	var target := int(d["challenge"].split(":")[1])
	if d["claimed"] or int(d["progress"]) < target:
		return false
	d["claimed"] = true
	add_gems(15)
	save_game()
	return true


func daily_status() -> Dictionary:
	_ensure_daily()
	return data["daily"]


func add_playtime(delta: float) -> void:
	data["stats"]["playtime_sec"] += delta
	if fmod(data["stats"]["playtime_sec"], 10.0) < delta:
		mark_dirty()


# ----------------------------------------------------------------------------
# Purchases / entitlements (filled by BillingBridge)
# ----------------------------------------------------------------------------
func has_entitlement(product_id: String) -> bool:
	return data["purchases"]["entitlements"].has(product_id)


func grant_entitlement(product_id: String) -> void:
	if not has_entitlement(product_id):
		data["purchases"]["entitlements"].append(product_id)
		save_game()


func record_consumed_tx(tx_id: String) -> void:
	if not data["purchases"]["consumed_tx"].has(tx_id):
		data["purchases"]["consumed_tx"].append(tx_id)
		save_game()


func tx_already_processed(tx_id: String) -> bool:
	return data["purchases"]["consumed_tx"].has(tx_id)


func set_pending_tx(tx_id: String, product_id: String) -> void:
	data["purchases"]["pending_tx"][tx_id] = product_id
	save_game()


func clear_pending_tx(tx_id: String) -> void:
	data["purchases"]["pending_tx"].erase(tx_id)
	save_game()


func pending_txs() -> Dictionary:
	return data["purchases"]["pending_tx"]
