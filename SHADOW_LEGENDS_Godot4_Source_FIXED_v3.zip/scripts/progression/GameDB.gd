extends Node
## GameDB — static game data: skills, items, worlds, enemies, IAP catalog,
## achievements, daily challenges. Tuning constants for balance live here.

# ----------------------------------------------------------------------------
# ATTRIBUTES
# ----------------------------------------------------------------------------
const ATTR_INFO := {
	"max_hp": {"key": "char.hp", "pct": false},
	"attack": {"key": "char.attack", "pct": false},
	"defense": {"key": "char.defense", "pct": false},
	"crit_chance": {"key": "char.crit", "pct": true},
	"crit_damage": {"key": "char.critdmg", "pct": true},
	"move_speed": {"key": "char.speed", "pct": false},
}

# ----------------------------------------------------------------------------
# SKILL TREE — 3 branches x 4 nodes. effects apply per rank via SaveSystem.
# ----------------------------------------------------------------------------
const SKILLS := {
	"blade_1": {
		"branch": "blade", "cost": 1, "max_rank": 3, "requires": [],
		"name": {"fa": "تیغ برنده", "en": "Keen Edge"},
		"desc": {"fa": "۶٪ حمله به ازای هر رتبه", "en": "+6% attack per rank"},
		"effects": [{"attr": "attack", "per_rank": 1.6}],
	},
	"blade_2": {
		"branch": "blade", "cost": 2, "max_rank": 2, "requires": ["blade_1"],
		"name": {"fa": "ضربه‌ی باغض", "en": "Critical Edge"},
		"desc": {"fa": "۳٪ شانس باغض به ازای هر رتبه", "en": "+3% crit chance per rank"},
		"effects": [{"attr": "crit_chance", "per_rank": 0.03}],
	},
	"blade_3": {
		"branch": "blade", "cost": 3, "max_rank": 2, "requires": ["blade_2"],
		"name": {"fa": "خون‌ریز", "en": "Bloodletting"},
		"desc": {"fa": "باغض ۲۰٪ آسیب بیشتر، هر رتبه", "en": "Crits deal +20% damage per rank"},
		"effects": [{"attr": "crit_damage", "per_rank": 0.2}],
	},
	"blade_4": {
		"branch": "blade", "cost": 4, "max_rank": 1, "requires": ["blade_3"],
		"name": {"fa": "طوفان شمشیر", "en": "Sword Storm"},
		"desc": {"fa": "کمبو سوم ۵۰٪ آسیب بیشتر", "en": "Final combo strike deals +50%"},
		"effects": [{"attr": "combo3_damage", "per_rank": 0.5}],
	},
	"fleet_1": {
		"branch": "fleet", "cost": 1, "max_rank": 3, "requires": [],
		"name": {"fa": "گام باد", "en": "Wind Step"},
		"desc": {"fa": "۳٪ سرعت حرکت هر رتبه", "en": "+3% move speed per rank"},
		"effects": [{"attr": "move_speed", "per_rank": 14.0}],
	},
	"fleet_2": {
		"branch": "fleet", "cost": 2, "max_rank": 2, "requires": ["fleet_1"],
		"name": {"fa": "پرش سایه", "en": "Shadow Leap"},
		"desc": {"fa": "پرش دوگانه بلندتر", "en": "Higher double jump"},
		"effects": [{"attr": "double_jump", "per_rank": 40.0}],
	},
	"fleet_3": {
		"branch": "fleet", "cost": 2, "max_rank": 2, "requires": ["fleet_2"],
		"name": {"fa": "دفاع سایه", "en": "Shade Ward"},
		"desc": {"fa": "۲ دفاع هر رتبه", "en": "+2 defense per rank"},
		"effects": [{"attr": "defense", "per_rank": 2.0}],
	},
	"fleet_4": {
		"branch": "fleet", "cost": 3, "max_rank": 1, "requires": ["fleet_3"],
		"name": {"fa": "وقار نینجا", "en": "Ninja Vigor"},
		"desc": {"fa": "+۴۰ جان بیشینه", "en": "+40 max health"},
		"effects": [{"attr": "max_hp", "per_rank": 40.0}],
	},
	"shade_1": {
		"branch": "shade", "cost": 1, "max_rank": 3, "requires": [],
		"name": {"fa": "یورش سایه", "en": "Shadow Rush"},
		"desc": {"fa": "یورش آسیب بیشتری دارد", "en": "Dash deals more damage"},
		"effects": [{"attr": "dash_damage", "per_rank": 8.0}],
	},
	"shade_2": {
		"branch": "shade", "cost": 2, "max_rank": 2, "requires": ["shade_1"],
		"name": {"fa": "نفس آرام", "en": "Calm Breath"},
		"desc": {"fa": "انرژی ویژه سریع‌تر پر می‌شود", "en": "Special charges faster"},
		"effects": [{"attr": "special_rate", "per_rank": 0.15}],
	},
	"shade_3": {
		"branch": "shade", "cost": 3, "max_rank": 2, "requires": ["shade_2"],
		"name": {"fa": "خون‌آشام سایه", "en": "Shadow Leech"},
		"desc": {"fa": "کمبو سوم مقداری جان می‌دهد", "en": "Final combo strike heals"},
		"effects": [{"attr": "combo3_leech", "per_rank": 6.0}],
	},
	"shade_4": {
		"branch": "shade", "cost": 4, "max_rank": 1, "requires": ["shade_3"],
		"name": {"fa": "انفجار ارباب سایه", "en": "Shadowlord Burst"},
		"desc": {"fa": "حمله‌ی ویژه ۴۰٪ قوی‌تر", "en": "Special attack +40% damage"},
		"effects": [{"attr": "special_damage", "per_rank": 0.4}],
	},
}

const SKILL_BRANCHES := ["blade", "fleet", "shade"]

# ----------------------------------------------------------------------------
# ITEMS — slot: weapon/armor/accessory/potion. rarity drives stat multipliers.
# stat_value(def, stat, rarity, plus) computes final value.
# ----------------------------------------------------------------------------
const RARITY_MULT := {"common": 1.0, "rare": 1.25, "epic": 1.55, "legendary": 1.95, "mythic": 2.5}
const PLUS_MULT := 0.12  # +12% per upgrade level

const ITEMS := {
	"katana_basic": {
		"slot": "weapon", "type": "weapon", "price": 0, "sell": 25,
		"name": {"fa": "کاتانای سایه", "en": "Shadow Katana"},
		"desc": {"fa": "تیغه‌ی جنگاوران گمنام", "en": "Blade of nameless warriors"},
		"stats": {"attack": 6.0},
	},
	"katana_crimson": {
		"slot": "weapon", "type": "weapon", "price": 1200, "sell": 300,
		"name": {"fa": "کاتانای سرخ", "en": "Crimson Fang"},
		"desc": {"fa": "لبه‌اش هنوز گرم است", "en": "Its edge is still warm"},
		"stats": {"attack": 14.0, "crit_damage": 0.15},
	},
	"katana_abyssal": {
		"slot": "weapon", "type": "weapon", "price": 4800, "sell": 900,
		"name": {"fa": "کاتانای پرتگاه", "en": "Abyssal Edge"},
		"desc": {"fa": "از تاریکی‌های معبد بیرون کشیده شد", "en": "Pulled from the temple dark"},
		"stats": {"attack": 26.0, "crit_chance": 0.05},
	},
	"katana_void": {
		"slot": "weapon", "type": "weapon", "price": 12000, "sell": 2200,
		"name": {"fa": "تیغه‌ی پوچی", "en": "Void Reaver"},
		"desc": {"fa": "برش می‌زند؛ حتی در برابر نور", "en": "It cuts even the light"},
		"stats": {"attack": 42.0, "crit_chance": 0.08, "crit_damage": 0.3},
	},
	"cloak_basic": {
		"slot": "armor", "type": "armor", "price": 0, "sell": 20,
		"name": {"fa": "عبای ساده", "en": "Wanderer's Cloak"},
		"desc": {"fa": "خاک جاده هنوز روی آن است", "en": "Still smells of the road"},
		"stats": {"max_hp": 20.0, "defense": 2.0},
	},
	"armor_nightweave": {
		"slot": "armor", "type": "armor", "price": 900, "sell": 220,
		"name": {"fa": "بفت شب", "en": "Nightweave"},
		"desc": {"fa": "قاليچه‌ای از ابریشم و سایه", "en": "Woven of silk and shadow"},
		"stats": {"max_hp": 45.0, "defense": 5.0},
	},
	"armor_kingdom": {
		"slot": "armor", "type": "armor", "price": 3600, "sell": 700,
		"name": {"fa": "پناه پادشاهی", "en": "Kingdom Bulwark"},
		"desc": {"fa": "آخرین زره‌ی نگهبانان", "en": "Last armor of the guard"},
		"stats": {"max_hp": 90.0, "defense": 10.0},
	},
	"armor_abyss": {
		"slot": "armor", "type": "armor", "price": 9500, "sell": 1800,
		"name": {"fa": "پناه پرتگاه", "en": "Abyss Shell"},
		"desc": {"fa": "سرد است، همیشه", "en": "Cold to the touch, always"},
		"stats": {"max_hp": 150.0, "defense": 16.0, "move_speed": 20.0},
	},
	"ring_fleet": {
		"slot": "accessory", "type": "accessory", "price": 750, "sell": 180,
		"name": {"fa": "انگشتر چابکی", "en": "Ring of Fleet"},
		"desc": {"fa": "پاها سبک می‌شوند", "en": "The feet grow light"},
		"stats": {"move_speed": 35.0},
	},
	"ring_blood": {
		"slot": "accessory", "type": "accessory", "price": 2400, "sell": 500,
		"name": {"fa": "حلقه‌ی خون", "en": "Blood Loop"},
		"desc": {"fa": "ضربانش را می‌شنوی", "en": "You can hear it pulse"},
		"stats": {"crit_chance": 0.06, "crit_damage": 0.2},
	},
	"amulet_shade": {
		"slot": "accessory", "type": "accessory", "price": 5200, "sell": 1000,
		"name": {"fa": "تعویذ سایه", "en": "Shade Talisman"},
		"desc": {"fa": "سایه‌ها حافظ تو هستند", "en": "The shadows watch over you"},
		"stats": {"max_hp": 60.0, "defense": 6.0, "crit_chance": 0.04},
	},
	"potion_health": {
		"slot": "potion", "type": "potion", "price": 80, "sell": 25,
		"name": {"fa": "معجون جان", "en": "Health Potion"},
		"desc": {"fa": "۶۰ جان بازمی‌گرداند", "en": "Restores 60 health"},
		"stats": {"heal": 60.0},
	},
}

const RARITIES := ["common", "rare", "epic", "legendary", "mythic"]

## Drop rarity roll used by enemies / chests.
static func roll_rarity(luck: float) -> String:
	var r := randf() - luck * 0.15
	if r < 0.02:
		return "mythic"
	if r < 0.09:
		return "legendary"
	if r < 0.24:
		return "epic"
	if r < 0.5:
		return "rare"
	return "common"


static func stat_value(def: Dictionary, stat: String, rarity: String, plus: int) -> float:
	var base := float(def["stats"].get(stat, 0.0))
	return base * RARITY_MULT.get(rarity, 1.0) * (1.0 + PLUS_MULT * plus)


static func upgrade_cost(inst: Dictionary) -> int:
	var def: Dictionary = ITEMS.get(inst["id"], {})
	var base: int = max(120, def.get("price", 400) / 6)
	return int(base * pow(1.5, int(inst["plus"])))


# ----------------------------------------------------------------------------
# WORLDS & LEVELS
# ----------------------------------------------------------------------------
const WORLDS := [
	{
		"id": 1, "key": "w1", "theme": "forest",
		"name": {"fa": "جنگل فراموش‌شده", "en": "The Forgotten Forest"},
		"levels": 3, "ambience": "amb_forest",
		"enemies": ["shadow_wolf", "blood_archer", "shadow_assassin"],
		"boss": "abyss_lord",
		"tint": Color("2e6b6e"),
	},
	{
		"id": 2, "key": "w2", "theme": "cave",
		"name": {"fa": "غار نفرین‌شده", "en": "The Cursed Caves"},
		"levels": 3, "ambience": "amb_cave",
		"enemies": ["shadow_wolf", "dark_knight", "abyss_mage"],
		"boss": "crystal_tyrant",
		"tint": Color("3a5a8c"),
	},
	{
		"id": 3, "key": "w3", "theme": "kingdom",
		"name": {"fa": "پادشاهی ویران", "en": "The Ruined Kingdom"},
		"levels": 3, "ambience": "amb_kingdom",
		"enemies": ["dark_knight", "blood_archer", "shadow_assassin", "abyss_mage"],
		"boss": "ash_monarch",
		"tint": Color("8c6a4a"),
	},
	{
		"id": 4, "key": "w4", "theme": "temple",
		"name": {"fa": "معبد پرتگاه", "en": "The Abyss Temple"},
		"levels": 3, "ambience": "amb_temple",
		"enemies": ["abyss_mage", "dark_knight", "shadow_assassin"],
		"boss": "void_sovereign",
		"tint": Color("7a5a9c"),
	},
]

const LEVEL_NAMES := {
	"w1_l1": {"fa": "دروازه‌ی جنگل", "en": "Forest Gate"},
	"w1_l2": {"fa": "مسیر خارها", "en": "Thorn Path"},
	"w1_l3": {"fa": "محله‌ی ارباب پرتگاه", "en": "Lord's Approach"},
	"w2_l1": {"fa": "ورودی غار", "en": "Cave Mouth"},
	"w2_l2": {"fa": "تالار بلور", "en": "Crystal Hall"},
	"w2_l3": {"fa": "آشیانه‌ی تیران", "en": "Tyrant's Nest"},
	"w3_l1": {"fa": "دروازه‌ی شکسته", "en": "Broken Gate"},
	"w3_l2": {"fa": "خیابان‌های خاکستر", "en": "Ash Streets"},
	"w3_l3": {"fa": "قصر خاکستر", "en": "Ashen Keep"},
	"w4_l1": {"fa": "پله‌های معبد", "en": "Temple Steps"},
	"w4_l2": {"fa": "سالن سنگ‌های شناور", "en": "Floating Stones"},
	"w4_l3": {"fa": "قلب معبد", "en": "Temple Heart"},
}

## Enemy base stats; scaled by world index and level.
const ENEMY_STATS := {
	"shadow_wolf":     {"hp": 55, "damage": 12, "speed": 240.0, "gold": [8, 16], "xp": 14, "detect": 560.0, "attack_range": 96.0},
	"dark_knight":     {"hp": 140, "damage": 22, "speed": 120.0, "gold": [18, 34], "xp": 30, "detect": 480.0, "attack_range": 130.0},
	"blood_archer":    {"hp": 70, "damage": 14, "speed": 110.0, "gold": [14, 26], "xp": 22, "detect": 820.0, "attack_range": 560.0},
	"abyss_mage":      {"hp": 85, "damage": 18, "speed": 90.0, "gold": [20, 38], "xp": 34, "detect": 700.0, "attack_range": 520.0},
	"shadow_assassin": {"hp": 90, "damage": 20, "speed": 300.0, "gold": [16, 30], "xp": 26, "detect": 640.0, "attack_range": 120.0},
}

## Difficulty scaling: world 1..4, level 1..3, plus endless depth.
static func enemy_scale(world: int, level: int, depth: int = 0) -> float:
	return 1.0 + 0.35 * (world - 1) + 0.12 * (level - 1) + 0.10 * depth

# ----------------------------------------------------------------------------
# IAP CATALOG (Part 18) — ids must be registered in each marketplace panel.
# Prices are NEVER invented; they come from the marketplace SDK at runtime.
# ----------------------------------------------------------------------------
const PRODUCTS := {
	"gems_100":  {"type": "consumable", "grant": {"gems": 100}},
	"gems_500":  {"type": "consumable", "grant": {"gems": 500}},
	"gems_1200": {"type": "consumable", "grant": {"gems": 1200}},
	"gems_2500": {"type": "consumable", "grant": {"gems": 2500}},
	"gold_10000": {"type": "consumable", "grant": {"gold": 10000}},
	"gold_50000": {"type": "consumable", "grant": {"gold": 50000}},
	"remove_ads": {"type": "non_consumable", "grant": {"entitlement": "remove_ads"}},
	"shadow_ninja_premium_skin": {"type": "non_consumable", "grant": {"entitlement": "skin_premium", "cosmetic": "ninja_gold"}},
	"legendary_katana_skin": {"type": "non_consumable", "grant": {"entitlement": "skin_katana", "cosmetic": "katana_legend"}},
	"premium_cosmetic_bundle": {"type": "non_consumable", "grant": {"entitlement": "bundle_premium", "cosmetic": "ninja_gold,katana_legend"}},
}

const SHOP_PRODUCT_ORDER := [
	"gems_100", "gems_500", "gems_1200", "gems_2500", "gold_10000", "gold_50000",
	"remove_ads", "shadow_ninja_premium_skin", "legendary_katana_skin", "premium_cosmetic_bundle",
]

## Gold-price equivalents for shop items purchasable with soft currency.
const SHOP_GEM_EXCHANGE := {"gold_1000": {"gems": 10, "gold": 1000}}

# ----------------------------------------------------------------------------
# ACHIEVEMENTS
# ----------------------------------------------------------------------------
const ACHIEVEMENTS := {
	"first_blood": {"reward": 5, "key": "ach.first_blood", "dkey": "ach.first_blood_d"},
	"slayer_100": {"reward": 15, "key": "ach.slayer_100", "dkey": "ach.slayer_100_d"},
	"slayer_1000": {"reward": 60, "key": "ach.slayer_1000", "dkey": "ach.slayer_1000_d"},
	"boss_slayer": {"reward": 20, "key": "ach.boss_slayer", "dkey": "ach.boss_slayer_d"},
	"wayfarer": {"reward": 10, "key": "ach.wayfarer", "dkey": "ach.wayfarer_d"},
	"w1_clear": {"reward": 25, "key": "ach.w1_clear", "dkey": "ach.w1_clear_d"},
	"w3_clear": {"reward": 50, "key": "ach.w3_clear", "dkey": "ach.w3_clear_d"},
	"abyss_10": {"reward": 20, "key": "ach.abyss_10", "dkey": "ach.abyss_10_d"},
	"abyss_25": {"reward": 60, "key": "ach.abyss_25", "dkey": "ach.abyss_25_d"},
	"combo_master": {"reward": 10, "key": "ach.combo_master", "dkey": "ach.combo_master_d"},
	"rich": {"reward": 30, "key": "ach.rich", "dkey": "ach.rich_d"},
	"mythic": {"reward": 40, "key": "ach.mythic", "dkey": "ach.mythic_d"},
}

# ----------------------------------------------------------------------------
# DAILY CHALLENGES — deterministic per date, seeded pick.
# ----------------------------------------------------------------------------
const DAILY_POOL := [
	"kills:30", "kills:60", "kills:100",
]


static func daily_challenge(date_string: String) -> String:
	var h := 0
	for c in date_string:
		h = (h * 31 + c.unicode_at(0)) % 997
	return DAILY_POOL[h % DAILY_POOL.size()]


# ----------------------------------------------------------------------------
# ENDLESS ABYSS tuning
# ----------------------------------------------------------------------------
const ABYSS := {
	"rooms_per_boss": 4,
	"score_per_room": 250,
	"score_per_boss": 1200,
	"depth_scale": 0.10,   # enemy scale per depth
}
