extends Node
## BillingBridge — marketplace in-app purchase state machine (Godot side).
##
## Talks to native Android plugins through Engine singletons:
##   - "PoolakeyPlugin" (Cafe Bazaar, Poolakey SDK 2.1.0) -> android/plugin/poolakey_bridge
##   - "MyketPlugin"    (Myket Billing Client 2.2)        -> android/plugin/myket_bridge
## The active plugin is chosen in this order:
##   1. SL_MARKET environment variable (dev override),
##   2. application/config/marketplace project setting,
##   3. runtime detection: whichever plugin singleton actually loaded
##      (each export preset ships exactly one plugin — see export_presets.cfg).
##      This is the mechanism that really reaches the APK; preset-only custom
##      options are not baked into the package.
##
## SECURITY MODEL (documented in documentation/MARKETPLACE_INTEGRATION.md):
##  - Signature verification happens in Kotlin (Poolakey SecurityCheck.Enable /
##    Myket IabHelper internal verification) against the marketplace public key.
##  - purchase_success carries signature_valid=false when verification could
##    not be performed (no key configured) — purchases are then REJECTED here.
##  - Items are granted ONLY on purchase_success (non-consumables) or
##    consume_success (consumables) callbacks from the plugin.
##  - Transaction ids are logged and persisted; duplicates are ignored.
##  - Pending purchases are stored and recovered on next launch.

signal state_changed(new_state: int)
signal products_loaded(products: Array)          # [{id,title,price,type}]
signal purchase_succeeded(product_id: String)
signal purchase_failed(product_id: String, reason: String)
signal purchase_canceled(product_id: String)
signal purchase_pending(product_id: String)
signal restore_finished(count: int)

enum S { DISABLED, IDLE, CONNECTING, LOADING_PRODUCTS, PURCHASING, PENDING,
		  PURCHASED, VERIFYING, CONSUMED, FAILED, CANCELED, RESTORED }

const MARKET_BAZAAR := "bazaar"
const MARKET_MYKET := "myket"
const LOG_PATH := "user://transactions.log"

var state: int = S.DISABLED
var marketplace := ""
var products: Array = []                 # latest product list from the market
var _plugin: Object = null               # Android plugin singleton
var _pending_product := ""
var _initialized := false


func _ready() -> void:
	marketplace = OS.get_environment("SL_MARKET")
	if marketplace.is_empty():
		marketplace = String(ProjectSettings.get_setting("application/config/marketplace", ""))
	if marketplace.is_empty() or _android_plugin_available() == false:
		marketplace = _detect_marketplace()
	_set_state(S.IDLE if _android_plugin_available() else S.DISABLED)
	if not is_disabled():
		call_deferred("initialize")
	_recover_pending()


func is_disabled() -> bool:
	return state == S.DISABLED or _plugin == null


func _android_plugin_available() -> bool:
	if OS.get_name() != "Android":
		return false
	var pname := "PoolakeyPlugin" if marketplace == MARKET_BAZAAR else "MyketPlugin"
	return Engine.has_singleton(pname)


func _detect_marketplace() -> String:
	# Pick the store that actually shipped inside this APK: each export preset
	# enables exactly one billing plugin (export_presets.cfg plugins/* toggles),
	# so the loaded singleton identifies the marketplace unambiguously.
	if Engine.has_singleton("PoolakeyPlugin"):
		return MARKET_BAZAAR
	if Engine.has_singleton("MyketPlugin"):
		return MARKET_MYKET
	return MARKET_BAZAAR


# ----------------------------------------------------------------------------
# Lifecycle
# ----------------------------------------------------------------------------
func initialize() -> void:
	if is_disabled():
		_log("init skipped: no plugin (desktop or plugin missing)")
		return
	_set_state(S.CONNECTING)
	_plugin = Engine.get_singleton(
		"PoolakeyPlugin" if marketplace == MARKET_BAZAAR else "MyketPlugin")
	_connect_signals()
	_log("init: market=%s" % marketplace)
	_plugin.initialize()


func _connect_signals() -> void:
	_plugin.billing_connected.connect(_on_connected)
	_plugin.billing_disconnected.connect(_on_disconnected)
	_plugin.connect_failed.connect(_on_connect_failed)
	_plugin.products_loaded.connect(_on_products)
	_plugin.purchase_success.connect(_on_purchase_success)
	_plugin.purchase_failure.connect(_on_purchase_failure)
	_plugin.purchase_canceled.connect(_on_purchase_canceled)
	_plugin.consume_success.connect(_on_consume_success)
	_plugin.consume_failure.connect(_on_consume_failure)
	_plugin.purchases_restored.connect(_on_restored)
	_plugin.purchase_pending.connect(_on_purchase_pending)


# ----------------------------------------------------------------------------
# Products
# ----------------------------------------------------------------------------
func request_products() -> void:
	if is_disabled():
		return
	_set_state(S.LOADING_PRODUCTS)
	# Plugin methods are the exact camelCase Kotlin names (Godot does NOT
	# convert snake_case for Android plugin methods) and take a JSON string.
	_plugin.queryProducts(JSON.stringify(GameDB.SHOP_PRODUCT_ORDER))


func product_price(id: String) -> String:
	for p in products:
		if p["id"] == id:
			return p["price"]
	return ""


func has_product(id: String) -> bool:
	for p in products:
		if p["id"] == id:
			return true
	return false


# ----------------------------------------------------------------------------
# Purchase flow
# ----------------------------------------------------------------------------
func purchase(product_id: String) -> void:
	if is_disabled():
		purchase_failed.emit(product_id, "billing_unavailable")
		return
	if SaveSystem.has_entitlement(product_id):
		purchase_failed.emit(product_id, "already_owned")
		return
	_pending_product = product_id
	_set_state(S.PURCHASING)
	_log("launch purchase flow: %s" % product_id)
	_plugin.launchPurchase(product_id)


func consume(product_id: String, purchase_token: String) -> void:
	if is_disabled():
		return
	_set_state(S.VERIFYING)
	_log("consume: %s token=%s" % [product_id, purchase_token])
	# Poolakey consumes by token; the Myket SDK consumes Purchase objects and
	# resolves the matching purchase from the inventory by token.
	_plugin.consume(purchase_token)


func restore_purchases() -> void:
	if is_disabled():
		return
	_log("restore purchases")
	_plugin.restorePurchases()


# ----------------------------------------------------------------------------
# Plugin callbacks — the ONLY place where items are granted
# ----------------------------------------------------------------------------
func _on_connected() -> void:
	_log("billing connected")
	request_products()


func _on_disconnected() -> void:
	_log("billing disconnected")
	if state == S.PURCHASING:
		_set_state(S.FAILED)


func _on_connect_failed(message: String) -> void:
	_log("connect failed: " + message)
	_set_state(S.FAILED)


func _on_products(payload: String) -> void:
	# The Kotlin plugins emit a JSON array STRING, not a GDScript Array.
	var parsed = JSON.parse_string(payload)
	if parsed == null or typeof(parsed) != TYPE_ARRAY:
		_log("products payload malformed: " + payload)
		parsed = []
	products = parsed
	_set_state(S.IDLE)
	_log("products loaded: %d" % products.size())
	products_loaded.emit(products)


func _on_purchase_success(product_id: String, purchase_token: String, signature_valid: bool) -> void:
	_log("purchase success: %s token=%s sig_valid=%s" % [product_id, purchase_token, signature_valid])
	# The plugin has already verified the signature against the market key.
	if not signature_valid:
		_log("REJECT: invalid signature — nothing granted")
		_set_state(S.FAILED)
		purchase_failed.emit(product_id, "invalid_signature")
		return
	_set_state(S.PURCHASED)
	SaveSystem.set_pending_tx(purchase_token, product_id)
	var def: Dictionary = GameDB.PRODUCTS.get(product_id, {})
	if def.get("type", "") == "consumable":
		# Deliver consumables only after the consume workflow succeeds.
		_set_state(S.VERIFYING)
		consume(product_id, purchase_token)
	else:
		_grant(product_id, purchase_token)
		_set_state(S.RESTORED)
		purchase_succeeded.emit(product_id)


func _on_purchase_pending(product_id: String) -> void:
	_log("purchase pending: %s" % product_id)
	_set_state(S.PENDING)
	purchase_pending.emit(product_id)


func _on_purchase_failure(product_id: String, message: String) -> void:
	_log("purchase failure: %s (%s)" % [product_id, message])
	_set_state(S.FAILED)
	purchase_failed.emit(product_id, message)


func _on_purchase_canceled(product_id: String) -> void:
	_log("purchase canceled: %s" % product_id)
	_set_state(S.CANCELED)
	purchase_canceled.emit(product_id)


func _on_consume_success(purchase_token: String) -> void:
	var product_id: String = SaveSystem.pending_txs().get(purchase_token, _pending_product)
	_log("consume success: token=%s product=%s" % [purchase_token, product_id])
	SaveSystem.record_consumed_tx(purchase_token)
	SaveSystem.clear_pending_tx(purchase_token)
	if product_id != "":
		_grant(product_id, purchase_token)
	_set_state(S.CONSUMED)
	if product_id != "":
		purchase_succeeded.emit(product_id)


func _on_consume_failure(purchase_token: String, message: String) -> void:
	_log("consume failure: %s (%s)" % [purchase_token, message])
	_set_state(S.FAILED)


func _on_restored(payload: String) -> void:
	# The Kotlin plugins emit a JSON array STRING of {"id":..,"token":..} dicts.
	var parsed = JSON.parse_string(payload)
	if parsed == null or typeof(parsed) != TYPE_ARRAY:
		_log("restore payload malformed: " + payload)
		parsed = []
	var count := 0
	for entry in parsed:
		var id := ""
		var token := ""
		if typeof(entry) == TYPE_DICTIONARY:
			id = String(entry.get("id", ""))
			token = String(entry.get("token", ""))
		elif typeof(entry) == TYPE_STRING:
			id = String(entry)
		if id.is_empty():
			continue
		# Crash recovery: a token that matches a pending transaction is resolved.
		if not token.is_empty() and SaveSystem.pending_txs().has(token):
			_log("recovered pending tx %s -> %s" % [token, id])
			SaveSystem.clear_pending_tx(token)
		var def: Dictionary = GameDB.PRODUCTS.get(id, {})
		if def.get("type", "") == "non_consumable" and not SaveSystem.has_entitlement(id):
			_grant(id, token if not token.is_empty() else "restore")
			count += 1
	_set_state(S.RESTORED)
	_log("restored %d entitlements" % count)
	restore_finished.emit(count)


func _grant(product_id: String, tx_id: String) -> void:
	if SaveSystem.tx_already_processed(tx_id) and tx_id != "restore":
		_log("duplicate grant blocked: tx=%s" % tx_id)
		return
	var def: Dictionary = GameDB.PRODUCTS.get(product_id, {})
	if def.is_empty():
		_log("unknown product grant attempt: " + product_id)
		return
	var grant: Dictionary = def["grant"]
	if grant.has("gems"):
		SaveSystem.add_gems(int(grant["gems"]))
	if grant.has("gold"):
		SaveSystem.add_gold(int(grant["gold"]))
	if grant.has("entitlement"):
		SaveSystem.grant_entitlement(product_id)
	if grant.has("cosmetic"):
		SaveSystem.set_setting("cosmetic_" + product_id, grant["cosmetic"])
	_log("granted: %s tx=%s" % [product_id, tx_id])


# ----------------------------------------------------------------------------
# Crash recovery: pending transactions recorded before a crash are re-checked.
# The plugin re-queries owned purchases; grants happen via restore flow only.
# ----------------------------------------------------------------------------
func _recover_pending() -> void:
	for tx_id in SaveSystem.pending_txs().keys():
		_log("recovering pending tx on launch: %s -> %s" % [tx_id, SaveSystem.pending_txs()[tx_id]])
	if not SaveSystem.pending_txs().is_empty() and not is_disabled():
		restore_purchases()


# ----------------------------------------------------------------------------
# Logging
# ----------------------------------------------------------------------------
func _log(line: String) -> void:
	var f := FileAccess.open(LOG_PATH, FileAccess.READ_WRITE)
	if f == null:
		f = FileAccess.open(LOG_PATH, FileAccess.WRITE)
	if f:
		f.seek_end()
		f.store_line("%s | %s | %s" % [Time.get_datetime_string_from_system(false, true), _state_name(), line])


func _set_state(s: int) -> void:
	if state != s:
		state = s
		state_changed.emit(s)


func _state_name() -> String:
	return S.keys()[state]
