extends Area2D
class_name Coin
## Gold coin pickup — bursts out, then homes to the player.

var value := 5.0
var _vel := Vector2.ZERO
var _homing := false
var _t := 0.0


static func spawn(parent: Node, pos: Vector2, v: float) -> Coin:
	var c := Coin.new()
	c.global_position = pos
	c.value = v
	c.collision_layer = Globals.L_PICKUP
	c.collision_mask = Globals.L_PLAYER
	var s := Sprite2D.new()
	s.texture = load("res://assets/icons/coin.png")
	s.scale = Vector2(0.8, 0.8)
	c.add_child(s)
	var col := CollisionShape2D.new()
	var sh := CircleShape2D.new()
	sh.radius = 26.0
	col.shape = sh
	c.add_child(col)
	parent.add_child(c)
	c._vel = Vector2(randf_range(-140, 140), randf_range(-320, -180))
	return c


func _ready() -> void:
	body_entered.connect(_on_body)


func _physics_process(delta: float) -> void:
	_t += delta
	if not _homing:
		_vel.y += 1400.0 * delta
		global_position += _vel * delta
		if _t > 0.55:
			_homing = true
	else:
		var p := _find_player()
		if p:
			global_position = global_position.lerp(p.global_position + Vector2(0, -40), minf(1.0, 10.0 * delta))
		if _t > 3.5:
			queue_free()


func _find_player() -> Player:
	return get_tree().get_first_node_in_group("player") as Player


func _on_body(body: Node) -> void:
	if body is Player:
		SaveSystem.add_gold(int(round(value)))
		AudioManager.sfx("coin", -4.0)
		queue_free()
