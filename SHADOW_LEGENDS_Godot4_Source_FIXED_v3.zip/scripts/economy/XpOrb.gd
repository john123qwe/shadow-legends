extends Area2D
class_name XpOrb
## XP pickup — floats, homes to the player.

var xp := 10


static func spawn(parent: Node, pos: Vector2, v: int) -> XpOrb:
	var o := XpOrb.new()
	o.global_position = pos
	o.xp = v
	o.collision_layer = Globals.L_PICKUP
	o.collision_mask = Globals.L_PLAYER
	var s := Sprite2D.new()
	s.texture = Vfx.tex("xp_orb")
	s.scale = Vector2(1.2, 1.2)
	o.add_child(s)
	var col := CollisionShape2D.new()
	var sh := CircleShape2D.new()
	sh.radius = 30.0
	col.shape = sh
	o.add_child(col)
	parent.add_child(o)
	return o


func _ready() -> void:
	body_entered.connect(_on_body)
	# gentle float
	var tw := create_tween().set_loops()
	tw.tween_property(self, "position:y", position.y - 14, 1.2).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	tw.tween_property(self, "position:y", position.y + 14, 1.2).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)


func _on_body(body: Node) -> void:
	if body is Player:
		SaveSystem.add_xp(xp)
		AudioManager.sfx("xp", -6.0)
		queue_free()
