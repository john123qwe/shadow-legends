extends EnemyBase
class_name AbyssLord
## THE ABYSS LORD — World 1 boss. Three combat phases:
##   P1 (100-66%): cleaver slam + ground charge
##   P2 (66-33%):  faster; adds rune orb barrages
##   P3 (<33%):    enraged; chains patterns, glowing rune overdrive
## Cinematic entrance (drop from the dark + roar + camera pan) and a
## slow-motion defeat sequence with rewards.

var phase := 1
var _pattern_i := 0
var _busy := false
var _dead_seq_running := false
var boss_name_fa := "ارباب پرتگاه"


func _ready() -> void:
	kind = "abyss_lord"
	is_boss = true
	anim_move = "walk"
	anim_attack = "slam"
	anim_hurt = "hurt"
	anim_death = "death"
	# boss stats (not from ENEMY_STATS table)
	max_hp = 1450.0
	hp = max_hp
	damage = 26.0
	speed = 150.0
	gold_range = Vector2i(320, 420)
	xp_value = 420
	detect_range = 1600.0
	attack_range = 190.0
	super._ready()
	sprite.scale = Vector2(1.15, 1.15)
	sprite.position = Vector2(0, -110)

	var col: CollisionShape2D = get_child(1)
	col.shape.size = Vector2(110, 200)
	col.position = Vector2(0, -100)
	attack_area.get_child(0).shape.size = Vector2(220, 130)
	attack_area.get_child(0).position = Vector2(110, -70)


func _body_size() -> Vector2:
	return Vector2(110, 200)


func _sprite_offset() -> Vector2:
	return Vector2(0, -110)


func entrance() -> void:
	## Cinematic: rises from the dark, roars, camera focuses.
	st = ST.RECOVER
	recover_t = 2.2
	global_position += Vector2(0, -420)
	sprite.modulate.a = 0.0
	var tw := create_tween()
	tw.tween_property(sprite, "modulate:a", 1.0, 1.2)
	EventBus.boss_engaged.emit(boss_name_fa)
	EventBus.boss_health_changed.emit(hp, max_hp)
	AudioManager.sfx("boss_roar")
	EventBus.screen_shake_requested.emit(12.0)
	await tw.finished
	_play("idle")


func _update_visual() -> void:
	# phase 3 tint
	if phase == 3 and st != ST.DEAD:
		var pulse := 0.5 + 0.5 * sin(Time.get_ticks_msec() * 0.008)
		sprite.modulate = Color(1.0 + pulse * 0.35, 1.0, 1.0)
	sprite.flip_h = facing < 0


func _can_attack() -> bool:
	return st == ST.CHASE and not _busy


func _do_chase(delta: float) -> void:
	if _busy:
		velocity.x = move_toward(velocity.x, 0, 800.0 * delta)
		return
	var dist := player.global_position.distance_to(global_position)
	facing = 1 if player.global_position.x > global_position.x else -1
	if dist <= attack_range or _should_pattern():
		_begin_pattern()
		return
	super._do_chase(delta)


func _should_pattern() -> bool:
	# occasionally open with a ranged/charge pattern even from afar
	return randf() < 0.006


func _begin_pattern() -> void:
	_busy = true
	st = ST.RECOVER  # hold still while the coroutine runs
	velocity.x = 0
	var dist := player.global_position.distance_to(global_position)
	var patterns: Array[String]
	match phase:
		1:
			patterns = ["slam", "charge"]
		2:
			patterns = ["slam", "charge", "barrage", "slam"]
		_:
			patterns = ["charge", "slam", "barrage", "slam", "barrage", "charge"]
	# distance-aware selection
	if dist > 400.0 and patterns.has("charge"):
		_pattern_i = patterns.find("charge")
	_run_pattern(patterns[_pattern_i % patterns.size()])
	_pattern_i += 1


func _run_pattern(p: String) -> void:
	match p:
		"slam":
			await _pattern_slam()
		"charge":
			await _pattern_charge()
		"barrage":
			await _pattern_barrage()
	_busy = false
	st = ST.CHASE


func _pattern_slam() -> void:
	_play("slam", true)
	await get_tree().create_timer(0.55).timeout
	if st == ST.DEAD:
		return
	# land the cleaver: damage arc in front + shockwave
	var origin := global_position + Vector2(facing * 120, -60)
	attack_area.set_deferred("monitoring", true)
	Vfx.shockwave(get_parent(), global_position + Vector2(facing * 120, -30))
	Vfx.dust(get_parent(), global_position + Vector2(facing * 120, 0))
	AudioManager.sfx("boss_slam")
	EventBus.screen_shake_requested.emit(10.0)
	var t := get_tree().create_timer(0.24)
	await t.timeout
	if st == ST.DEAD:
		return
	for body in attack_area.get_overlapping_bodies():
		if body is Player:
			body.take_damage(damage * 1.2, Vector2(facing * 420.0, -260.0))
	attack_area.set_deferred("monitoring", false)
	await get_tree().create_timer(0.5).timeout


func _pattern_charge() -> void:
	_play("charge", true)
	var dir := signf(player.global_position.x - global_position.x)
	dir = dir if dir != 0.0 else 1.0
	facing = int(dir)
	var hit_once := {}
	for i in range(20):
		if st == ST.DEAD:
			return
		velocity.x = dir * 900.0
		await get_tree().physics_frame
		move_and_slide()
		attack_area.set_deferred("monitoring", true)
		for body in attack_area.get_overlapping_bodies():
			if body is Player and not hit_once.has(body):
				hit_once[body] = true
				body.take_damage(damage, Vector2(dir * 520.0, -180.0))
	attack_area.set_deferred("monitoring", false)
	velocity.x = 0
	AudioManager.sfx("dash", -4.0)
	await get_tree().create_timer(0.4).timeout


func _pattern_barrage() -> void:
	_play("cast", true)
	AudioManager.sfx("ui_open", -6.0)
	await get_tree().create_timer(0.6).timeout
	if st == ST.DEAD:
		return
	var n := 5 if phase == 2 else 8
	for i in range(n):
		if st == ST.DEAD:
			return
		var from := global_position + Vector2(facing * 20, -160)
		var spread := deg_to_rad(randf_range(-35, 35))
		var dir := (player.global_position + Vector2(0, -60) - from).normalized().rotated(spread)
		Projectile.spawn(get_parent(), from, dir, damage * 0.55, "orb", player)
		await get_tree().create_timer(0.12).timeout
	await get_tree().create_timer(0.6).timeout


func _die() -> void:
	if _dead_seq_running:
		return
	_dead_seq_running = true
	st = ST.DEAD
	velocity = Vector2.ZERO
	collision_layer = 0
	attack_area.set_deferred("monitoring", false)
	# cinematic: hitstop, slow motion, dissolve
	EventBus.hitstop_requested.emit(0.12)
	Engine.time_scale = 0.35
	AudioManager.sfx("boss_roar")
	EventBus.screen_shake_requested.emit(14.0)
	_play("death", true)
	EventBus.boss_defeated.emit(kind)
	await sprite.animation_finished
	_drop_loot()
	var tw := create_tween()
	tw.tween_property(sprite, "modulate:a", 0.0, 1.4)
	tw.parallel().tween_property(sprite, "modulate", Color(0.7, 0.1, 0.15, 0.0), 1.4)
	await tw.finished
	Engine.time_scale = 1.0
	Vfx.dissolve(get_parent(), global_position)
	queue_free()
