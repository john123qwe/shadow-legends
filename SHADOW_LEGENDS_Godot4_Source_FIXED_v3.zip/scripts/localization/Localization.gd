extends Node
## Localization — Persian-first RTL string table with English fallback.
## Keys are namespaced strings; L10N.t("menu.start") returns localized text.
## Godot 4 ships an advanced text server with full BiDi, so Persian shaping
## and RTL layout work out of the box when layout_direction is RTL.

signal locale_changed(locale: String)

const STRINGS := {
	# ---- generic ----
	"common.play": {"fa": "شروع بازی", "en": "Play"},
	"common.continue": {"fa": "ادامه", "en": "Continue"},
	"common.back": {"fa": "بازگشت", "en": "Back"},
	"common.close": {"fa": "بستن", "en": "Close"},
	"common.confirm": {"fa": "تأیید", "en": "Confirm"},
	"common.cancel": {"fa": "لغو", "en": "Cancel"},
	"common.buy": {"fa": "خرید", "en": "Buy"},
	"common.equip": {"fa": "آماده‌سازی", "en": "Equip"},
	"common.equipped": {"fa": "آماده شده", "en": "Equipped"},
	"common.upgrade": {"fa": "ارتقا", "en": "Upgrade"},
	"common.sell": {"fa": "فروش", "en": "Sell"},
	"common.use": {"fa": "استفاده", "en": "Use"},
	"common.claim": {"fa": "دریافت", "en": "Claim"},
	"common.locked": {"fa": "قفل", "en": "Locked"},
	"common.level": {"fa": "سطح", "en": "Level"},
	"common.stars": {"fa": "ستاره", "en": "Stars"},
	"common.done": {"fa": "انجام شد", "en": "Done"},
	"common.ok": {"fa": "باشه", "en": "OK"},
	"common.max": {"fa": "حداکثر", "en": "MAX"},
	"common.new": {"fa": "جدید", "en": "NEW"},
	# ---- menu ----
	"menu.start": {"fa": "کمپین", "en": "Campaign"},
	"menu.endless": {"fa": "دره بی‌پایان", "en": "Endless Abyss"},
	"menu.character": {"fa": "نینجا", "en": "Character"},
	"menu.inventory": {"fa": "وسایل", "en": "Inventory"},
	"menu.shop": {"fa": "فروشگاه", "en": "Shop"},
	"menu.settings": {"fa": "تنظیمات", "en": "Settings"},
	"menu.achievements": {"fa": "دستاوردها", "en": "Achievements"},
	"menu.quit": {"fa": "خروج", "en": "Quit"},
	"menu.subtitle": {"fa": "افسانه‌ی سایه‌ها", "en": "Legends of the Shadows"},
	"menu.tap_to_start": {"fa": "برای شروع لمس کنید", "en": "Tap to start"},
	# ---- character ----
	"char.attributes": {"fa": "توانایی‌ها", "en": "Attributes"},
	"char.skills": {"fa": "مهارت‌ها", "en": "Skills"},
	"char.skill_points": {"fa": "امتیاز مهارت", "en": "Skill Points"},
	"char.hp": {"fa": "جان", "en": "Health"},
	"char.attack": {"fa": "حمله", "en": "Attack"},
	"char.defense": {"fa": "دفاع", "en": "Defense"},
	"char.crit": {"fa": "ضربه‌ی باغض", "en": "Crit Chance"},
	"char.critdmg": {"fa": "آسیب باغضی", "en": "Crit Damage"},
	"char.speed": {"fa": "سرعت حرکت", "en": "Move Speed"},
	"char.branch_blade": {"fa": "تیغه", "en": "Blade"},
	"char.branch_fleet": {"fa": "چابکی", "en": "Fleet"},
	"char.branch_shade": {"fa": "سایه", "en": "Shade"},
	# ---- inventory ----
	"inv.title": {"fa": "وسایل نینجا", "en": "Inventory"},
	"inv.empty": {"fa": "چیزی اینجا نیست...", "en": "Nothing here..."},
	"inv.weapon": {"fa": "کاتانا", "en": "Weapon"},
	"inv.armor": {"fa": "زره", "en": "Armor"},
	"inv.accessory": {"fa": "وردست", "en": "Accessory"},
	"inv.potion": {"fa": "معجون", "en": "Potion"},
	"inv.upgrade_cost": {"fa": "هزینه‌ی ارتقا", "en": "Upgrade cost"},
	# ---- shop ----
	"shop.title": {"fa": "فروشگاه", "en": "Shop"},
	"shop.potions": {"fa": "معجون جان", "en": "Health Potion"},
	"shop.gems": {"fa": "جواهرات", "en": "Gems"},
	"shop.cosmetics": {"fa": "ظاهرها", "en": "Cosmetics"},
	"shop.remove_ads": {"fa": "حذف تبلیغات", "en": "Remove Ads"},
	"shop.premium_skin": {"fa": "پوسته‌ی ویژه‌ی نینجا", "en": "Ninja Premium Skin"},
	"shop.katana_skin": {"fa": "کاتانای افسانه‌ای", "en": "Legendary Katana Skin"},
	"shop.bundle": {"fa": "بسته‌ی کامل ظاهرها", "en": "Premium Cosmetic Bundle"},
	"shop.price_pending": {"fa": "قیمت از بازار...", "en": "Price from market..."},
	"shop.billing_unavailable": {"fa": "فروش درون‌برنامه‌ای در این نسخه فعال نیست", "en": "In-app billing unavailable in this build"},
	"shop.purchased": {"fa": "خرید با موفقیت انجام شد", "en": "Purchase completed"},
	"shop.purchased_before": {"fa": "قبلاً خریداری شده", "en": "Already owned"},
	"shop.gold_pack": {"fa": "طلا", "en": "Gold"},
	# ---- worlds ----
	"world.w1": {"fa": "جنگل فراموش‌شده", "en": "The Forgotten Forest"},
	"world.w2": {"fa": "غار نفرین‌شده", "en": "The Cursed Caves"},
	"world.w3": {"fa": "پادشاهی ویران", "en": "The Ruined Kingdom"},
	"world.w4": {"fa": "معبد پرتگاه", "en": "The Abyss Temple"},
	"world.w5": {"fa": "دره‌ی بی‌پایان", "en": "Endless Abyss"},
	"world.locked": {"fa": "برای باز شدن، جهان قبل را تمام کنید", "en": "Clear the previous world to unlock"},
	# ---- gameplay ----
	"game.pause": {"fa": "توقف", "en": "Paused"},
	"game.resume": {"fa": "ادامه", "en": "Resume"},
	"game.restart": {"fa": "شروع دوباره", "en": "Restart"},
	"game.quit_to_menu": {"fa": "منوی اصلی", "en": "Main Menu"},
	"game.victory": {"fa": "پیروزی!", "en": "Victory!"},
	"game.game_over": {"fa": "شکست", "en": "Defeat"},
	"game.reward_gold": {"fa": "طلای دریافت‌شده", "en": "Gold earned"},
	"game.reward_xp": {"fa": "تجربه", "en": "XP earned"},
	"game.next_level": {"fa": "مرحله‌ی بعد", "en": "Next level"},
	"game.retry": {"fa": "تلاش دوباره", "en": "Retry"},
	"game.checkpoint": {"fa": "ایست بازرسی ذخیره شد", "en": "Checkpoint reached"},
	"game.abyss_depth": {"fa": "عمق", "en": "Depth"},
	"game.abyss_best": {"fa": "رکورد", "en": "Best"},
	"game.abyss_run_end": {"fa": "پایان این نفوذ", "en": "Run ended"},
	"game.special_ready": {"fa": "حمله‌ی ویژه آماده است!", "en": "Special ready!"},
	"game.tutorial_move": {"fa": "با اهرم چپ حرکت کن", "en": "Move with the left stick"},
	"game.tutorial_jump": {"fa": "دو بار پرش = پرش دوگانه", "en": "Tap jump twice to double jump"},
	"game.tutorial_attack": {"fa": "سه ضرب پیوسته کمبو می‌سازد", "en": "Chain three strikes for a combo"},
	# ---- achievements ----
	"ach.first_blood": {"fa": "نخستین خون", "en": "First Blood"},
	"ach.first_blood_d": {"fa": "نخستین دشمن را شکست بده", "en": "Defeat your first enemy"},
	"ach.slayer_100": {"fa": "شکارچی سایه‌ها", "en": "Shadow Slayer"},
	"ach.slayer_100_d": {"fa": "۱۰۰ دشمن را شکست بده", "en": "Defeat 100 enemies"},
	"ach.slayer_1000": {"fa": "افسانه‌ی مرگ", "en": "Legend of Death"},
	"ach.slayer_1000_d": {"fa": "۱۰۰۰ دشمن را شکست بده", "en": "Defeat 1000 enemies"},
	"ach.boss_slayer": {"fa": "کشنده‌ی اربابان", "en": "Lord Killer"},
	"ach.boss_slayer_d": {"fa": "نخستین باس را شکست بده", "en": "Defeat your first boss"},
	"ach.wayfarer": {"fa": "راهوار", "en": "Wayfarer"},
	"ach.wayfarer_d": {"fa": "سه مرحله را تمام کن", "en": "Complete 3 levels"},
	"ach.w1_clear": {"fa": "پاک‌سازی جنگل", "en": "Forest Cleansed"},
	"ach.w1_clear_d": {"fa": "جنگل فراموش‌شده را تمام کن", "en": "Clear The Forgotten Forest"},
	"ach.w3_clear": {"fa": "فتح پادشاهی", "en": "Kingdom Conquered"},
	"ach.w3_clear_d": {"fa": "پادشاهی ویران را تمام کن", "en": "Clear The Ruined Kingdom"},
	"ach.abyss_10": {"fa": "عمق ۱۰", "en": "Depth 10"},
	"ach.abyss_10_d": {"fa": "در دره‌ی بی‌پایان به عمق ۱۰ برس", "en": "Reach depth 10 in the Endless Abyss"},
	"ach.abyss_25": {"fa": "فراتر از مه", "en": "Beyond the Mist"},
	"ach.abyss_25_d": {"fa": "به عمق ۲۵ برس", "en": "Reach depth 25"},
	"ach.combo_master": {"fa": "استاد کمبو", "en": "Combo Master"},
	"ach.combo_master_d": {"fa": "کمبو کامل سه‌ضرب را بزن", "en": "Finish a full 3-hit combo"},
	"ach.rich": {"fa": "گنجینه", "en": "Hoarder"},
	"ach.rich_d": {"fa": "۵٬۰۰۰ طلا انباشته کن", "en": "Hold 5,000 gold"},
	"ach.mythic": {"fa": "افسانه‌ای", "en": "Mythic"},
	"ach.mythic_d": {"fa": "یک وسیله‌ی افسانه‌ای به دست بیاور", "en": "Own a legendary item"},
	# ---- settings ----
	"set.title": {"fa": "تنظیمات", "en": "Settings"},
	"set.music": {"fa": "موسیقی", "en": "Music"},
	"set.sfx": {"fa": "جلوه‌های صوتی", "en": "Sound Effects"},
	"set.persian_digits": {"fa": "اعداد فارسی", "en": "Persian digits"},
	"set.language": {"fa": "زبان", "en": "Language"},
	"set.controls": {"fa": "دکمه‌های لمسی", "en": "Touch buttons"},
	"set.button_scale": {"fa": "اندازه‌ی دکمه‌ها", "en": "Button size"},
	"set.shake": {"fa": "لرزش صفحه", "en": "Screen shake"},
	"set.reset": {"fa": "پاک کردن ذخیره", "en": "Reset save"},
	"set.reset_confirm": {"fa": "همه‌ی پیشرفت پاک شود؟", "en": "Erase all progress?"},
	"set.quality": {"fa": "کیفیت تصویر", "en": "Graphics quality"},
}

var locale := "fa"


func _ready() -> void:
	locale = SaveSystem.get_setting("locale", "fa")


func set_locale(l: String) -> void:
	if STRINGS.values().any(func(v): return v.has(l)) or l in ["fa", "en"]:
		locale = l
		SaveSystem.set_setting("locale", l)
		locale_changed.emit(l)


## Translate a key. Missing keys return the key itself (visible in dev).
func t(key: String) -> String:
	var entry: Dictionary = STRINGS.get(key, {})
	if entry.is_empty():
		return key
	if entry.has(locale):
		return entry[locale]
	return entry.get("fa", key)


## Persian digit formatting toggle-aware (delegates to Globals).
func num(n: int) -> String:
	return Globals.num(n)


func percent(v: float) -> String:
	return num(roundi(v * 100.0)) + "٪"
