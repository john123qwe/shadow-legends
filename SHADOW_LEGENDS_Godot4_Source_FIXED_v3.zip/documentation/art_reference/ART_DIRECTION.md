# SHADOW LEGENDS — Approved Art Direction

The two images in this folder are the user's approved visual references.

## Required look
- 2D side-scrolling dark-fantasy platformer.
- Misty teal / cyan-green forest atmosphere with visible depth.
- Black silhouette trees, cliffs, platforms, props, player and enemies.
- Distinct red glowing thorns, spikes and trap accents.
- Multi-layer parallax (sky, distant forest, middle forest, fog and foreground).
- Keep gameplay silhouettes readable; avoid crushing the whole scene into near-black.
- Use this visual identity consistently across campaign worlds while allowing each
  world to vary its scenery and color accents.

## Gameplay readability
- Platforms and hazards must remain clearly separated from the background.
- The player and enemies remain dark silhouettes, but should be visible against
  the lighter mist and forest layers.
- Red should be reserved for danger, hit effects and selected points of emphasis.

## Jump tuning update
A quick tap previously cut upward velocity to 35% immediately, which could make
short-touch jumps feel extremely low. The tap-jump cutoff is now 72% of the full
jump impulse, and the full jump impulse is slightly stronger. This is a source
change; it still needs on-device gameplay verification.
