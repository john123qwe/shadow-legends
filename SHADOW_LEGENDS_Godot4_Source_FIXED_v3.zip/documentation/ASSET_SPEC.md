# Asset Specification — SHADOW LEGENDS

This project's art direction is **locked** to the supplied concept references:
pure-black silhouettes on deep-teal fog atmosphere, red-tipped flora, glowing
red accents. All currently shipped assets are **original and procedurally
generated** by the scripts in the delivery bundle (`/scripts/art_*.py`) —
they are not placeholder rectangles; they are the intended silhouette style
with rendered detail (grass tufts, jagged rock, cloak waves, red eye glow).

If you commission hand-drawn replacements later, keep the specs below so the
pipeline (frames, anchors, scales) keeps working unchanged.

---

## 1. Shipped assets (original, generated)

### Backgrounds — `assets/backgrounds/` (1920×1080, tileable horizontally)
| File | Parallax factor | Content |
| --- | --- | --- |
| sky_w1..w4 | 0.0 | teal vertical gradient + vignette (w1 forest, w2 cave-blue, w3 kingdom-warm, w4 temple-violet) |
| far_w1..w4 | 0.15 | faded distant trees/bamboo |
| mid_w1..w4 | 0.30 | darker mid silhouettes |
| fog_w1..w4 | 0.55 | soft fog band |
| near_w1 | 0.85 | foreground black foliage frame |

### Platforms & props — `assets/environments/`
plat_wide/wide2 (1024×260), plat_mid (640×240), plat_small (320×210),
plat_float/float2 (~300-360×~220-240), plat_edge_l/r (512×260), pillar
(160×560), vine_0..2 (96×260), ruin_column (120×420), ruin_arch (460×360),
checkpoint_off/on (140×190), spike_plant/s/big (220×170 base), floor_spikes
(320×90), portal (180×220).

**Collision contract:** platform sprites are placed by top-left anchor; the
engine collision rectangle covers `min(h*0.55, 130)` px below the top edge.

### Characters — 128×128 frames (boss 256×256), horizontal strips
| Sheet | Animations (start, count, fps, loop) |
| --- | --- |
| characters/ninja_sheet.png (50 frames) | idle(0,4,6,1) run(4,8,13,1) jump(12,2,8,0) fall(14,2,8,1) attack1(16,4,16,0) attack2(20,4,16,0) attack3(24,5,15,0) dash(29,3,12,0) special(32,6,12,0) hurt(38,2,10,0) death(40,6,9,0) victory(46,4,6,1) |
| enemies/shadow_wolf_sheet.png (24) | idle(0,4) run(4,8) attack(12,4) hurt(16,2) death(18,6) |
| enemies/dark_knight_sheet.png (23) | idle(0,4) walk(4,6) attack(10,5) hurt(15,2) death(17,6) |
| enemies/blood_archer_sheet.png (22) | idle(0,4) walk(4,6) shoot(10,4) hurt(14,2) death(16,6) |
| enemies/abyss_mage_sheet.png (16) | idle(0,4) cast(4,4) hurt(8,2) death(10,6) |
| enemies/shadow_assassin_sheet.png (24) | idle(0,4) run(4,8) attack(12,4) hurt(16,2) death(18,6) |
| bosses/abyss_lord_sheet.png (40) | idle(0,6) walk(6,6) slam(12,6) charge(18,6) cast(24,6) hurt(30,2) death(32,8) |

All frames face **right**; flip via `flip_h`. Metadata is mirrored in
`scripts/player/SpriteLib.gd` — keep the two in sync.

### Effects — `assets/effects/`
slash_0..2 (160×160 red arcs), slash_3 special burst, impact (96), shockwave
(220), dash_trail (200×80), dash_ghost (128), arrow (64×20), orb (56),
particle_soft/red/teal, firefly (16), smoke (64), xp_orb (44).

### UI & icons — `assets/ui/`, `assets/icons/`
panel (96, 9-slice margins 24), btn/btn_pressed (160×64), bar_bg (280×30),
bar_red/gold/teal fills (274×24), rbtn_jump/attack/dash/special/pause (128),
icon_coin (72), icon_gem (72), item_weapon/armor/accessory/potion/material/skin
(96), icon_star_on/off (96), icon_skull, icon_gear, icon_coin small (56),
gem pickups, app icon set (192 / adaptive 432 fg+bg).

### Audio — `assets/audio/` (22050 Hz mono 16-bit WAV)
SFX: swish_1..3, special, hit_1, hit_crit, hurt, death, enemy_death, jump,
double_jump, dash, coin, gem, xp, heal, ui_click, ui_open, level_up,
checkpoint, portal, boss_roar, boss_slam, arrow, orb, trap.
Loops (seamless): music_menu, music_boss, amb_forest, amb_cave, amb_kingdom,
amb_temple. Stings: sting_victory, sting_defeat.

### Fonts — `assets/fonts/`
Vazirmatn Regular/Medium/Bold/Black — SIL OFL. Godot 4's advanced text server
handles Persian shaping + RTL natively; layout direction is set RTL at the
screen root (`UIKit.root_rtl`).

## 2. Missing assets (identified honestly)

| Asset | Status | Impact | Suggested fix |
| --- | --- | --- | --- |
| Composed music tracks | missing — synthesized ambient loops stand in | atmosphere depth on menus/boss | commission 2-3 dark-fantasy tracks or keep loops (they fit the mood) |
| Worlds 2-4 authored levels | environment art exists (recolored); levels not authored | worlds 2-4 playable only as endless-style rooms | author LevelDefs entries per world (~30 min each with the builder) |
| World-specific platform variants | platforms shared across themes | minor visual repetition | recolor/black shapes are theme-neutral by design |
| Bosses for worlds 2-4 (Crystal Tyrant, Ash Monarch, Void Sovereign) | ids reserved in GameDB; AbyssLord system reusable | worlds 2-4 have no unique boss | parameterize AbyssLord class per world (silhouette + palette + pattern weights) |
| Enemy variety beyond 5 | 5 required enemies shipped | — | none required for the spec |
| Rewarded-ad provider | intentionally disabled | no ad revenue until configured | see MARKETPLACE_INTEGRATION.md § 6 |

## 3. Commission replacement spec (if hand art is added later)

- Same frame counts/sizes per table above; horizontal strips; transparent PNG.
- Pivot: feet at y≈120/128 (boss 236/256); facing right.
- Palette contract: silhouette #0A0E10, accent red #C1272D/#FF2E40, blade
  #242C30 + edge #4A5C60, UI teal #3A6E70, gold #DEA83E.
- Export scale: draw at 1× listed sizes; in-game `Sprite.scale` handles DPR.
