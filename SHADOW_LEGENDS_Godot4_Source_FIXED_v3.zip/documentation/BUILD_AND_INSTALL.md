# Build & Install — SHADOW LEGENDS (from an Android phone)

You have an Android phone only. There are two practical paths to get the game
running on it. Both produce a **real native APK** — this project is pure Godot;
there is no web/HTML5 fallback.

---

## Path A — Cloud build via GitHub Actions (recommended, no PC needed)

The repo ships `.github/workflows/build_android.yml` which compiles two APKs
(Bazaar + Myket variants) plus an AAB in the cloud.

### Steps (all doable from the phone browser)

1. **Zip the project** and create a GitHub account at github.com.
2. In the GitHub web app: **New repository** → name it e.g. `shadow-legends`
   → create.
3. **Upload files**: in the repo, `Add file → Upload files`. Upload the
   *contents* of this folder (keep the `.github/workflows/` structure!). On a
   phone this is easiest by first unzipping, then uploading folders one by
   one. Alternatively use the GitHub mobile app or `git` via Termux.
4. Go to **Actions tab** → select **Build Android** → **Run workflow**.
5. Wait ~20–40 minutes (the workflow builds the two billing plugin AARs,
   validates the project headlessly, then exports three packages). Open the
   finished run → **Artifacts** → download `shadow-legends-android` → it
   contains:
   - `shadow_legends_bazaar.apk` (debug-signed)
   - `shadow_legends_myket.apk` (debug-signed)
   - `shadow_legends_bazaar.aab`
6. Install the APK: open it → Android will ask to allow installs from your
   browser ("install unknown apps") → allow → install.
7. Play. First launch asks nothing, needs nothing — the game is fully offline.

### Why debug-signed?

Debug APKs install and run on any phone — perfect for development testing.
Release signing with YOUR keystore happens once you have one (see
`MARKETPLACE_INTEGRATION.md` § Release signing) — that step requires the
keystore you create, so it cannot be done for you here.

---

## Path B — Build on the phone with Godot Editor (Android build via web IDE)

1. Use a cloud dev environment that exposes a desktop in the browser (e.g.
   GitHub Codespaces from the mobile browser).
2. In the Codespace terminal:
   ```bash
   wget https://github.com/godotengine/godot/releases/download/4.3-stable/Godot_v4.3-stable_linux.x86_64.zip
   unzip Godot_v4.3-stable_linux.x86_64.zip
   ./Godot_v4.3-stable_linux.x86_64 --editor --path .
   ```
3. Open `Editor → Editor Settings → Export → Android`, point at the Android
   SDK the codespace can install, then `Project → Export → Android
   (shadow_legends_bazaar) → Export Project`.
4. Download the APK back to the phone and install.

Path A is simpler; Path B gives you the full editor (useful for tuning).

---

## Requirements summary

| Component | Version | Needed for |
| --- | --- | --- |
| Godot | 4.3+ (GL Compatibility renderer default) | everything |
| Export templates | 4.3-stable | CI build (auto-downloaded) |
| Android SDK | platform 34, build-tools 34 | CI build (auto-installed) |
| Java | 17 | CI build |
| Billing plugins | built AARs in `res://android/plugins/` | IAP only — game runs without them |

## Verifying the install

- Launch → main menu shows the title with the animated ninja silhouette.
- `تنظیمات` (Settings) → sliders affect music/SFX immediately.
- Start `کمپین` → World 1 level 1 loads; movement/jump/combo work; dying
  respawns at the checkpoint.
- Force-close the app mid-level and reopen — progress (currencies, unlocks)
  is restored from the save file (`user://shadow_legends_save.json`).

## Troubleshooting

- **"Failed to load plugin PoolakeyPlugin"** — expected until you build the
  AARs (see MARKETPLACE_INTEGRATION.md § Building the plugins). The game
  runs fine without them; billing shows as unavailable.
- **Black screen on import** — wait for first import to finish; it can take
  a minute on low-end hardware.
- **Export fails in CI with gradle errors** — confirm `.github/workflows/`
  structure survived upload (folder starting with a dot can be missed by
  phone file managers; upload it via GitHub's web editor "Create new file →
  `.github/workflows/build_android.yml`" path manually if needed).
