# Marketplace Integration — Cafe Bazaar (Poolakey) & Myket

This document is the complete integration guide: what is implemented, what was
verified against official sources, what must be configured with real developer
credentials, and what remains untested. Nothing in this project fakes a
purchase; the GDScript side grants items **only** on verified success callbacks.

---

## 1. Architecture

```
GDScript BillingBridge (scripts/billing/BillingBridge.gd)
   │  Engine.get_singleton("PoolakeyPlugin" | "MyketPlugin")
   ▼
Kotlin GodotPlugin (Godot 4 Android plugin, AAR in res://android/plugins/)
   │
   ├── PoolakeyBridge.kt  → com.github.cafebazaar.Poolakey:poolakey:2.1.0 (JitPack)
   └── MyketBridge.kt     → ir.myket:billing:2.2 (https://maven.myket.ir)
```

### Plugin packaging (Godot 4.3, source-verified)

- `android/plugins/*.gdap` uses the **v1 plugin config format** that Godot 4.3
  still parses (deprecated but functional — `platform/android/export/godot_plugin_config.h`):
  `[config]` requires `name`, `binary_type="local"`, `binary="<AAR file name>"`;
  `[dependencies]` takes `remote=[...]` (gradle coordinates) and
  `custom_maven_repos=[...]` as **arrays**. The `entry_tag` / dictionary-style
  fields some old samples show do not exist in Godot 4.
- The AAR must sit next to the `.gdap` under `res://android/plugins/` with the
  exact `binary` file name (`PoolakeyBridge.aar` / `MyketBridge.aar`); the
  config is invalid (and the plugin excluded) otherwise.
- At **runtime** the plugin class is loaded via the merged manifest meta-data
  inside each AAR: `org.godotengine.plugin.v2.<Name>` whose `android:value` is
  the fully-qualified class name (`GodotPluginRegistry` does `Class.forName`).
- Export presets toggle which plugin ships: `plugins/PoolakeyPlugin=true`
  (Bazaar variants) vs `plugins/MyketPlugin=true` (Myket variant) — one store
  per build, the SDKs are never mixed.

### Store selection at runtime

BillingBridge picks the marketplace in this order:
1. `SL_MARKET` environment variable (dev override),
2. `application/config/marketplace` project setting,
3. **detection**: whichever plugin singleton actually loaded in the APK
   (each variant ships exactly one plugin). This is what really works,
   because custom export-preset options are not baked into the package.

## 2. Product catalog (Part 18)

`android/billing_catalog.json` mirrors `GameDB.PRODUCTS`:

| id | type | grants |
| --- | --- | --- |
| gems_100 / gems_500 / gems_1200 / gems_2500 | consumable | gems |
| gold_10000 / gold_50000 | consumable | gold |
| remove_ads | non_consumable | ad-free entitlement |
| shadow_ninja_premium_skin | non_consumable | premium ninja cosmetic |
| legendary_katana_skin | non_consumable | katana cosmetic |
| premium_cosmetic_bundle | non_consumable | all cosmetics |

**These IDs are proposals.** Register exactly these ids in each developer
panel (Bazaar → Panel → IAP products; Myket → panel) before release. Never
hardcode prices — the SDK returns the localized price at runtime and the shop
displays it (UI shows "قیمت از بازار…" until products load).

## 3. Developer-side configuration (requires YOUR credentials)

### Cafe Bazaar
1. Register at cafebazaar.ir/panel → create the app (package
   `com.shadowlegends.game.bazaar`).
2. Create the 10 IAP products above.
3. Copy the **public** RSA key from the panel.
4. Create `android/plugin/poolakey_bridge/src/main/res/values/secrets.xml`
   from `android/plugin/secrets.xml.example`, pasting the key into
   `bazaar_rsa_public_key`. **Never commit secrets.xml** — it is gitignored.
   This is a public key only, used to verify signatures.
5. Without a key the bridge builds `SecurityCheck.Disable`, every
   `purchase_success` arrives with `signature_valid=false` and the game
   **rejects all grants** (fail closed).

### Myket
1. Register at myket.ir developer panel → create the app (package
   `com.shadowlegends.game.myket`).
2. Create the 10 IAP products above.
3. Copy the public key → `myket_rsa_public_key` in secrets.xml for the
   myket_bridge module. Without it the plugin reports `connect_failed`
   and billing stays disabled (fail closed).
4. The official SDK's manifest needs gradle placeholders — the CI workflow
   patches the installed Godot build template with
   `marketApplicationId=ir.mservices.market`,
   `marketBindAddress=ir.mservices.market.InAppBillingService.BIND`,
   `marketPermission=ir.mservices.market.BILLING` (see
   `.github/workflows/build_android.yml`, step "Patch build template…").
   A manual build must do the same before exporting the Myket variant.

## 4. Building the plugins (one-time, or via CI)

From any machine with Android SDK + JDK 17 (the CI workflow does this
automatically; locally verified with Gradle 8.9 + AGP 8.2.0):

```bash
cd android/plugin
gradle :poolakey_bridge:assembleRelease :myket_bridge:assembleRelease
# outputs:
#   poolakey_bridge/build/outputs/aar/poolakey_bridge-release.aar
#   myket_bridge/build/outputs/aar/myket_bridge-release.aar
cp poolakey_bridge/build/outputs/aar/poolakey_bridge-release.aar ../plugins/PoolakeyBridge.aar
cp myket_bridge/build/outputs/aar/myket_bridge-release.aar    ../plugins/MyketBridge.aar
```

> If you skip this, the export still succeeds **only if the `.gdap` files are
> also removed** (a `.gdap` whose `binary` AAR is missing makes the plugin
> config invalid and Godot logs `Invalid plugin config file …` — the plugin is
> silently excluded). The game then runs with billing reported unavailable.

## 5. Purchase flow & security (Part 19)

State machine (BillingBridge): `DISABLED → IDLE → CONNECTING →
LOADING_PRODUCTS → PURCHASING → PURCHASED → VERIFYING → CONSUMED`, with
`PENDING / FAILED / CANCELED / RESTORED` branches.

Guarantees implemented:
- **Signature verification in Kotlin, inside the official SDKs**:
  Poolakey 2.1.0 verifies with `SecurityCheck.Enable(rsaPublicKey)` and routes
  invalid signatures to `purchaseFailed` (PurchaseHijackedException); the Myket
  `IabHelper` verifies with the store key given to its constructor and reports
  failures through its result listeners. Invalid/unverifiable → nothing
  granted, logged.
- **Grant points**: non-consumables on `purchase_success` (with
  `signature_valid=true`); consumables only after `consume_success`.
- **Duplicate protection**: transaction tokens recorded in
  `data.purchases.consumed_tx`; repeated grants blocked.
- **Crash recovery**: pending transactions persisted in
  `data.purchases.pending_tx`; on next launch `restorePurchases()` runs and
  matching tokens are cleared.
- **Transaction log**: `user://transactions.log` (timestamped lines).
- **No private credentials in code**; secrets.xml is developer-local.

### Local-only verification limitation (must be stated)

Without a backend server, signature verification happens **on-device**. A
determined attacker with root access can patch the client to skip checks.
Mitigations, in increasing strength:
1. Current state: SDK public-key verification + token ledger (reasonable for a
   casual game).
2. Recommended before scale: server-side receipt validation. Cafe Bazaar
   exposes an API for verifying purchases server-side (`poolakey` docs →
   "Server-side verification"); Myket documents an equivalent. Add a small
   backend that receives `purchaseToken`, validates it with the store, and
   returns a signed grant token the client can trust.
3. Optionally obfuscate the save file (the checksum already detects casual
   edits — see SaveSystem).

## 6. Ads (Part 15)

Advertising is **disabled** in this build. To enable an approved provider for
Iranian distribution (e.g. Tapsell):
1. Add their SDK via the same plugin mechanism (AAR + `.gdap`).
2. Implement rewarded ads ONLY: a genuine `rewarded video finished` callback
   must trigger the reward; on dismiss/fail, no reward.
3. Gate behind `remove_ads` entitlement: skip loading ads entirely when
   `SaveSystem.has_entitlement("remove_ads")`.
4. No interstitials on gameplay screens; never block core loops.

Until those steps are done, the game simply never shows ads — this is the
safe default.

## 7. Release signing & store upload

1. Generate a keystore (keep it safe — stores key updates to it):
   `keytool -genkeypair -v -keystore shadow_legends.keystore -alias sl -keyalg RSA -validity 10000`
2. In Godot export dialog, fill keystore path/alias/passwords, export
   release APK/AAB per variant. (The CI workflow produces **debug-signed**
   APKs — fine for installing/testing, NOT for store upload.)
3. Upload with screenshots + Persian store listing; register the same
   product IDs you configured.

## 8. What is NOT done (honest list)

- ❌ No live purchase tested against Bazaar/Myket test environments (requires
  registered developer accounts + real product IDs).
- ❌ No backend receipt validation.
- ❌ Release signing (needs your keystore).
- ✅ SDK dependencies and APIs verified against official sources:
  Poolakey 2.1.0 (github.com/cafebazaar/Poolakey, JitPack artifact inspected)
  and Myket Billing Client 2.2 (github.com/myketstore/billing-sample-android,
  official maven artifact inspected). The old hand-written Myket AIDL
  reflection code was replaced by the official SDK.
- ✅ Everything source-level is in place; see `TESTING_REPORT.md`.
