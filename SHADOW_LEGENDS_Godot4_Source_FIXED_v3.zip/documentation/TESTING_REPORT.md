# Testing Report — SHADOW LEGENDS

**Environment where this report was produced:** a Linux sandbox with
**Godot 4.3.stable (headless), OpenJDK 17, Gradle 8.9, Android SDK
(platform 34 + build-tools 34.0.0) and the official Godot 4.3 export
templates** — i.e. the same toolchain the CI workflow uses. Everything below
states exactly what was and was not verified. No claim goes beyond what was
checked, and every build claim is backed by artifacts + logs produced in this
environment.

---

## 1. Verified in this environment

### 1.1 Project integrity (Godot 4.3 headless)

| Check | Method | Result |
| --- | --- | --- |
| Asset import, script compile of all 42 .gd files | `godot --headless --path . --import` | ✅ **0 script errors** (after fixing the bugs in § 3 — the project originally failed to parse) |
| Headless validation suite | `godot --headless --path . --script tests/run_checks.gd` | ✅ **ALL CHECKS PASSED** — campaign levels 1-1..1-3 reachable, abyss rooms 1..20 valid, sprite sheet frame counts correct, product catalog (10 products) consistent, XP curve monotonic |
| Export presets parse | ConfigFile load test | ✅ 3 presets detected (`shadow_legends_bazaar`, `shadow_legends_myket`, `shadow_legends_bazaar_bundle`) — the shipped file had `permissions/bill=False` (capital letter) which broke the whole file for Godot's ConfigFile parser |
| Plugin configs valid | import log after AARs are in place | ✅ no `Invalid plugin config file …` messages (they DID appear before the AARs were copied — the `.gdap` v1 format requires the AAR next to it) |

### 1.2 Billing plugin AARs (Gradle)

| Check | Method | Result |
| --- | --- | --- |
| PoolakeyBridge compiles against the official SDK | `gradle :poolakey_bridge:assembleRelease` (AGP 8.2.0 / Kotlin 2.2.0 / compileSdk 34) | ✅ BUILD SUCCESSFUL → `poolakey_bridge-release.aar` |
| MyketBridge compiles against the official SDK | `gradle :myket_bridge:assembleRelease` | ✅ BUILD SUCCESSFUL → `myket_bridge-release.aar` (requires Kotlin ≥ 2.2 — the `ir.myket:billing:2.2` metadata is Kotlin 2.2) |
| AAR registration meta-data | unzip + manifest inspection | ✅ both AARs carry `org.godotengine.plugin.v2.<Name>` → fully-qualified class name |
| SDK dependency coordinates | downloaded the actual artifacts | ✅ `com.github.cafebazaar.Poolakey:poolakey:2.1.0` (JitPack) and `ir.myket:billing:2.2` (maven.myket.ir) exist and were inspected (manifests, `javap`-level strings, READMEs) |

### 1.3 Real APK builds (the strongest evidence)

Both marketplace variants were **actually exported here** with
`godot --headless --export-debug` (gradle build) and the resulting APKs were
unzipped and inspected:

| Property | Bazaar APK | Myket APK |
| --- | --- | --- |
| Build completed | ✅ (`export: end`, gradle output APK present) | ✅ |
| Package name | `com.shadowlegends.game.bazaar` | `com.shadowlegends.game.myket` |
| Plugin meta-data in merged manifest | `org.godotengine.plugin.v2.PoolakeyPlugin` → `com.shadowlegends.billing.PoolakeyBridge` | `org.godotengine.plugin.v2.MyketPlugin` → `com.shadowlegends.billing.MyketBridge` |
| Store SDK merged into dex | ✅ `com.farsitel.bazaar.*` (Poolakey receiver actions) | ✅ `ir.myket.billingclient.IabHelper` + utils |
| Store manifest entries | Poolakey `<queries>` + `PAY_THROUGH_BAZAAR` permission merged | ✅ `ir.mservices.market` placeholders **resolved** (`${marketBindAddress}` etc.) — the CI template patch works |
| ABIs | armeabi-v7a + arm64-v8a | armeabi-v7a + arm64-v8a |
| Other store's plugin present | ❌ absent (0 matches) | ❌ absent (0 matches) |
| Signing | debug-signed (auto-generated debug keystore) | debug-signed |

→ The two variants are **independent by construction** (per-preset plugin
toggles) and this was verified against the produced binaries, not just the
configs.

### 1.4 Platform behavior verified from the engine source (4.3-stable)

- `.gdap` v1 format fields (`binary_type`/`binary`, array `remote` deps) —
  read from `platform/android/export/godot_plugin_config.{h,cpp}`.
- Runtime plugin loading via `Class.forName(android:value)` —
  `GodotPluginRegistry.java`.
- `--install-android-build-template` CLI flag — `main/main.cpp`.
- Template layout: app module at `android/build/` root (so the Myket
  placeholder patch targets `android/build/build.gradle`).
- Godot auto-generates a debug keystore if missing —
  `export_plugin.cpp::_create_editor_debug_keystore_if_needed` (the workflow
  still creates one explicitly to keep the log readable).
- Android exporter silently fails validation unless
  `rendering/textures/vram_compression/import_etc2_astc=true` — set in
  project.godot now.

## 2. NOT verified here — requires accounts/devices (next steps)

| Area | Why not | How to verify |
| --- | --- | --- |
| Live billing (connect → products → purchase → consume → restore) against Cafe Bazaar / Myket | needs registered developer accounts, registered product ids, public keys in secrets.xml, the store app installed on a device | follow MARKETPLACE_INTEGRATION.md § 3 + § 8 checklist; the code paths compile against the real SDKs but no real transaction was ever made |
| Release signing | needs YOUR keystore | keytool command in MARKETPLACE_INTEGRATION.md § 7 |
| Runtime gameplay feel, frame rate on device, touch ergonomics | no physical device in the sandbox | install the CI artifact; manual QA checklist below |
| Save corruption recovery on device | user:// is empty in the sandbox | delete/truncate the save file on device → app must fall back to .bak |

## 3. Bug log — found and fixed during the pipeline hardening pass

1. **`.gdap` files used a non-existent format** (`entry_tag`, dictionary
   `local={…}`) — Godot 4.3 rejected them ("Invalid plugin config file").
   Rewritten to the verified v1 format (`binary_type`/`binary`, array
   `remote`/`custom_maven_repos`).
2. **Plugin AAR manifests used a bare class name** in
   `org.godotengine.plugin.v2.*` meta-data — runtime does `Class.forName()`,
   so the plugins could never load. Now full class names.
3. **Wrong dependency coordinates**: `com.cafebazaar.poolakey:poolakey:2.2.0`
   (does not exist) and `io.github.godotengine:godot:4.3.0` (does not exist).
   Now `com.github.cafebazaar.Poolakey:poolakey:2.1.0` (JitPack) and
   `org.godotengine:godot:4.3.0.stable` (Maven Central, `compileOnly`).
4. **PoolakeyBridge.kt was written against an invented API** (wrong package
   `com.cafebazaar.*`, non-existent Builder/getProducts/consume signatures).
   Rewritten against the verified Poolakey 2.1.0 API
   (`ir.cafebazaar.poolakey`, `SecurityCheck.Enable(rsaPublicKey)`,
   `purchaseProduct(registry, request)`, `consumeProduct(token)`,
   `getInAppSkuDetails`, `getPurchasedProducts`).
5. **MyketBridge.kt hand-rolled AIDL reflection with TODO(verify)** — replaced
   with the official `ir.myket:billing:2.2` SDK (`IabHelper`), verified against
   the official sample and the published artifact. Manifest placeholders
   (`ir.mservices.market…`) are now provided by the CI patch step.
6. **BillingBridge.gd**: `_on_products`/`_on_restored` expected GDScript
   Arrays but the plugins emit JSON strings (would throw at runtime); plugin
   methods were called snake_case (`query_products`) while the Kotlin methods
   are camelCase (`queryProducts`) — "nonexistent function" errors. Fixed,
   store detection now uses the actually-loaded plugin singleton.
7. **`permissions/bill=False`** (capital) — broke parsing of the entire
   export_presets.cfg. Lowercased; comments converted to Godot's `;` syntax
   (a `;` inside `#` comment text also broke the parser).
8. **`L10N` / `Main` identifiers unresolved** — 15 scripts referenced them but
   the autoload was named `Localization` and `Main.gd` had no `class_name`.
   Every UI screen failed to compile → export impossible. Autoload renamed to
   `L10N`, `class_name Main` added.
9. **Five GDScript type-inference errors** (InventoryScreen, ShopScreen,
   SettingsScreen, TouchControls) — `:=` against Variant values; plus a
   SettingsScreen call to a `_build()` function that did not exist (language
   switch would crash). All fixed.
10. **SaveSystem._checksum bug** — subscripted its argument as if it were the
    save wrapper (`payload["data"]`), throwing on every save/load. Now hashes
    the inner data dict (consistent at both call sites).
11. **Level validator measured platform LEFT edges** and ignored platform
    widths → 56 false "gap too large" failures. Rewritten to measure real
    edge-to-edge gaps using actual sprite widths and jump budgets derived from
    Player.gd physics (single 352px / double 541px / +dash 762px, with margin).
    All levels pass; no gameplay data was changed.
12. **tests/run_checks.gd hung in `-s` mode** — class_name scripts that
    reference autoloads fail to compile before autoload registration in script
    mode. The runner now defers to the first process frame and loads scripts
    dynamically.
13. **`rendering/textures/vram_compression/import_etc2_astc` missing** — the
    Android exporter failed validation silently (empty error list). Set to
    true.
14. **Workflow rewrite**: no more `|| true` error swallowing, no fake
    `.aab`-named-APK export (a real `export_format=1` preset was added),
    artifacts uploaded only when the files exist, headless validation step
    before any export, explicit editor-settings + debug-keystore step.

## 4. Manual QA checklist (execute on device)

**Startup & menu**
- [ ] Cold start < 3 s to main menu (target; measure on device)
- [ ] Persian text renders RTL, digits optionally Persian
- [ ] Music starts; volume sliders affect buses

**Gameplay (World 1-1)**
- [ ] Move / jump / double jump / dash feel responsive
- [ ] 3-hit combo chains while holding attack; final hit knocks back
- [ ] Special charges from hits; burst damages group
- [ ] Wolf lunge telegraphs (crouch) and can be dodged by dash/jump
- [ ] Archer retreats and shoots; orbs/magics are dodgeable
- [ ] Spike flora damages with knockback; death → checkpoint respawn
- [ ] Portal ends level; stars reflect deaths; rewards granted and saved

**Boss (World 1-3)**
- [ ] Entrance cinematic: camera pan, roar, health bar appears
- [ ] Phase 2 at 66%: faster + orb barrage; Phase 3 at 33%: enrage tint
- [ ] Defeat: slow-motion, dissolve, loot, victory overlay

**Progression**
- [ ] XP bar fills; level-up grants 2 skill points; skills apply
- [ ] Item drop → inventory → equip → stats change
- [ ] Upgrade deducts gold; sell unequipped only

**Save**
- [ ] Kill app mid-level → relaunch keeps level, currencies, skills
- [ ] Settings persist
- [ ] Corrupt the save file → app recovers from backup or starts fresh

**Billing (use each store's test/dev process; never real money)**
- [ ] Shop shows real localized prices when plugin connected
- [ ] Without secrets.xml key → billing reports unavailable / connect_failed
      (fail-closed, no grants)
- [ ] Purchase success grants after callback (and after consume for gems)
- [ ] Cancel → no grant
- [ ] Failure (offline / no account) → no grant, error shown
- [ ] Pending state → no grant; later restore grants
- [ ] Same token never grants twice
- [ ] Non-consumable restore works after reinstall
- [ ] transactions.log records each state transition

## 5. Performance plan (Part 22)

- GL Compatibility renderer (lowest-end friendly), MSAA off, 2D snapping on.
- Sprite sheets preloaded; textures ≤ 1920×1080; total asset weight ≈ 9 MB.
- Particle counts capped (≤ 24 alive per effect); pooled SFX players (8).
- `settings.quality` reserved for toggling foreground layer + particles on
  weak devices (wired into settings UI; effect toggle hook in Vfx).
- Measure on device before claiming any fps number — none is claimed here.

## 6. Earlier bug log (asset-authoring pass)

1. Floating-platform generator produced degenerate polygon → rewritten as
   solid mass; verified 91% vertical coverage.
2. GDScript: dynamic `owner_node` property on built-in Area2D would crash →
   replaced with `set_meta/get_meta`.
3. Victory next-level parse `substr(3)` → `substr(4)` ("w1_l1" → level 1).
4. Patrol bounds inversion (`-span` handling) → anchored at spawn in `_ready`.
5. Projectiles referenced `area.owner_node` → damage moved to body contact.
6. Pause overlay unresponsive while tree paused → overlay layer
   `PROCESS_MODE_ALWAYS`; AudioManager keeps music.
7. Missing closing parens in two UI lambdas — caught by the structural check.
8. Non-Vazirmatn glyphs (★ ◆ ⛁ ×) → replaced with generated icon textures /
   safe characters.
