package com.shadowlegends.billing

import android.app.Activity
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.result.ActivityResultRegistry
import ir.cafebazaar.poolakey.Connection
import ir.cafebazaar.poolakey.Payment
import ir.cafebazaar.poolakey.config.PaymentConfiguration
import ir.cafebazaar.poolakey.config.SecurityCheck
import ir.cafebazaar.poolakey.request.PurchaseRequest
import org.godotengine.godot.plugin.GodotPlugin
import org.godotengine.godot.plugin.SignalInfo
import org.godotengine.godot.plugin.UsedByGodot

/**
 * PoolakeyBridge — Cafe Bazaar in-app billing for Godot 4 (Android plugin v2).
 *
 * Wraps the OFFICIAL Poolakey SDK 2.1.0 (https://github.com/cafebazaar/Poolakey).
 * Every API call below was verified against the Poolakey 2.1.0 source
 * (ir.cafebazaar.poolakey package — note: NOT com.cafebazaar.poolakey):
 *   - PaymentConfiguration(localSecurityCheck, shouldSupportSubscription) is a
 *     data class; there is no Builder. SecurityCheck is a sealed class:
 *     SecurityCheck.Enable(rsaPublicKey) or SecurityCheck.Disable.
 *   - purchaseProduct(registry: ActivityResultRegistry, request, callback) —
 *     the Godot host activity is a FragmentActivity (ComponentActivity), so
 *     getActivityResultRegistry() is available.
 *   - consumeProduct(purchaseToken), getInAppSkuDetails(ids),
 *     getPurchasedProducts(callback) with DSL callbacks (purchaseSucceed etc.).
 *   - With SecurityCheck.Enable, Poolakey verifies the RSA signature itself and
 *     routes invalid signatures to purchaseFailed (PurchaseHijackedException),
 *     so purchaseSucceed implies a verified signature. With SecurityCheck.Disable
 *     (no key configured) we emit signature_valid=false and the GDScript side
 *     fail-closes (no grants), so a missing key can never silently grant items.
 *
 * The RSA *public* key from the Bazaar developer panel goes into
 * res/values/secrets.xml as `bazaar_rsa_public_key` (NEVER a private key,
 * NEVER committed — see android/plugin/secrets.xml.example).
 *
 * Signals emitted to GDScript (scripts/billing/BillingBridge.gd):
 *   billing_connected(), billing_disconnected(), connect_failed(message)
 *   products_loaded(jsonArrayString)
 *   purchase_pending(productId)             // purchase flow started
 *   purchase_success(productId, purchaseToken, signatureValid)
 *   purchase_failure(productId, message), purchase_canceled(productId)
 *   consume_success(token), consume_failure(token, message)
 *   purchases_restored(jsonArrayString)     // [{"id":...,"token":...}, ...]
 */
class PoolakeyBridge(godot: org.godotengine.godot.Godot) : GodotPlugin(godot) {

    companion object {
        const val TAG = "PoolakeyBridge"
        const val PLUGIN_NAME = "PoolakeyPlugin"
    }

    private var payment: Payment? = null
    private var connection: Connection? = null
    private var securityEnabled = false

    override fun getPluginName(): String = PLUGIN_NAME

    override fun getPluginSignals(): MutableSet<SignalInfo> {
        return mutableSetOf(
            SignalInfo("billing_connected"),
            SignalInfo("billing_disconnected"),
            SignalInfo("connect_failed", String::class.java),
            SignalInfo("products_loaded", String::class.java),
            SignalInfo("purchase_pending", String::class.java),
            SignalInfo("purchase_success", String::class.java, String::class.java, Boolean::class.java),
            SignalInfo("purchase_failure", String::class.java, String::class.java),
            SignalInfo("purchase_canceled", String::class.java),
            SignalInfo("consume_success", String::class.java),
            SignalInfo("consume_failure", String::class.java, String::class.java),
            SignalInfo("purchases_restored", String::class.java),
        )
    }

    // ------------------------------------------------------------------
    // lifecycle
    // ------------------------------------------------------------------
    @UsedByGodot
    fun initialize() {
        val activity: Activity = activity ?: run {
            emitSignal("connect_failed", "no activity")
            return
        }
        val config = PaymentConfiguration(
            localSecurityCheck = buildSecurityCheck(activity),
            shouldSupportSubscription = false,
        )
        payment = Payment(context = activity.applicationContext, config = config)
        connection = payment?.connect {
            connectionSucceed {
                Log.i(TAG, "Bazaar billing connected (signature check enabled=$securityEnabled)")
                emitSignal("billing_connected")
            }
            connectionFailed { throwable ->
                Log.e(TAG, "Bazaar billing connect failed: ${throwable.message}")
                emitSignal("connect_failed", throwable.message ?: "connect_failed")
            }
            disconnected {
                Log.w(TAG, "Bazaar billing disconnected")
                emitSignal("billing_disconnected")
            }
        }
    }

    /**
     * Public key handling: Base64 X.509 PUBLIC key(s) from the developer panel,
     * stored in res/values/secrets.xml (never committed). When no valid key is
     * configured we disable Poolakey's local verification and flag every
     * purchase as unverified (signature_valid=false) — fail closed.
     */
    private fun buildSecurityCheck(activity: Activity): SecurityCheck {
        val key = readStringResource(activity, "bazaar_rsa_public_key")
            ?: readStringResource(activity, "bazaar_rsa_public_key_2")
        return if (key.isNullOrBlank()) {
            Log.w(TAG, "No Bazaar public key configured (secrets.xml). " +
                    "Purchases will be flagged UNVERIFIED and rejected by the game.")
            SecurityCheck.Disable
        } else {
            securityEnabled = true
            SecurityCheck.Enable(rsaPublicKey = key.trim())
        }
    }

    private fun readStringResource(activity: Activity, name: String): String? {
        val resId = activity.resources.getIdentifier(name, "string", activity.packageName)
        if (resId == 0) return null
        val value = try {
            activity.getString(resId)
        } catch (e: Exception) {
            return null
        }
        if (value.contains("PASTE_") || value.isBlank()) return null  // unfilled placeholder
        return value
    }

    // ------------------------------------------------------------------
    // products / purchase / consume / restore
    // ------------------------------------------------------------------
    @UsedByGodot
    fun queryProducts(productIdsJson: String) {
        val p = payment ?: run {
            emitSignal("products_loaded", "[]")
            return
        }
        val ids = splitIds(productIdsJson)
        p.getInAppSkuDetails(ids) {
            getSkuDetailsSucceed { skuList ->
                val json = buildString {
                    append("[")
                    skuList.forEachIndexed { i, sku ->
                        if (i > 0) append(",")
                        append("{\"id\":\"").append(j(sku.sku)).append("\",")
                        append("\"title\":\"").append(j(sku.title)).append("\",")
                        append("\"price\":\"").append(j(sku.price)).append("\",")
                        append("\"type\":\"inapp\"}")
                    }
                    append("]")
                }
                emitSignal("products_loaded", json)
            }
            getSkuDetailsFailed { throwable ->
                Log.e(TAG, "getInAppSkuDetails failed: ${throwable.message}")
                emitSignal("products_loaded", "[]")
            }
        }
    }

    @UsedByGodot
    fun launchPurchase(productId: String) {
        val act = activity ?: return
        val p = payment ?: run {
            emitSignal("purchase_failure", productId, "not_connected")
            return
        }
        val registry: ActivityResultRegistry =
            (act as? ComponentActivity)?.activityResultRegistry ?: run {
                Log.e(TAG, "host activity is not a ComponentActivity — cannot launch purchase")
                emitSignal("purchase_failure", productId, "no_activity_result_registry")
                return
            }
        p.purchaseProduct(
            registry = registry,
            request = PurchaseRequest(productId = productId, payload = null)
        ) {
            purchaseFlowBegan {
                emitSignal("purchase_pending", productId)
            }
            failedToBeginFlow { throwable ->
                Log.e(TAG, "purchase flow failed to begin $productId: ${throwable.message}")
                emitSignal("purchase_failure", productId, throwable.message ?: "buy_intent_failed")
            }
            purchaseSucceed { purchaseInfo ->
                Log.i(TAG, "purchase success $productId token=${purchaseInfo.purchaseToken} " +
                        "verified=$securityEnabled")
                emitSignal("purchase_success", productId, purchaseInfo.purchaseToken, securityEnabled)
            }
            purchaseCanceled {
                Log.i(TAG, "purchase canceled $productId")
                emitSignal("purchase_canceled", productId)
            }
            purchaseFailed { throwable ->
                Log.e(TAG, "purchase failed $productId: ${throwable.message}")
                emitSignal("purchase_failure", productId, throwable.message ?: "error")
            }
        }
    }

    @UsedByGodot
    fun consume(purchaseToken: String) {
        val p = payment ?: run {
            emitSignal("consume_failure", purchaseToken, "not_connected")
            return
        }
        p.consumeProduct(purchaseToken) {
            consumeSucceed {
                Log.i(TAG, "consumed $purchaseToken")
                emitSignal("consume_success", purchaseToken)
            }
            consumeFailed { throwable ->
                Log.e(TAG, "consume failed: ${throwable.message}")
                emitSignal("consume_failure", purchaseToken, throwable.message ?: "error")
            }
        }
    }

    @UsedByGodot
    fun restorePurchases() {
        val p = payment ?: run {
            emitSignal("purchases_restored", "[]")
            return
        }
        p.getPurchasedProducts {
            querySucceed { purchasedList ->
                val json = buildString {
                    append("[")
                    purchasedList.forEachIndexed { i, info ->
                        if (i > 0) append(",")
                        append("{\"id\":\"").append(j(info.productId)).append("\",")
                        append("\"token\":\"").append(j(info.purchaseToken)).append("\"}")
                    }
                    append("]")
                }
                emitSignal("purchases_restored", json)
            }
            queryFailed { throwable ->
                Log.e(TAG, "getPurchasedProducts failed: ${throwable.message}")
                emitSignal("purchases_restored", "[]")
            }
        }
    }

    // ------------------------------------------------------------------
    // helpers
    // ------------------------------------------------------------------
    private fun splitIds(json: String): List<String> {
        // ids arrive as a JSON array string from GDScript; parse defensively
        return json.replace("[", "").replace("]", "")
            .split(",").map { it.trim().trim('"') }.filter { it.isNotEmpty() }
    }

    private fun j(s: String): String =
        s.replace("\\", "\\\\").replace("\"", "\\\"")
}
