package com.shadowlegends.billing

import android.app.Activity
import android.util.Log
import ir.myket.billingclient.IabHelper
import ir.myket.billingclient.util.IabResult
import ir.myket.billingclient.util.Inventory
import ir.myket.billingclient.util.Purchase
import org.godotengine.godot.plugin.GodotPlugin
import org.godotengine.godot.plugin.SignalInfo
import org.godotengine.godot.plugin.UsedByGodot

/**
 * MyketBridge — Myket in-app billing for Godot 4 (Android plugin v2).
 *
 * Wraps the OFFICIAL Myket Billing Client SDK (verified against the official
 * sample https://github.com/myketstore/billing-sample-android and the artifact
 * itself):
 *   - repository: https://maven.myket.ir — dependency: ir.myket:billing:2.2
 *   - API: IabHelper(context, base64PublicKey) + startSetup /
 *     queryInventoryAsync / launchPurchaseFlow / consumeAsync / dispose.
 *   - The SDK performs RSA signature verification internally with the store
 *     public key; a failed verification surfaces as result.isFailure() in the
 *     purchase listener, so purchase_success implies a verified signature.
 *   - The SDK requires the gradle manifest placeholders ${marketApplicationId},
 *     ${marketBindAddress}, ${marketPermission} (ir.mservices.market / ...BIND /
 *     ir.mservices.market.BILLING). They are provided by the CI workflow's
 *     "Patch build template" step — see MyketBridge.gdap and
 *     documentation/MARKETPLACE_INTEGRATION.md.
 *   - The purchase dialog runs through the SDK's internal ProxyBillingActivity,
 *     so no onActivityResult delegation is needed in the plugin.
 *
 * The RSA *public* key from the Myket developer panel goes into
 * res/values/secrets.xml as `myket_rsa_public_key` (NEVER a private key,
 * NEVER committed — see android/plugin/secrets.xml.example). Without a key the
 * plugin reports connect_failed and stays disabled — fail closed.
 *
 * Signals match PoolakeyBridge so BillingBridge.gd can drive either store:
 *   billing_connected(), billing_disconnected(), connect_failed(message)
 *   products_loaded(jsonArrayString)
 *   purchase_pending(productId)
 *   purchase_success(productId, purchaseToken, signatureValid)
 *   purchase_failure(productId, message), purchase_canceled(productId)
 *   consume_success(token), consume_failure(token, message)
 *   purchases_restored(jsonArrayString)   // [{"id":...,"token":...}, ...]
 */
class MyketBridge(godot: org.godotengine.godot.Godot) : GodotPlugin(godot) {

    companion object {
        const val TAG = "MyketBridge"
        const val PLUGIN_NAME = "MyketPlugin"
        // IAB v3 response codes (same table the SDK uses — see IabResult).
        const val RESPONSE_USER_CANCELED = 1
    }

    private var iabHelper: IabHelper? = null

    override fun getPluginName(): String = PLUGIN_NAME

    override fun getPluginSignals(): MutableSet<SignalInfo> {
        return mutableSetOf(
            SignalInfo("billing_connected"),
            SignalInfo("billing_disconnected"),
            SignalInfo("connect_failed", String::class.java),
            SignalInfo("products_loaded", String::class.java),
            SignalInfo("purchase_pending", String::class.java),
            SignalInfo("purchase_success", String::class.java, String::class.java, Boolean::class.java),
            SignalInfo("purchase_failure", String::class.java, String::class.java),
            SignalInfo("purchase_canceled", String::class.java),
            SignalInfo("consume_success", String::class.java),
            SignalInfo("consume_failure", String::class.java, String::class.java),
            SignalInfo("purchases_restored", String::class.java),
        )
    }

    // ------------------------------------------------------------------
    // lifecycle
    // ------------------------------------------------------------------
    @UsedByGodot
    fun initialize() {
        val act: Activity = activity ?: run {
            emitSignal("connect_failed", "no activity")
            return
        }
        val publicKey = readPublicKey(act)
        if (publicKey.isNullOrBlank()) {
            Log.e(TAG, "No Myket public key configured (secrets.xml). Billing stays disabled.")
            emitSignal("connect_failed", "no_myket_public_key_configure_secrets_xml")
            return
        }
        try {
            iabHelper = IabHelper(act, publicKey.trim())
        } catch (e: Exception) {
            Log.e(TAG, "IabHelper init failed: ${e.message}")
            emitSignal("connect_failed", e.message ?: "init_failed")
            return
        }
        iabHelper?.enableDebugLogging(false, TAG)
        iabHelper?.startSetup { result ->
            if (!result.isSuccess) {
                Log.e(TAG, "Myket billing setup failed: ${result.message}")
                emitSignal("connect_failed", result.message)
            } else {
                Log.i(TAG, "Myket billing service connected")
                emitSignal("billing_connected")
            }
        }
    }

    private fun readPublicKey(act: Activity): String? {
        val resId = act.resources.getIdentifier("myket_rsa_public_key", "string", act.packageName)
        if (resId == 0) return null
        val value = try {
            act.getString(resId)
        } catch (e: Exception) {
            return null
        }
        if (value.contains("PASTE_") || value.isBlank()) return null  // unfilled placeholder
        return value
    }

    // ------------------------------------------------------------------
    // products
    // ------------------------------------------------------------------
    @UsedByGodot
    fun queryProducts(productIdsJson: String) {
        val helper = iabHelper ?: run { emitSignal("products_loaded", "[]"); return }
        val ids = splitIds(productIdsJson)
        helper.queryInventoryAsync(true, ids) { result: IabResult, inventory: Inventory? ->
            if (result.isFailure || inventory == null) {
                Log.e(TAG, "queryInventoryAsync failed: ${result.message}")
                emitSignal("products_loaded", "[]")
                return@queryInventoryAsync
            }
            val json = buildString {
                append("[")
                ids.forEachIndexed { i, sku ->
                    val details = inventory.getSkuDetails(sku) ?: return@forEachIndexed
                    if (i > 0) append(",")
                    append("{\"id\":\"").append(j(details.sku)).append("\",")
                    append("\"title\":\"").append(j(details.title)).append("\",")
                    append("\"price\":\"").append(j(details.price)).append("\",")
                    append("\"type\":\"inapp\"}")
                }
                append("]")
            }
            emitSignal("products_loaded", json)
        }
    }

    // ------------------------------------------------------------------
    // purchase
    // ------------------------------------------------------------------
    @UsedByGodot
    fun launchPurchase(productId: String) {
        val act = activity
        val helper = iabHelper
        if (act == null || helper == null) {
            emitSignal("purchase_failure", productId, "not_connected")
            return
        }
        helper.launchPurchaseFlow(act, productId, { result: IabResult, purchase: Purchase? ->
            when {
                result.isSuccess && purchase != null -> {
                    Log.i(TAG, "purchase success $productId token=${purchase.token} (verified by SDK)")
                    emitSignal("purchase_success", productId, purchase.token, true)
                }
                result.response == RESPONSE_USER_CANCELED -> {
                    Log.i(TAG, "purchase canceled $productId")
                    emitSignal("purchase_canceled", productId)
                }
                else -> {
                    Log.e(TAG, "purchase failed $productId: ${result.message}")
                    emitSignal("purchase_failure", productId, result.message)
                }
            }
        }, "")
        emitSignal("purchase_pending", productId)
    }

    // ------------------------------------------------------------------
    // consume — the SDK consumes Purchase objects; resolve by token first,
    // otherwise query the inventory and consume the matching purchase.
    // ------------------------------------------------------------------
    @UsedByGodot
    fun consume(purchaseToken: String) {
        val helper = iabHelper ?: run {
            emitSignal("consume_failure", purchaseToken, "not_connected")
            return
        }
        helper.queryInventoryAsync(false, emptyList()) { result: IabResult, inventory: Inventory? ->
            if (result.isFailure || inventory == null) {
                emitSignal("consume_failure", purchaseToken, "inventory_query_failed")
                return@queryInventoryAsync
            }
            val owned = inventory.getAllPurchases().firstOrNull { it.token == purchaseToken }
            if (owned == null) {
                Log.e(TAG, "consume: token not found in inventory")
                emitSignal("consume_failure", purchaseToken, "purchase_not_found_in_inventory")
                return@queryInventoryAsync
            }
            helper.consumeAsync(owned) { consumed: Purchase?, consumeResult: IabResult ->
                if (consumeResult.isSuccess) {
                    Log.i(TAG, "consumed ${consumed?.sku}")
                    emitSignal("consume_success", purchaseToken)
                } else {
                    Log.e(TAG, "consume failed: ${consumeResult.message}")
                    emitSignal("consume_failure", purchaseToken, consumeResult.message)
                }
            }
        }
    }

    // ------------------------------------------------------------------
    // restore
    // ------------------------------------------------------------------
    @UsedByGodot
    fun restorePurchases() {
        val helper = iabHelper ?: run { emitSignal("purchases_restored", "[]"); return }
        helper.queryInventoryAsync(false, emptyList()) { result: IabResult, inventory: Inventory? ->
            if (result.isFailure || inventory == null) {
                Log.e(TAG, "restore query failed: ${result.message}")
                emitSignal("purchases_restored", "[]")
                return@queryInventoryAsync
            }
            val json = buildString {
                append("[")
                inventory.getAllPurchases().forEachIndexed { i, purchase ->
                    if (i > 0) append(",")
                    append("{\"id\":\"").append(j(purchase.sku)).append("\",")
                    append("\"token\":\"").append(j(purchase.token)).append("\"}")
                }
                append("]")
            }
            emitSignal("purchases_restored", json)
        }
    }

    // ------------------------------------------------------------------
    // helpers
    // ------------------------------------------------------------------
    private fun splitIds(json: String): List<String> {
        return json.replace("[", "").replace("]", "")
            .split(",").map { it.trim().trim('"') }.filter { it.isNotEmpty() }
    }

    private fun j(s: String): String =
        s.replace("\\", "\\\\").replace("\"", "\\\"")
}
