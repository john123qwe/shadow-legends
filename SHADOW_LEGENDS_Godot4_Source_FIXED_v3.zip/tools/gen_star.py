"""Small addendum: star icon (unlocked/locked) for UI, since the Persian font
does not include the U+2605 glyph. Two variants saved to assets/ui."""
import math
import sys

sys.path.insert(0, "/home/z/my-project/scripts")
from PIL import Image, ImageDraw

from art_lib import canvas, save, PAL


def star(filled: bool, color):
    img = canvas(96, 96)
    d = ImageDraw.Draw(img)
    pts = []
    for i in range(10):
        a = math.radians(-90 + i * 36)
        rr = 40 if i % 2 == 0 else 17
        pts.append((48 + math.cos(a) * rr, 48 + math.sin(a) * rr))
    if filled:
        d.polygon(pts, fill=color + (255,))
        d.polygon([(48 + (p[0] - 48) * 0.5, 48 + (p[1] - 48) * 0.5) for p in pts],
                  fill=(255, 235, 170, 120))
    else:
        d.polygon(pts, fill=(16, 24, 26, 255), outline=(70, 96, 100, 255))
    return img


save(star(True, PAL["gold"]), "ui", "icon_star_on.png")
save(star(False, PAL["gold"]), "ui", "icon_star_off.png")
print("stars saved")
