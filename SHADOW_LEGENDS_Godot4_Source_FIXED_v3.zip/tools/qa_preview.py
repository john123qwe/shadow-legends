"""QA montage for wolf + boss sheets, and a full-scene art-direction preview
composite (clearly labeled preview, NOT an in-game screenshot)."""
import os
import sys

sys.path.insert(0, "/home/z/my-project/scripts")

from PIL import Image, ImageDraw, ImageFilter

from art_lib import ASSETS, contact_sheet

QA = "/tmp/render"


def sheets_tiles(paths, fw):
    tiles = []
    for p in paths:
        im = Image.open(p)
        for i in range(0, im.width, fw):
            t = im.crop((i, 0, i + fw, im.height))
            if t.getbbox():
                tiles.append(t)
    return tiles


def qa_wolf_boss():
    tiles = sheets_tiles([os.path.join(ASSETS, "enemies", "shadow_wolf_sheet.png"),
                          os.path.join(ASSETS, "bosses", "abyss_lord_sheet.png")], 256)
    tmp = os.path.join(QA, "tiles2")
    os.makedirs(tmp, exist_ok=True)
    ps = []
    for i, t in enumerate(tiles[:40]):
        p = os.path.join(tmp, f"b{i:02d}.png")
        t.save(p)
        ps.append(p)
    contact_sheet(ps, 7, 170, os.path.join(QA, "qa_wolf_boss.jpg"))


def scene_preview():
    """Compose one 1920x1080 preview: parallax stack + platforms + ninja + props."""
    W, H = 1920, 1080
    scene = Image.new("RGBA", (W, H))
    sky = Image.open(os.path.join(ASSETS, "backgrounds", "sky_w1.png"))
    far = Image.open(os.path.join(ASSETS, "backgrounds", "far_w1.png"))
    mid = Image.open(os.path.join(ASSETS, "backgrounds", "mid_w1.png"))
    fog = Image.open(os.path.join(ASSETS, "backgrounds", "fog_w1.png"))
    # shift layers horizontally like parallax would
    scene.alpha_composite(sky)
    scene.alpha_composite(far.crop((140, 0, 140 + W, H)))
    scene.alpha_composite(mid.crop((420, 0, 420 + W, H)))
    scene.alpha_composite(fog)
    ground = Image.open(os.path.join(ASSETS, "environments", "plat_wide.png"))
    ground2 = Image.open(os.path.join(ASSETS, "environments", "plat_edge_r.png"))
    flt = Image.open(os.path.join(ASSETS, "environments", "plat_float.png"))
    pillar = Image.open(os.path.join(ASSETS, "environments", "pillar.png"))
    arch = Image.open(os.path.join(ASSETS, "environments", "ruin_arch.png"))
    spikes = Image.open(os.path.join(ASSETS, "environments", "spike_plant.png"))
    spikes_s = Image.open(os.path.join(ASSETS, "environments", "spike_plant_small.png"))
    ninja = Image.open(os.path.join(ASSETS, "characters", "ninja_sheet.png")).crop((0, 0, 128, 128))
    wolf = Image.open(os.path.join(ASSETS, "enemies", "shadow_wolf_sheet.png")).crop((128 * 9, 0, 128 * 10, 128))
    scene.alpha_composite(arch, (1050, 240))
    scene.alpha_composite(pillar, (120, 380))
    scene.alpha_composite(ground, (0, 820))
    scene.alpha_composite(ground2, (960, 820))
    scene.alpha_composite(flt, (430, 560))
    scene.alpha_composite(spike_plant_img(spikes), (700, 700))
    scene.alpha_composite(spikes_s, (1500, 740))
    # characters standing on ground top (y=860)
    scene.alpha_composite(ninja, (300, 736))
    scene.alpha_composite(wolf, (1180, 742))
    # slash arc near ninja
    slash = Image.open(os.path.join(ASSETS, "effects", "slash_0.png"))
    scene.alpha_composite(slash, (430, 700))
    # near foliage frame
    near = Image.open(os.path.join(ASSETS, "backgrounds", "near_w1.png"))
    scene.alpha_composite(near)
    # fireflies
    ff = Image.open(os.path.join(ASSETS, "effects", "firefly.png"))
    for x, y in ((200, 500), (500, 420), (900, 620), (1300, 380), (1600, 550), (750, 480)):
        scene.alpha_composite(ff, (x, y))
    # label banner
    d = ImageDraw.Draw(scene)
    d.rectangle([0, 0, W, 64], fill=(5, 9, 11, 210))
    d.text((24, 18), "SHADOW LEGENDS - art direction preview (generated assets composite; NOT an in-game screenshot)",
           fill=(200, 220, 222, 255))
    flat = Image.new("RGB", (W, H), (10, 16, 18))
    flat.paste(scene, mask=scene.getchannel("A"))
    flat.save(os.path.join(QA, "preview_scene.jpg"), quality=88)


def spike_plant_img(img):
    return img


if __name__ == "__main__":
    qa_wolf_boss()
    scene_preview()
    print("QA sheets written")
