"""SHADOW LEGENDS — environments: parallax layers, platforms, traps, props."""
import math
import random

import numpy as np
from PIL import Image, ImageDraw, ImageFilter

from art_lib import (ASSETS, PAL, THEMES, add_glow, canvas, grass_tufts,
                     hue_rotate, jagged_edge, radial_gradient, rng, save,
                     vgrad)


# ----------------------------------------------------------------------------
# Parallax background layers (1920x1080, horizontally tileable)
# ----------------------------------------------------------------------------
W, H = 1920, 1080


def draw_tree(d, x, base_y, h, col, trunk_w=14, branches=4, r=None):
    """Bare silhouette tree with recursive-ish branches."""
    r = r or random.Random(0)
    top = base_y - h
    d.line([x, base_y, x, top], fill=col, width=trunk_w)
    for i in range(branches):
        t = 0.45 + 0.5 * r.random()
        by = base_y - h * t
        length = h * (0.18 + 0.22 * r.random())
        side = -1 if i % 2 == 0 else 1
        ang = math.radians(r.uniform(20, 55)) * side
        ex = x + math.sin(ang) * length
        ey = by - math.cos(ang) * length
        d.line([x, by, ex, ey], fill=col, width=max(3, int(trunk_w * 0.45)))
        # sub-branch
        d.line([ex, ey, ex + math.sin(ang * 1.4) * length * 0.5,
                ey - math.cos(ang) * length * 0.5], fill=col, width=3)


def draw_bamboo(d, x, base_y, h, col, r):
    seg = 64
    wdt = r.randint(9, 14)
    top = base_y - h
    y = base_y
    while y > top:
        y2 = max(top, y - seg)
        d.line([x, y, x, y2], fill=col, width=wdt)
        d.line([x - wdt // 2 - 2, y2, x + wdt // 2 + 2, y2], fill=col, width=3)
        # small leaf pair
        if r.random() < 0.7:
            lx = x + (wdt // 2 + 2)
            d.line([lx, y2, lx + r.randint(12, 26), y2 - r.randint(8, 18)], fill=col, width=3)
        y = y2


def draw_hanging_vines(d, x, y_top, length, col, r, width=3):
    n = r.randint(4, 7)
    xx = x
    for i in range(n):
        ln = length * r.uniform(0.5, 1.0)
        sway = r.randint(-14, 14)
        d.arc([xx - 8, y_top, xx + 40, y_top + ln], 180, 300, fill=col, width=width)
        d.line([xx, y_top, xx + sway * 0.6, y_top + ln], fill=col, width=width)
        xx += r.randint(10, 26)


def layer_far(seed):
    """Distant faded trees/bamboo — lightest teal."""
    img = canvas(W, H)
    d = ImageDraw.Draw(img)
    r = rng(seed)
    col = PAL["far"] + (110,)
    x = -40
    while x < 2 * W:
        if r.random() < 0.5:
            h = r.randint(260, 470)
            draw_tree(d, x, H, h, col, r.randint(7, 12), r.randint(3, 5), r)
        else:
            draw_bamboo(d, x, H, r.randint(300, 520), col, r)
        x += r.randint(60, 150)
    return img


def layer_mid(seed):
    """Mid-ground silhouettes — darker teal."""
    img = canvas(W, H)
    d = ImageDraw.Draw(img)
    r = rng(seed)
    col = PAL["mid"] + (200,)
    x = -60
    while x < 2 * W:
        h = r.randint(360, 660)
        if r.random() < 0.45:
            draw_tree(d, x, H, h, col, r.randint(12, 20), 5, r)
        else:
            draw_bamboo(d, x, H, h, col, r)
        x += r.randint(90, 200)
    # ground mist band at base
    fog = radial_gradient((W, 260), PAL["fog"] + (52,), PAL["fog"] + (0,))
    img.alpha_composite(fog, (0, H - 210))
    return img


def layer_fog(seed):
    """Soft horizontal fog band, mostly transparent."""
    img = canvas(W, H)
    band = radial_gradient((900, 300), PAL["fog"] + (46,), PAL["fog"] + (0,))
    r = rng(seed)
    for i in range(7):
        x = r.randint(-200, W - 400)
        y = r.randint(H - 480, H - 240)
        img.alpha_composite(band, (x, y))
    return img


def layer_near(seed):
    """Near-black framing foliage: hanging canopy top, bushes bottom."""
    img = canvas(W, H)
    d = ImageDraw.Draw(img)
    r = rng(seed)
    col = PAL["near"] + (255,)
    # top canopy hangers
    x = 0
    while x < 2 * W:
        wgt = r.randint(60, 170)
        dep = r.randint(60, 170)
        pts = [(x, 0), (x + wgt, 0), (x + wgt * 0.72, dep), (x + wgt * 0.3, dep * 0.8)]
        d.polygon(pts, fill=col)
        draw_hanging_vines(d, x + 14, dep - 6, r.randint(60, 150), col, r)
        x += wgt + r.randint(30, 120)
    # bottom bushes
    x = -40
    while x < 2 * W:
        bw = r.randint(120, 300)
        bh = r.randint(70, 160)
        pts = [(x, H), (x + bw, H), (x + bw * 0.7, H - bh), (x + bw * 0.35, H - bh * 0.9)]
        d.polygon(pts, fill=col)
        grass_tufts(d, x + 6, x + bw - 6, H - bh * 0.72, col, 0.8, 22, r.randint(0, 999))
        x += bw * 0.8
    return img


def make_sky(theme):
    """Vertical teal gradient with darker vignette edges."""
    img = vgrad(W, H, [(0.0, PAL["sky_top"]), (0.45, PAL["sky_mid"]), (1.0, PAL["sky_low"])])
    # vignette
    vg = np.zeros((H, W, 4), dtype=np.uint8)
    yy, xx = np.mgrid[0:H, 0:W]
    dx = (xx - W / 2) / (W / 2)
    dy = (yy - H / 2) / (H / 2)
    dd = np.clip(np.sqrt(dx ** 2 + dy ** 2) - 0.55, 0, 1) ** 1.5
    dark = (np.array(PAL["sky_top"])[None, None, :] * (dd[..., None] * 0.75)).astype(np.uint8)
    vg[..., 0] = dark[..., 0]
    vg[..., 1] = dark[..., 1]
    vg[..., 2] = dark[..., 2]
    vg[..., 3] = (dd * 235).astype(np.uint8)
    img.alpha_composite(Image.fromarray(vg, "RGBA"))
    return img


def gen_backgrounds():
    saved = []
    for name, th in THEMES.items():
        sky = make_sky(name)
        far = layer_far(100 + hash(name) % 50)
        mid = layer_mid(200 + hash(name) % 50)
        fog = layer_fog(300 + hash(name) % 50)
        near = layer_near(400 + hash(name) % 50)
        if th["rot"]:
            for im, k in ((far, "far"), (mid, "mid"), (fog, "fog")):
                pass
            far = hue_rotate(far, th["rot"], th["sat"])
            mid = hue_rotate(mid, th["rot"], th["sat"])
            fog = hue_rotate(fog, th["rot"], th["sat"])
            sky = hue_rotate(sky, th["rot"] * 0.4, th["sat"] * 0.9)
        tag = th["label"]
        saved += [save(sky, "backgrounds", f"sky_{tag}.png"),
                  save(far, "backgrounds", f"far_{tag}.png"),
                  save(mid, "backgrounds", f"mid_{tag}.png"),
                  save(fog, "backgrounds", f"fog_{tag}.png"),
                  save(near, "backgrounds", f"near_{tag}.png")]
    return saved


# ----------------------------------------------------------------------------
# Platforms — pure black silhouettes with grass tufts and jagged rock bottoms
# ----------------------------------------------------------------------------
def make_platform(w, h, variant, seed):
    img = canvas(w, h)
    d = ImageDraw.Draw(img)
    r = rng(seed)
    col = PAL["black"] + (255,)
    top_y = 40
    # main body with slightly irregular top
    top_pts = [(0, top_y)]
    x = 0
    while x < w:
        x += r.randint(30, 60)
        top_pts.append((min(x, w), top_y + r.randint(-3, 3)))
    top_pts[-1] = (w, top_y)
    bottom_profile = []
    if variant == "float":
        # floating rock: solid rounded mass with jagged underside taper
        body = canvas(w, h)
        bd = ImageDraw.Draw(body)
        bd.ellipse([4, top_y - 4, w - 4, top_y + (h - top_y) * 0.7], fill=col)
        pts = [(w * 0.5 + r.randint(-14, 14), h - 8)]
        for i in range(6):
            t = (i + 1) / 6.0
            bx = w * (0.5 - 0.45 * (1 - t))
            by = top_y + (h - top_y) * (0.45 + 0.5 * t) + r.randint(-10, 10)
            pts.append((bx, by))
        pts.append((4, top_y + (h - top_y) * 0.45))
        bd.polygon(pts, fill=col)
        img.alpha_composite(body)
    else:
        # ground chunk: jagged rocky bottom
        bot = jagged_edge(r, w, 0, h - 26, 20)
        d.polygon(top_pts + bot, fill=col)
        # vertical rocky striations
        for i in range(int(w / 90)):
            x0 = r.randint(0, w - 20)
            d.line([x0, top_y + 20, x0 + r.randint(-12, 12), h - 40], fill=(16, 24, 27, 255), width=3)
    # grass along top
    grass_tufts(d, 2, w - 2, top_y + 1, col, 0.75, 20, r.randint(0, 999))
    # side grass drizzle for edge variants
    if variant == "left":
        for yy in range(top_y, h - 20, 14):
            d.line([2, yy, 2 + r.randint(4, 10), yy + r.randint(-4, 4)], fill=col, width=2)
    if variant == "right":
        for yy in range(top_y, h - 20, 14):
            d.line([w - 2, yy, w - 2 - r.randint(4, 10), yy + r.randint(-4, 4)], fill=col, width=2)
    return img


def make_pillar(seed):
    w, h = 160, 560
    img = canvas(w, h)
    d = ImageDraw.Draw(img)
    r = rng(seed)
    col = PAL["black"] + (255,)
    pts_l, pts_r = [], []
    for yy in range(0, h, 40):
        off = r.randint(-6, 6)
        pts_l.append((24 + off, yy))
        pts_r.append((w - 24 + r.randint(-6, 6), yy))
    d.polygon([(w // 2 - 10, 0)] + pts_l + pts_r[::-1] + [(w // 2 + 10, 0)], fill=col)
    grass_tufts(d, 20, w - 20, 4, col, 0.5, 14, seed)
    return img


def make_vine(seed):
    w, h = 96, 260
    img = canvas(w, h)
    d = ImageDraw.Draw(img)
    r = rng(seed)
    col = PAL["black"] + (255,)
    for i in range(3):
        x = 18 + i * 28 + r.randint(-6, 6)
        ln = h - r.randint(30, 110)
        d.line([x, 0, x + r.randint(-10, 10), ln], fill=col, width=3)
        for k in range(r.randint(3, 6)):
            ly = ln * k / 5.0
            lx = x + r.randint(-8, 8)
            d.ellipse([lx - 5, ly, lx + 5, ly + 10], fill=col)
    return img


# ----------------------------------------------------------------------------
# Traps — the red-tipped spike flora from the reference art
# ----------------------------------------------------------------------------
def make_spike_plant(seed, scale=1.0):
    w, h = int(220 * scale), int(170 * scale)
    img = canvas(w, h)
    d = ImageDraw.Draw(img)
    r = rng(seed)
    black = PAL["black"] + (255,)
    red = PAL["red"] + (255,)
    n = r.randint(9, 13)
    base_y = h - 8
    for i in range(n):
        x0 = w * 0.5 + r.randint(int(-w * 0.32), int(w * 0.32))
        ang = math.radians(r.uniform(-65, 65))
        ln = r.uniform(0.5, 1.0) * (h - 30)
        # dark stem (slight curve)
        mx = x0 + math.sin(ang) * ln * 0.5
        my = base_y - ln * 0.55
        tipx = x0 + math.sin(ang) * ln
        tipy = base_y - ln * 0.95
        d.line([x0, base_y, mx, my], fill=black, width=max(3, int(7 * scale)))
        d.line([mx, my, tipx, tipy], fill=black, width=max(2, int(5 * scale)))
        # red tip glow
        add_glow(img, lambda dd, c: dd.ellipse([tipx - 7 * scale, tipy - 7 * scale,
                                                tipx + 7 * scale, tipy + 7 * scale], fill=c),
                 PAL["red_hot"] + (255,), radius=6, strength=0.8)
        d.ellipse([tipx - 5 * scale, tipy - 5 * scale, tipx + 5 * scale, tipy + 5 * scale], fill=red)
        # side thorns
        for t in (0.35, 0.6):
            thx = x0 + math.sin(ang) * ln * t
            thy = base_y - ln * (t * 0.9)
            s = 1 if r.random() < 0.5 else -1
            d.line([thx, thy, thx + s * 9 * scale, thy - 6 * scale], fill=black, width=3)
    return img


def make_floor_spikes(seed):
    w, h = 320, 90
    img = canvas(w, h)
    d = ImageDraw.Draw(img)
    r = rng(seed)
    black = PAL["black"] + (255,)
    red = PAL["red"] + (255,)
    base = h - 6
    d.polygon([(0, h), (w, h), (w, base), (0, base)], fill=black)
    x = 6
    while x < w - 6:
        hgt = r.randint(34, 70)
        d.polygon([(x - 7, base), (x + 7, base), (x, base - hgt)], fill=black)
        tip = (x, base - hgt)
        add_glow(img, lambda dd, c: dd.ellipse([tip[0] - 5, tip[1] - 5, tip[0] + 5, tip[1] + 5], fill=c),
                 PAL["red_hot"] + (255,), 5, 0.75)
        d.ellipse([tip[0] - 3, tip[1] - 3, tip[0] + 3, tip[1] + 3], fill=red)
        x += r.randint(22, 34)
    return img


# ----------------------------------------------------------------------------
# Pickups / checkpoints / portal
# ----------------------------------------------------------------------------
def make_coin():
    img = radial_gradient((56, 56), PAL["gold"] + (255,), (222, 168, 62, 0))
    d = ImageDraw.Draw(img)
    add_glow(img, lambda dd, c: dd.ellipse([10, 10, 46, 46], fill=c), (255, 216, 120, 255), 10, 0.9)
    d.ellipse([12, 12, 44, 44], fill=PAL["gold"] + (255,))
    d.ellipse([17, 17, 39, 39], outline=(255, 216, 120, 255), width=3)
    return img


def make_gem(color):
    img = canvas(64, 64)
    d = ImageDraw.Draw(img)
    col = color + (255,)
    add_glow(img, lambda dd, c: dd.polygon([(32, 4), (54, 26), (32, 60), (10, 26)], fill=c),
             color, 12, 0.9)
    d.polygon([(32, 6), (52, 26), (32, 58), (12, 26)], fill=col)
    d.polygon([(32, 6), (52, 26), (32, 30), (12, 26)], fill=(255, 255, 255, 90))
    d.line([12, 26, 52, 26], fill=(255, 255, 255, 70), width=2)
    return img


def make_xp_orb():
    img = radial_gradient((44, 44), PAL["teal_glow"] + (255,), PAL["teal_glow"] + (0,))
    d = ImageDraw.Draw(img)
    d.ellipse([14, 14, 30, 30], fill=(255, 255, 255, 220))
    return img


def make_checkpoint(on):
    w, h = 140, 190
    img = canvas(w, h)
    d = ImageDraw.Draw(img)
    black = PAL["black"] + (255,)
    # stone shrine
    d.polygon([(70, 6), (104, 40), (104, 150), (36, 150), (36, 40)], fill=black)
    d.polygon([(20, 150), (120, 150), (126, 178), (14, 178)], fill=black)
    d.rectangle([56, 90, 84, 150], fill=(2, 3, 4, 255))
    if on:
        # red flame
        flame = lambda dd, c: dd.polygon([(70, 58), (84, 96), (70, 120), (56, 96)], fill=c)
        add_glow(img, flame, PAL["red_hot"] + (255,), 14, 1.0)
        d.polygon([(70, 62), (82, 96), (70, 116), (58, 96)], fill=PAL["red"] + (255,))
        d.polygon([(70, 74), (76, 96), (70, 106), (64, 96)], fill=(255, 120, 110, 255))
    else:
        d.polygon([(70, 84), (78, 100), (70, 112), (62, 100)], fill=(40, 50, 54, 255))
    return img


def make_portal():
    img = canvas(180, 220)
    d = ImageDraw.Draw(img)
    add_glow(img, lambda dd, c: dd.ellipse([30, 40, 150, 190], fill=c), PAL["red"] + (255,), 24, 1.0)
    d.ellipse([40, 50, 140, 180], fill=(10, 4, 6, 255))
    d.arc([40, 50, 140, 180], 0, 360, fill=PAL["red"] + (255,), width=6)
    d.arc([55, 65, 125, 165], 0, 360, fill=PAL["red_hot"] + (230,), width=3)
    # swirling shards
    r = rng(7)
    for i in range(7):
        a = r.uniform(0, math.tau)
        rr = r.uniform(20, 46)
        x = 90 + math.cos(a) * rr
        y = 115 + math.sin(a) * rr * 0.9
        d.ellipse([x - 4, y - 8, x + 4, y + 8], fill=PAL["red"] + (200,))
    return img


# ----------------------------------------------------------------------------
# World props: ancient ruins fragments (silhouette decorations)
# ----------------------------------------------------------------------------
def make_ruin_column(seed):
    w, h = 120, 420
    img = canvas(w, h)
    d = ImageDraw.Draw(img)
    r = rng(seed)
    col = PAL["black"] + (255,)
    tilt = r.randint(-5, 5)
    d.polygon([(30 + tilt, 40), (90, 40), (86 - tilt, h), (34, h)], fill=col)
    d.polygon([(18, 40), (102, 40), (96, 14), (24, 14)], fill=col)
    d.polygon([(22, h), (98, h), (104, h - 26), (16, h - 26)], fill=col)
    for yy in range(80, h - 60, 56):
        d.line([32, yy, 88, yy + r.randint(-3, 3)], fill=(2, 4, 5, 255), width=4)
    grass_tufts(d, 24, 96, 14, col, 0.5, 12, seed)
    return img


def make_ruin_arch(seed):
    w, h = 460, 360
    img = canvas(w, h)
    d = ImageDraw.Draw(img)
    col = PAL["black"] + (255,)
    d.polygon([(0, h), (70, h), (70, 120), (30, 60), (120, 20), (340, 20),
               (430, 60), (390, 120), (390, h), (460, h), (460, 0), (0, 0)], fill=col)
    r = rng(seed)
    # broken chunks at top
    d.polygon([(150, 20), (230, 20), (222, 60), (160, 52)], fill=(2, 4, 5, 255))
    grass_tufts(d, 40, 420, h - 2, col, 0.5, 18, seed)
    return img


def gen_world_props():
    saved = []
    saved.append(save(make_ruin_column(3), "environments", "ruin_column.png"))
    saved.append(save(make_ruin_arch(4), "environments", "ruin_arch.png"))
    saved.append(save(make_pillar(5), "environments", "pillar.png"))
    for i, seed in enumerate((11, 12, 13)):
        saved.append(save(make_vine(seed), "environments", f"vine_{i}.png"))
    return saved


def gen_platforms():
    saved = []
    specs = [
        ("plat_wide.png", 1024, 260, "ground", 21),
        ("plat_wide2.png", 1024, 260, "ground", 22),
        ("plat_mid.png", 640, 240, "ground", 23),
        ("plat_small.png", 320, 210, "ground", 24),
        ("plat_float.png", 360, 240, "float", 25),
        ("plat_float2.png", 300, 220, "float", 26),
        ("plat_edge_l.png", 512, 260, "left", 27),
        ("plat_edge_r.png", 512, 260, "right", 28),
    ]
    for name, w, h, var, seed in specs:
        saved.append(save(make_platform(w, h, var, seed), "environments", name))
    return saved


def gen_traps_pickups():
    saved = []
    saved.append(save(make_spike_plant(31, 1.0), "environments", "spike_plant.png"))
    saved.append(save(make_spike_plant(32, 0.7), "environments", "spike_plant_small.png"))
    saved.append(save(make_spike_plant(33, 1.35), "environments", "spike_plant_big.png"))
    saved.append(save(make_floor_spikes(34), "environments", "floor_spikes.png"))
    saved.append(save(make_coin(), "icons", "coin.png"))
    saved.append(save(make_gem(PAL["red"]), "icons", "gem_red.png"))
    saved.append(save(make_gem((70, 130, 220)), "icons", "gem_blue.png"))
    saved.append(save(make_xp_orb(), "effects", "xp_orb.png"))
    saved.append(save(make_checkpoint(False), "environments", "checkpoint_off.png"))
    saved.append(save(make_checkpoint(True), "environments", "checkpoint_on.png"))
    saved.append(save(make_portal(), "effects", "portal.png"))
    return saved


if __name__ == "__main__":
    out = []
    out += gen_backgrounds()
    out += gen_platforms()
    out += gen_world_props()
    out += gen_traps_pickups()
    print("env assets written:", len(out))
