"""SHADOW LEGENDS — procedural art library.
Drawing helpers that reproduce the game's locked visual identity:
black silhouettes, deep-teal atmosphere, red glowing accents, fog layering.
All assets are original, generated procedurally with PIL/numpy.
"""
import math
import random

import numpy as np
from PIL import Image, ImageDraw, ImageFilter

# ----------------------------------------------------------------------------
# Palette (locked to the concept reference)
# ----------------------------------------------------------------------------
PAL = {
    "sky_top":    (13, 40, 50),
    "sky_mid":    (30, 82, 92),
    "sky_low":    (74, 138, 138),
    "far":        (52, 108, 112),   # faded distant silhouettes
    "mid":        (30, 72, 78),     # mid-ground silhouettes
    "near":       (10, 22, 26),     # near vegetation
    "black":      (7, 11, 13),      # pure silhouette black (platforms/characters)
    "body":       (10, 14, 16),
    "blade":      (36, 44, 48),
    "blade_edge": (74, 92, 96),
    "red":        (193, 39, 45),
    "red_hot":    (255, 46, 64),
    "red_dark":   (120, 22, 28),
    "gold":       (222, 168, 62),
    "teal_glow":  (110, 210, 210),
    "fog":        (120, 170, 172),
}

# World themes: (name, hue-rotation of background layers, accent multiplier)
THEMES = {
    "forest":  {"rot": 0,   "sat": 1.0,  "label": "w1"},
    "cave":    {"rot": -40, "sat": 0.85, "label": "w2"},
    "kingdom": {"rot": 150, "sat": 0.75, "label": "w3"},
    "temple":  {"rot": 75,  "sat": 0.95, "label": "w4"},
}

ASSETS = "/home/z/my-project/download/SHADOW_LEGENDS/assets"


def canvas(w, h, color=(0, 0, 0, 0)):
    return Image.new("RGBA", (int(w), int(h)), color)


def rng(seed):
    r = random.Random(seed)
    return r


# ----------------------------------------------------------------------------
# Low-level helpers
# ----------------------------------------------------------------------------
def vgrad(w, h, stops):
    """Vertical gradient. stops = [(y_frac, (r,g,b)), ...] ascending."""
    ys = np.linspace(0.0, 1.0, h)
    cols = np.zeros((h, 3), dtype=np.float32)
    xs = [s[0] for s in stops]
    for ch in range(3):
        vals = np.array([s[1][ch] for s in stops], dtype=np.float32)
        cols[:, ch] = np.interp(ys, xs, vals)
    arr = np.repeat(cols[:, None, :], w, axis=1)
    img = Image.fromarray(arr.astype(np.uint8), "RGB").convert("RGBA")
    return img


def radial_gradient(size, inner, outer):
    """Soft radial blob used for glows/particles. inner/outer are (r,g,b,a)."""
    w, h = size
    yy, xx = np.mgrid[0:h, 0:w]
    cx, cy = (w - 1) / 2.0, (h - 1) / 2.0
    d = np.sqrt(((xx - cx) / (w / 2.0)) ** 2 + ((yy - cy) / (h / 2.0)) ** 2)
    a = np.clip(1.0 - d, 0.0, 1.0) ** 1.6
    img = np.zeros((h, w, 4), dtype=np.uint8)
    for ch in range(3):
        img[..., ch] = inner[ch]
    img[..., 3] = (a * inner[3]).astype(np.uint8)
    return Image.fromarray(img, "RGBA")


def add_glow(base, draw_fn, color, radius=8, strength=0.9):
    """Draw `draw_fn(d, color)` on a blurred layer composited under base's art."""
    gl = canvas(*base.size)
    d = ImageDraw.Draw(gl)
    draw_fn(d, color)
    gl = gl.filter(ImageFilter.GaussianBlur(radius))
    a = gl.getchannel("A").point(lambda v: int(min(255, v * strength)))
    gl.putalpha(a)
    base.alpha_composite(gl)


def limb(d, p0, a1, l1, a2, l2, w1, w2, col):
    """Two-bone limb: p0 -> joint -> tip. Angles in degrees (0 = down, + = forward)."""
    x0, y0 = p0
    jx = x0 + math.sin(math.radians(a1)) * l1
    jy = y0 + math.cos(math.radians(a1)) * l1
    tx = jx + math.sin(math.radians(a2)) * l2
    ty = jy + math.cos(math.radians(a2)) * l2
    d.line([x0, y0, jx, jy], fill=col, width=w1)
    d.line([jx, jy, tx, ty], fill=col, width=w2)
    r = w1 / 2.0
    d.ellipse([x0 - r, y0 - r, x0 + r, y0 + r], fill=col)
    r = w2 / 2.0
    for p in (jx, jy), (tx, ty):
        d.ellipse([p[0] - r, p[1] - r, p[0] + r, p[1] + r], fill=col)
    return (tx, ty)


def grass_tufts(d, x0, x1, y, col, density=0.5, hmax=16, seed=0, lean=0.0):
    """Silhouette grass blades along a top edge — signature of the reference art."""
    r = rng(seed)
    span = int(x1 - x0)
    n = max(2, int(span * density / 10))
    for i in range(n):
        x = x0 + r.randint(0, span)
        h = r.randint(hmax // 3, hmax)
        bend = r.randint(-6, 6) + int(lean * h * 0.4)
        d.line([x, y, x + bend, y - h], fill=col, width=2)
        d.line([x + 1, y, x + 1 + bend, y - int(h * 0.7)], fill=col, width=1)


def jagged_edge(r, x0, x1, y, amp, step=14):
    """Random walk y-points along x for rocky edges."""
    pts = [(x0, y)]
    x = x0
    yy = y
    while x < x1:
        x += r.randint(step // 2, step)
        yy = y + r.randint(-amp, amp)
        pts.append((x, yy))
    return pts


def hue_rotate(img, deg, sat=1.0):
    """Rotate hue of RGB channels, keep alpha."""
    arr = np.array(img.convert("RGBA"), dtype=np.float32) / 255.0
    r, g, b, a = arr[..., 0], arr[..., 1], arr[..., 2], arr[..., 3]
    mx = np.max(arr[..., :3], axis=-1)
    mn = np.min(arr[..., :3], axis=-1)
    # convert to HSL-ish rotation only on colored pixels
    hsv = np.array(Image.fromarray((arr[..., :3] * 255).astype(np.uint8), "RGB").convert("HSV"), dtype=np.int16)
    hsv[..., 0] = (hsv[..., 0] + int(deg / 360.0 * 255)) % 255
    hsv[..., 1] = np.clip(hsv[..., 1] * sat, 0, 255)
    rgb = np.array(Image.fromarray(hsv.astype(np.uint8), "HSV").convert("RGB"), dtype=np.uint8)
    out = np.dstack([rgb, (a * 255).astype(np.uint8)])
    return Image.fromarray(out, "RGBA")


def sheet_path(kind, name):
    import os
    d = os.path.join(ASSETS, kind)
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, name)


def save(img, kind, name):
    p = sheet_path(kind, name)
    img.save(p)
    return p


def verify_dir(kind):
    """Assert every png in a dir is non-blank (has opaque pixels)."""
    import os
    d = os.path.join(ASSETS, kind)
    bad = []
    n = 0
    if not os.path.isdir(d):
        return ["missing:" + kind]
    for f in sorted(os.listdir(d)):
        if not f.endswith(".png"):
            continue
        n += 1
        im = Image.open(os.path.join(d, f)).convert("RGBA")
        a = np.array(im.getchannel("A"))
        if a.max() < 30:
            bad.append(kind + "/" + f)
    return bad, n


def contact_sheet(paths, cols, cell, out_path, bg=(20, 30, 34, 255)):
    """Montage sprites onto one image for quick visual QA."""
    rows = int(math.ceil(len(paths) / float(cols)))
    W, H = cols * cell, rows * cell
    out = Image.new("RGBA", (W, H), bg)
    for i, p in enumerate(paths):
        im = Image.open(p).convert("RGBA")
        im.thumbnail((cell - 8, cell - 8), Image.LANCZOS)
        cx, cy = (i % cols) * cell + cell // 2, (i // cols) * cell + cell // 2
        out.alpha_composite(im, (cx - im.width // 2, cy - im.height // 2))
    flat = Image.new("RGB", out.size, bg[:3])
    flat.paste(out, mask=out.getchannel("A"))
    flat.save(out_path)
    return out_path
