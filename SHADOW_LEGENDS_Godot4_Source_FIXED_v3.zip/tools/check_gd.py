"""Static sanity checks for the GDScript codebase (no Godot available here):
- balanced (), [], {} outside strings/comments
- balanced quotes
- duplicate func definitions per file
- tabs/spaces mix check
- references to undefined script-level helper names (heuristic: Vfx/UIKit/etc. exist)
"""
import os
import re
import sys

ROOT = "/home/z/my-project/download/SHADOW_LEGENDS/scripts"
problems = []


def strip_comments_strings(src):
    out = []
    i = 0
    n = len(src)
    in_str = False
    q = ""
    while i < n:
        c = src[i]
        if in_str:
            out.append(" " if c != q else " ")
            if c == "\\":
                out.append(" ")
                i += 1
            elif c == q:
                in_str = False
        else:
            if c in "\"'":
                in_str = True
                q = c
                out.append(" ")
            elif c == "#":
                while i < n and src[i] != "\n":
                    i += 1
                out.append("\n")
                i += 1
                continue
            else:
                out.append(c)
        i += 1
    return "".join(out)


files = []
for root, dirs, fs in os.walk(ROOT):
    for f in fs:
        if f.endswith(".gd"):
            files.append(os.path.join(root, f))

for p in sorted(files):
    src = open(p, encoding="utf-8").read()
    stripped = strip_comments_strings(src)
    for a, b in (("(", ")"), ("[", "]"), ("{", "}")):
        if stripped.count(a) != stripped.count(b):
            problems.append(f"{p}: unbalanced {a}{b} {stripped.count(a)}/{stripped.count(b)}")
    # quote balance: odd number of unescaped quotes means trouble
    if src.count('"') % 2 != 0 and src.count("'") % 2 != 0:
        problems.append(f"{p}: odd quote counts")
    # duplicate funcs
    names = re.findall(r"^func\s+([a-zA-Z_][a-zA-Z0-9_]*)", src, re.M)
    dups = {x for x in names if names.count(x) > 1}
    if dups:
        problems.append(f"{p}: duplicate funcs {dups}")
    # mixed indentation (only outside bracket continuations)
    depth = 0
    for line in src.split("\n"):
        s = strip_comments_strings(line)
        lead = re.match(r"^(\t+ +)", line)
        if lead and depth == 0:
            problems.append(f"{p}: mixed tab/space indent: {line[:40]!r}")
            break
        depth += s.count("(") + s.count("[") + s.count("{")
        depth -= s.count(")") + s.count("]") + s.count("}")

print(f"checked {len(files)} gd files")
if problems:
    for pr in problems:
        print("PROBLEM:", pr)
    sys.exit(1)
print("OK - no structural problems found")
