"""SHADOW LEGENDS — art pipeline main entry.
Generates all game art (backgrounds, platforms, props, traps, pickups,
characters, enemies, boss, effects, UI, icons), verifies nothing is blank,
and builds a labeled art-direction preview montage (NOT an in-game screenshot).
"""
import os
import sys

sys.path.insert(0, "/home/z/my-project/scripts")

from PIL import Image, ImageDraw

from art_characters import gen_boss, gen_enemies, gen_wolf, ninja_sheet
from art_fx import gen_effects_ui
from art_lib import ASSETS, contact_sheet, verify_dir
from art_worlds import gen_backgrounds, gen_platforms, gen_traps_pickups, gen_world_props


def gen_icons():
    from art_lib import canvas, add_glow, save
    from art_lib import PAL
    import math
    # App icon: black disc, red eye, teal rim — matches the game identity
    for size, name in ((192, "icon.png"), (432, "icon_bg.png"), (432, "icon_fg.png")):
        img = canvas(size, size)
        d = ImageDraw.Draw(img)
        if name == "icon_bg.png":
            d.rectangle([0, 0, size, size], fill=(13, 40, 50, 255))
            continue
        d.ellipse([8, 8, size - 8, size - 8], fill=(7, 11, 13, 255),
                  outline=(58, 110, 112, 255), width=max(4, size // 40))
        cx, cy = size // 2, size // 2
        ew = size // 5
        add_glow(img, lambda dd, c: dd.ellipse([cx - ew, cy - ew // 2, cx + ew, cy + ew // 2], fill=c),
                 PAL["red_hot"] + (255,), size // 12, 1.0)
        d = ImageDraw.Draw(img)
        d.ellipse([cx - ew + 6, cy - ew // 4, cx + ew - 6, cy + ew // 4], fill=PAL["red"] + (255,))
        d.ellipse([cx - ew // 3, cy - ew // 6, cx + ew // 3, cy + ew // 6], fill=(255, 90, 90, 255))
        save(img, "icons", name)
    # cursor
    img = canvas(32, 32)
    d = ImageDraw.Draw(img)
    d.polygon([(4, 2), (4, 26), (11, 19), (16, 29), (20, 27), (15, 17), (24, 15)], fill=(220, 230, 232, 255))
    save(img, "icons", "cursor.png")
    return 4


def main():
    counts = {}
    counts["backgrounds+platforms+props"] = len(gen_backgrounds()) + len(gen_platforms()) + len(gen_world_props()) + len(gen_traps_pickups())
    counts["characters"] = 1  # ninja sheet
    meta_ninja = ninja_sheet()
    meta_en = gen_enemies()
    meta_wolf = gen_wolf()
    meta_boss = gen_boss()
    counts["fx+ui"] = len(gen_effects_ui())
    counts["icons"] = gen_icons()

    # verification: no blank images anywhere
    bad_total = []
    report = {}
    for kind in ("backgrounds", "environments", "characters", "enemies", "bosses",
                 "effects", "ui", "icons", "audio", "fonts"):
        try:
            bad, n = verify_dir(kind)
            report[kind] = n
            bad_total += bad
        except ValueError:
            report[kind] = 0
    print("PNG counts per dir:", report)
    if bad_total:
        print("BLANK/BROKEN:", bad_total)
        sys.exit(1)

    # contact sheets for QA (dev-facing, not deliverable art)
    qa = "/tmp/render"
    os.makedirs(qa, exist_ok=True)
    char_paths = [os.path.join(ASSETS, "characters", "ninja_sheet.png")]
    for f in sorted(os.listdir(os.path.join(ASSETS, "enemies"))):
        char_paths.append(os.path.join(ASSETS, "enemies", f))
    char_paths.append(os.path.join(ASSETS, "bosses", "abyss_lord_sheet.png"))
    # slice first frames of each sheet into individual images for the montage
    tiles = []
    for p in char_paths:
        im = Image.open(p)
        fw = 256 if im.height == 256 else 128
        for i in range(0, min(im.width, fw * 14), fw):
            tiles.append(im.crop((i, 0, i + fw, im.height)))
    tmp_dir = os.path.join(qa, "tiles")
    os.makedirs(tmp_dir, exist_ok=True)
    tile_paths = []
    for i, t in enumerate(tiles):
        pth = os.path.join(tmp_dir, f"t{i:03d}.png")
        t.save(pth)
        tile_paths.append(pth)
    contact_sheet(tile_paths[:56], 8, 150, os.path.join(qa, "qa_characters.jpg"))
    print("contact sheet at /tmp/render/qa_characters.jpg")
    print("ALL ART OK")


if __name__ == "__main__":
    main()
