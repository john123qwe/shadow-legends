"""SHADOW LEGENDS — combat effects, UI kits, icons."""
import math

import numpy as np
from PIL import Image, ImageDraw, ImageFilter

from art_lib import PAL, add_glow, canvas, radial_gradient, rng, save

RED = PAL["red"]
REDHOT = PAL["red_hot"]


# ----------------------------------------------------------------------------
# Combat FX
# ----------------------------------------------------------------------------
def make_slash(variant):
    """Red katana slash arcs. variant 0..2 combo, 3 = special burst."""
    S = 160
    img = canvas(S, S)
    d = ImageDraw.Draw(img)
    if variant == 0:  # thin crescent, horizontal
        bbox = [10, 40, 150, 130]
        d.pieslice(bbox, 190, 350, fill=REDHOT + (255,))
        cut = canvas(S, S)
        ImageDraw.Draw(cut).pieslice([bbox[0] + 14, bbox[1] + 18, bbox[2] - 6, bbox[3] - 10],
                                     180, 360, fill=(0, 0, 0, 255))
        img = Image.composite(canvas(S, S), img, cut.getchannel("A").point(lambda v: 255 - v))
    elif variant == 1:  # reverse arc
        bbox = [14, 30, 146, 132]
        d.pieslice(bbox, 200, 345, fill=RED + (255,))
        cut = canvas(S, S)
        ImageDraw.Draw(cut).pieslice([bbox[0] + 16, bbox[1] + 22, bbox[2] - 8, bbox[3] - 14],
                                     190, 355, fill=(0, 0, 0, 255))
        img = Image.composite(canvas(S, S), img, cut.getchannel("A").point(lambda v: 255 - v))
    elif variant == 2:  # spin ring segment
        bbox = [16, 16, 144, 144]
        d.arc(bbox, 300, 80, fill=REDHOT + (255,), width=14)
        d.arc([26, 26, 134, 134], 300, 80, fill=RED + (180,), width=6)
    else:  # special: full ring burst + shards
        add_glow(img, lambda dd, c: dd.ellipse([24, 24, 136, 136], outline=c, width=10),
                 REDHOT, 12, 1.0)
        d = ImageDraw.Draw(img)
        d.ellipse([30, 30, 130, 130], outline=RED + (220,), width=6)
        r = rng(5)
        for i in range(10):
            a = r.uniform(0, math.tau)
            rr = r.uniform(58, 76)
            x, y = 80 + math.cos(a) * rr, 80 + math.sin(a) * rr
            d.line([80 + math.cos(a) * 50, 80 + math.sin(a) * 50, x, y],
                   fill=REDHOT + (230,), width=3)
    # soft inner glow
    gl = img.filter(ImageFilter.GaussianBlur(6))
    a = gl.getchannel("A").point(lambda v: int(v * 0.75))
    gl.putalpha(a)
    out = canvas(S, S)
    out.alpha_composite(gl)
    out.alpha_composite(img)
    return out


def make_impact():
    """Hit spark burst."""
    S = 96
    img = canvas(S, S)
    d = ImageDraw.Draw(img)
    add_glow(img, lambda dd, c: dd.ellipse([34, 34, 62, 62], fill=c), (255, 240, 220, 255), 8, 1.0)
    d = ImageDraw.Draw(img)
    d.ellipse([40, 40, 56, 56], fill=(255, 250, 240, 255))
    r = rng(9)
    for i in range(8):
        a = r.uniform(0, math.tau)
        rr = r.uniform(30, 44)
        x, y = 48 + math.cos(a) * rr, 48 + math.sin(a) * rr
        d.line([48 + math.cos(a) * 14, 48 + math.sin(a) * 14, x, y],
               fill=(255, 120, 110, 230), width=4)
    return img


def make_shockwave():
    S = 220
    img = canvas(S, S)
    d = ImageDraw.Draw(img)
    add_glow(img, lambda dd, c: dd.arc([20, 70, 200, 180], 190, 350, fill=c, width=14), REDHOT, 14, 1.0)
    d = ImageDraw.Draw(img)
    d.arc([26, 76, 194, 174], 190, 350, fill=RED + (230,), width=7)
    r = rng(3)
    for i in range(8):
        a = math.radians(r.uniform(200, 340))
        x0, y0 = 110 + math.cos(a) * 70, 125 + math.sin(a) * 42
        d.line([x0, y0, x0 + math.cos(a) * 22, y0 + math.sin(a) * 12], fill=REDHOT + (220,), width=4)
    return img


def make_dash_trail():
    S = 200
    img = canvas(S, 80)
    grad = np.zeros((80, S, 4), dtype=np.uint8)
    for x in range(S):
        t = 1.0 - x / float(S)
        a = int(200 * (t ** 1.6))
        grad[:, x] = [200, 40, 52, a]
    img = Image.fromarray(grad, "RGBA").filter(ImageFilter.GaussianBlur(6))
    return img


def make_ghost():
    """Dash afterimage: simplified ninja silhouette."""
    img = canvas(128, 128)
    d = ImageDraw.Draw(img)
    col = (150, 40, 52, 120)
    d.polygon([(54, 52), (66, 52), (62, 90), (52, 90)], fill=col)
    d.ellipse([52, 34, 68, 52], fill=col)
    d.line([58, 90, 52, 118], fill=col, width=8)
    d.line([62, 90, 68, 116], fill=col, width=8)
    d.line([66, 60, 96, 74], fill=col, width=7)
    d.polygon([(48, 46), (34, 84), (54, 88)], fill=col)
    return img.filter(ImageFilter.GaussianBlur(1))


def make_projectiles():
    arrow = canvas(64, 20)
    d = ImageDraw.Draw(arrow)
    d.line([4, 10, 48, 10], fill=(180, 60, 64, 255), width=3)
    d.polygon([(48, 5), (60, 10), (48, 15)], fill=REDHOT + (255,))
    d.line([10, 6, 16, 10], fill=(140, 40, 44, 255), width=2)
    d.line([10, 14, 16, 10], fill=(140, 40, 44, 255), width=2)
    orb = canvas(56, 56)
    add_glow(orb, lambda dd, c: dd.ellipse([14, 14, 42, 42], fill=c), REDHOT, 10, 1.0)
    d = ImageDraw.Draw(orb)
    d.ellipse([20, 20, 36, 36], fill=(255, 180, 180, 255))
    return arrow, orb


def make_particles():
    soft = radial_gradient((32, 32), (255, 255, 255, 255), (255, 255, 255, 0))
    red = radial_gradient((32, 32), REDHOT + (255,), REDHOT + (0,))
    teal = radial_gradient((24, 24), PAL["teal_glow"] + (255,), PAL["teal_glow"] + (0,))
    firefly = radial_gradient((16, 16), (190, 240, 230, 255), (190, 240, 230, 0))
    smoke = canvas(64, 64)
    d = ImageDraw.Draw(smoke)
    for i, rr in ((0, 22), (1, 16)):
        d.ellipse([32 - rr, 32 - rr, 32 + rr, 32 + rr], fill=(70, 90, 96, 150))
    smoke = smoke.filter(ImageFilter.GaussianBlur(8))
    return soft, red, teal, firefly, smoke


# ----------------------------------------------------------------------------
# UI kit
# ----------------------------------------------------------------------------
def nine_panel():
    img = canvas(96, 96)
    d = ImageDraw.Draw(img)
    d.rounded_rectangle([2, 2, 94, 94], radius=18, fill=(8, 14, 17, 235),
                        outline=(58, 110, 112, 255), width=3)
    d.rounded_rectangle([8, 8, 88, 88], radius=14, outline=(30, 64, 66, 180), width=2)
    # corner accents
    for cx, cy, sx in ((12, 12, 1), (84, 12, -1), (12, 84, 1), (84, 84, -1)):
        d.line([cx, cy, cx + sx * 10, cy], fill=RED + (200,), width=3)
    return img


def make_button(pressed=False):
    img = canvas(160, 64)
    d = ImageDraw.Draw(img)
    fill = (12, 22, 26, 245) if not pressed else (20, 38, 42, 245)
    edge = (70, 130, 132, 255) if not pressed else (120, 190, 190, 255)
    d.rounded_rectangle([2, 2, 158, 62], radius=14, fill=fill, outline=edge, width=3)
    d.rounded_rectangle([2, 2, 158, 30], radius=12, fill=(255, 255, 255, 12))
    return img


def make_bar(fill_color):
    bg = canvas(280, 30)
    d = ImageDraw.Draw(bg)
    d.rounded_rectangle([1, 1, 279, 29], radius=12, fill=(6, 10, 12, 230),
                        outline=(52, 96, 98, 255), width=2)
    save(bg, "ui", "bar_bg.png")
    fill = canvas(280, 30)
    d = ImageDraw.Draw(fill)
    d.rounded_rectangle([3, 3, 277, 27], radius=10, fill=fill_color + (255,))
    # glossy top
    d.rounded_rectangle([6, 5, 274, 14], radius=6, fill=(255, 255, 255, 60))
    save(fill, "ui", "bar_fill.png")
    return bg, fill


def make_round_button(glyph):
    img = canvas(128, 128)
    d = ImageDraw.Draw(img)
    d.circle([64, 64], 60, fill=(8, 14, 17, 200), outline=(64, 120, 122, 255), width=4)
    d.circle([64, 64], 52, outline=(30, 62, 64, 200), width=2)
    gc = (225, 236, 238, 255)
    if glyph == "jump":
        d.polygon([(64, 26), (92, 58), (76, 58), (76, 96), (52, 96), (52, 58), (36, 58)], fill=gc)
    elif glyph == "attack":
        d.line([36, 92, 88, 40], fill=gc, width=9)
        d.polygon([(88, 30), (98, 30), (94, 42)], fill=REDHOT + (255,))
        d.line([30, 86, 44, 100], fill=gc, width=10)
    elif glyph == "dash":
        for i, x in enumerate((26, 44, 62)):
            d.polygon([(x, 44), (x + 26, 64), (x, 84), (x + 10, 64)], fill=gc)
        d.line([88, 64, 104, 64], fill=REDHOT + (255,), width=6)
    elif glyph == "special":
        add_glow(img, lambda dd, c: dd.circle([64, 64], 34, fill=c), REDHOT, 14, 1.0)
        d = ImageDraw.Draw(img)
        for a in range(8):
            ang = math.radians(a * 45)
            x0, y0 = 64 + math.cos(ang) * 26, 64 + math.sin(ang) * 26
            x1, y1 = 64 + math.cos(ang) * 44, 64 + math.sin(ang) * 44
            d.line([x0, y0, x1, y1], fill=gc, width=6)
        d.circle([64, 64], 22, fill=RED + (255,))
        d.circle([64, 64], 12, fill=(255, 170, 170, 255))
    elif glyph == "pause":
        d.rounded_rectangle([44, 36, 58, 92], radius=6, fill=gc)
        d.rounded_rectangle([70, 36, 84, 92], radius=6, fill=gc)
    return img


def make_currency_icons():
    coin = canvas(72, 72)
    add_glow(coin, lambda dd, c: dd.circle([36, 36], 26, fill=c), (255, 216, 120, 255), 10, 0.9)
    d = ImageDraw.Draw(coin)
    d.circle([36, 36], 24, fill=PAL["gold"] + (255,), outline=(255, 216, 120, 255), width=3)
    d.line([30, 24, 30, 48], fill=(120, 84, 24, 255), width=5)
    gem = canvas(72, 72)
    d = ImageDraw.Draw(gem)
    add_glow(gem, lambda dd, c: dd.polygon([(36, 6), (62, 30), (36, 66), (10, 30)], fill=c),
             REDHOT, 12, 0.9)
    d = ImageDraw.Draw(gem)
    d.polygon([(36, 8), (58, 30), (36, 62), (14, 30)], fill=RED + (255,))
    d.polygon([(36, 8), (58, 30), (36, 34), (14, 30)], fill=(255, 255, 255, 90))
    return coin, gem


def make_item_icons():
    out = {}
    # weapon (katana crossed)
    img = canvas(96, 96)
    d = ImageDraw.Draw(img)
    d.line([20, 76, 72, 24], fill=(220, 230, 232, 255), width=6)
    d.line([24, 80, 36, 68], fill=(90, 100, 104, 255), width=9)
    d.line([72, 76, 24, 28], fill=(180, 190, 192, 255), width=5)
    d.line([24, 28, 18, 22], fill=RED + (255,), width=4)
    out["item_weapon"] = img
    # armor (chest plate)
    img = canvas(96, 96)
    d = ImageDraw.Draw(img)
    d.polygon([(28, 20), (68, 20), (74, 40), (66, 78), (48, 86), (30, 78), (22, 40)], fill=(120, 134, 138, 255))
    d.polygon([(28, 20), (48, 26), (68, 20), (64, 34), (48, 40), (32, 34)], fill=(160, 176, 180, 255))
    out["item_armor"] = img
    # accessory (ring + gem)
    img = canvas(96, 96)
    d = ImageDraw.Draw(img)
    d.arc([28, 34, 68, 74], 0, 360, fill=(170, 186, 190, 255), width=7)
    add_glow(img, lambda dd, c: dd.polygon([(48, 14), (60, 26), (48, 38), (36, 26)], fill=c), REDHOT, 8, 0.9)
    out["item_accessory"] = img
    # potion
    img = canvas(96, 96)
    d = ImageDraw.Draw(img)
    d.rounded_rectangle([40, 14, 56, 30], radius=4, fill=(150, 160, 164, 255))
    d.circle([48, 58], 26, fill=(150, 30, 40, 255), outline=(190, 200, 204, 255), width=3)
    d.ellipse([36, 42, 60, 58], fill=(210, 60, 70, 255))
    out["item_potion"] = img
    # material (shard)
    img = canvas(96, 96)
    d = ImageDraw.Draw(img)
    d.polygon([(48, 12), (70, 44), (58, 84), (34, 76), (26, 40)], fill=(70, 96, 102, 255))
    d.polygon([(48, 12), (62, 40), (48, 36), (34, 40)], fill=(110, 140, 146, 255))
    out["item_material"] = img
    # skin (mask)
    img = canvas(96, 96)
    d = ImageDraw.Draw(img)
    d.ellipse([26, 22, 70, 76], fill=(16, 22, 24, 255), outline=(80, 130, 132, 255), width=3)
    d.ellipse([36, 40, 44, 48], fill=REDHOT + (255,))
    d.ellipse([52, 40, 60, 48], fill=REDHOT + (255,))
    out["item_skin"] = img
    return out


def make_misc_icons():
    # star (achievements)
    img = canvas(96, 96)
    d = ImageDraw.Draw(img)
    pts = []
    for i in range(10):
        a = math.radians(-90 + i * 36)
        rr = 38 if i % 2 == 0 else 16
        pts.append((48 + math.cos(a) * rr, 48 + math.sin(a) * rr))
    d.polygon(pts, fill=PAL["gold"] + (255,))
    # skull
    img = canvas(96, 96)
    d = ImageDraw.Draw(img)
    d.ellipse([26, 18, 70, 62], fill=(210, 216, 218, 255))
    d.rectangle([34, 54, 62, 74], fill=(210, 216, 218, 255))
    d.ellipse([36, 34, 46, 46], fill=(10, 14, 16, 255))
    d.ellipse([50, 34, 60, 46], fill=(10, 14, 16, 255))
    d.rectangle([40, 66, 46, 76], fill=(10, 14, 16, 255))
    d.rectangle([52, 66, 58, 76], fill=(10, 14, 16, 255))
    save(img, "ui", "icon_skull.png")
    # gear (settings)
    img = canvas(96, 96)
    d = ImageDraw.Draw(img)
    for a in range(8):
        ang = math.radians(a * 45)
        x0, y0 = 48 + math.cos(ang) * 30, 48 + math.sin(ang) * 30
        x1, y1 = 48 + math.cos(ang) * 42, 48 + math.sin(ang) * 42
        d.line([x0, y0, x1, y1], fill=(190, 200, 204, 255), width=10)
    d.circle([48, 48], 30, fill=(150, 160, 164, 255))
    d.circle([48, 48], 14, fill=(10, 14, 16, 255))
    save(img, "ui", "icon_gear.png")
    return img


def gen_effects_ui():
    saved = []
    for i in range(4):
        saved.append(save(make_slash(i), "effects", f"slash_{i}.png"))
    saved.append(save(make_impact(), "effects", "impact.png"))
    saved.append(save(make_shockwave(), "effects", "shockwave.png"))
    saved.append(save(make_dash_trail(), "effects", "dash_trail.png"))
    saved.append(save(make_ghost(), "effects", "dash_ghost.png"))
    arrow, orb = make_projectiles()
    saved.append(save(arrow, "effects", "arrow.png"))
    saved.append(save(orb, "effects", "orb.png"))
    soft, red, teal, firefly, smoke = make_particles()
    for nm, im in (("particle_soft", soft), ("particle_red", red), ("particle_teal", teal),
                   ("firefly", firefly), ("smoke", smoke)):
        saved.append(save(im, "effects", nm + ".png"))
    # UI
    saved.append(save(nine_panel(), "ui", "panel.png"))
    saved.append(save(make_button(False), "ui", "btn.png"))
    saved.append(save(make_button(True), "ui", "btn_pressed.png"))
    make_bar(PAL["red"])
    save(make_bar_fill(PAL["red"]), "ui", "bar_red.png")
    save(make_bar_fill(PAL["gold"]), "ui", "bar_gold.png")
    save(make_bar_fill(PAL["teal_glow"]), "ui", "bar_teal.png")
    for g in ("jump", "attack", "dash", "special", "pause"):
        saved.append(save(make_round_button(g), "ui", f"rbtn_{g}.png"))
    coin, gem = make_currency_icons()
    saved.append(save(coin, "ui", "icon_coin.png"))
    saved.append(save(gem, "ui", "icon_gem.png"))
    for nm, im in make_item_icons().items():
        saved.append(save(im, "ui", nm + ".png"))
    make_misc_icons()
    return saved


def make_bar_fill(color):
    img = canvas(274, 24)
    d = ImageDraw.Draw(img)
    d.rounded_rectangle([0, 0, 273, 23], radius=10, fill=color + (255,))
    d.rounded_rectangle([3, 2, 270, 11], radius=5, fill=(255, 255, 255, 70))
    return img


if __name__ == "__main__":
    out = gen_effects_ui()
    print("fx/ui assets written:", len(out))
