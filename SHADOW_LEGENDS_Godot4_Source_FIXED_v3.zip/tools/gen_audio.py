"""SHADOW LEGENDS — original procedural audio (WAV 22050 Hz mono 16-bit).
SFX + seamless dark-ambient loops. All audio is synthesized (original, license-free).
"""
import os
import struct
import wave

import numpy as np

SR = 22050
OUT = "/home/z/my-project/download/SHADOW_LEGENDS/assets/audio"


def write_wav(name, data, sr=SR):
    os.makedirs(OUT, exist_ok=True)
    data = np.clip(data, -1.0, 1.0)
    pcm = (data * 32000).astype(np.int16)
    with wave.open(os.path.join(OUT, name), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(sr)
        w.writeframes(pcm.tobytes())


def t(dur):
    return np.linspace(0, dur, int(SR * dur), endpoint=False)


def env(n, a=0.01, r=0.1, dur=None):
    """Attack/release envelope for n samples."""
    dur = dur if dur else n / SR
    x = np.linspace(0, dur, n, endpoint=False)
    e = np.minimum(x / max(a, 1e-4), 1.0)
    tail = np.clip((dur - x) / max(r, 1e-4), 0.0, 1.0)
    return np.minimum(e, tail)


def sine(f, dur, phase=0.0):
    return np.sin(2 * np.pi * f * t(dur) + phase)


def noise(dur):
    return np.random.default_rng(0).standard_normal(int(SR * dur))


def lowpass(x, alpha):
    y = np.empty_like(x)
    acc = 0.0
    for i, v in enumerate(x):
        acc += alpha * (v - acc)
        y[i] = acc
    return y


def sweep_noise(dur, f0, f1, q=6.0):
    """Bandpassed noise whose center frequency sweeps f0->f1 (sword swish)."""
    n = int(SR * dur)
    white = np.random.default_rng(1).standard_normal(n)
    # simple time-varying resonant filter
    out = np.empty(n)
    y1 = y2 = 0.0
    for i in range(n):
        fc = f0 + (f1 - f0) * (i / n)
        r = np.exp(-2 * np.pi * fc / q / SR)
        a1 = 2 * r * np.cos(2 * np.pi * fc / SR)
        a2 = -r * r
        inp = white[i]
        y = inp + a1 * y1 + a2 * y2
        # normalize by resonance gain
        out[i] = y * 0.35
        y2, y1 = y1, y
    return out



def mix(*sigs):
    """Sum signals of different lengths, padding to the longest."""
    n = max(len(s) for s in sigs)
    out = np.zeros(n)
    for s in sigs:
        out[:len(s)] += s
    return out

def bell(f, dur, decay=3.0):
    x = t(dur)
    return (np.sin(2 * np.pi * f * x) + 0.4 * np.sin(2 * np.pi * f * 2.7 * x)
            + 0.2 * np.sin(2 * np.pi * f * 5.4 * x)) * np.exp(-decay * x)


# ----------------------------------------------------------------------------
# SFX
# ----------------------------------------------------------------------------
def gen_sfx():
    P = {}
    # sword swishes — three combo variants
    for i, (f0, f1, dur) in enumerate(((900, 2400, 0.16), (1400, 700, 0.16), (500, 2600, 0.24))):
        s = sweep_noise(dur, f0, f1)
        s *= env(len(s), 0.008, 0.05, dur)
        write_wav(f"swish_{i+1}.wav", s * 0.8)
    # special burst
    s = sweep_noise(0.5, 300, 3200) * env(int(SR * 0.5), 0.01, 0.3, 0.5)
    s = mix(s, bell(180, 0.5, 6) * 0.6)
    write_wav("special.wav", s * 0.85)
    # hit (normal + crit)
    h = noise(0.12) * env(int(SR * 0.12), 0.002, 0.1, 0.12)
    th = sine(140, 0.12) * np.exp(-30 * t(0.12))
    write_wav("hit_1.wav", mix(h * 0.5, th * 0.9) * 0.9)
    hc = noise(0.18) * env(int(SR * 0.18), 0.002, 0.12, 0.18)
    thc = sine(90, 0.18) * np.exp(-22 * t(0.18))
    write_wav("hit_crit.wav", mix(hc * 0.6, thc * 1.1) * 1.0)
    # player hurt / death
    hu = lowpass(noise(0.25), 0.15) * env(int(SR * 0.25), 0.005, 0.2, 0.25)
    hu = mix(hu, sine(160, 0.25) * np.exp(-14 * t(0.25)) * 0.8)
    write_wav("hurt.wav", hu * 0.9)
    dd = mix(sine(220, 0.9) * np.exp(-3.2 * t(0.9)), sine(110, 0.9) * np.exp(-2.4 * t(0.9)) * 0.7)
    write_wav("death.wav", dd * 0.8)
    # enemy death (short dissolve)
    ed = lowpass(noise(0.35), 0.12) * env(int(SR * 0.35), 0.01, 0.3, 0.35)
    ed = mix(ed, sine(300, 0.35) * np.exp(-9 * t(0.35)) * 0.4)
    write_wav("enemy_death.wav", ed * 0.7)
    # jump / dash
    j = sweep_noise(0.18, 300, 900) * env(int(SR * 0.18), 0.01, 0.08, 0.18)
    write_wav("jump.wav", j * 0.6)
    j2 = sweep_noise(0.16, 500, 1100) * env(int(SR * 0.16), 0.01, 0.06, 0.16)
    write_wav("double_jump.wav", j2 * 0.55)
    da = lowpass(noise(0.3), 0.4) * env(int(SR * 0.3), 0.01, 0.2, 0.3)
    write_wav("dash.wav", da * 0.8)
    # pickups
    write_wav("coin.wav", mix(bell(1180, 0.18, 9), bell(1560, 0.12, 11) * 0.6) * 0.5)
    write_wav("gem.wav", mix(bell(1560, 0.3, 7), bell(2080, 0.25, 8) * 0.7) * 0.5)
    write_wav("xp.wav", bell(980, 0.22, 9) * 0.4)
    write_wav("heal.wav", mix(bell(660, 0.4, 6), bell(990, 0.35, 6) * 0.5) * 0.5)
    # UI
    write_wav("ui_click.wav", mix(bell(1400, 0.08, 22) * 0.5, noise(0.03) * env(int(SR * 0.03), 0.001, 0.02, 0.03) * 0.3))
    write_wav("ui_open.wav", sweep_noise(0.22, 500, 1500) * env(int(SR * 0.22), 0.01, 0.15, 0.22) * 0.4)
    write_wav("level_up.wav", mix(bell(523, 0.5, 5), bell(659, 0.45, 5) * 0.8, bell(784, 0.4, 5) * 0.6) * 0.45)
    write_wav("checkpoint.wav", mix(bell(440, 0.7, 4), bell(880, 0.6, 5) * 0.5) * 0.45)
    write_wav("portal.wav", mix(sweep_noise(0.8, 200, 1600) * env(int(SR * 0.8), 0.05, 0.4, 0.8) * 0.6, bell(220, 0.8, 4) * 0.5))
    # boss
    br = lowpass(noise(1.1), 0.06) * env(int(SR * 1.1), 0.05, 0.7, 1.1)
    br = mix(br, sine(55, 1.1) * np.exp(-2.5 * t(1.1)) * 1.2, sine(82, 1.1) * np.exp(-2.2 * t(1.1)) * 0.8)
    write_wav("boss_roar.wav", br * 1.0)
    bs = mix(sine(70, 0.6) * np.exp(-8 * t(0.6)) * 1.3, lowpass(noise(0.6), 0.1) * env(int(SR * 0.6), 0.005, 0.4, 0.6) * 0.8)
    write_wav("boss_slam.wav", bs * 1.0)
    # projectiles
    ar = sweep_noise(0.22, 1800, 600) * env(int(SR * 0.22), 0.01, 0.12, 0.22)
    write_wav("arrow.wav", ar * 0.5)
    ob = mix(sweep_noise(0.4, 600, 220) * env(int(SR * 0.4), 0.02, 0.25, 0.4) * 0.6, bell(310, 0.4, 6) * 0.4)
    write_wav("orb.wav", ob * 0.55)
    write_wav("trap.wav", mix(sine(200, 0.2) * np.exp(-16 * t(0.2)), noise(0.2) * env(int(SR * 0.2), 0.002, 0.15, 0.2) * 0.4) * 0.7)
    print("sfx done:", len(os.listdir(OUT)))


# ----------------------------------------------------------------------------
# Ambient / music loops (seamless: all components periodic over loop length)
# ----------------------------------------------------------------------------
def drone_loop(dur, base_f, bright=0.3, seed=2):
    n = int(SR * dur)
    x = np.linspace(0, dur, n, endpoint=False)
    out = np.zeros(n)
    rng = np.random.default_rng(seed)
    for mult, amp in ((1, 1.0), (2, 0.55), (3.01, 0.28), (4.02, bright * 0.5)):
        f = base_f * mult
        # keep each partial an exact integer number of cycles for seamless loop
        k = max(1, round(f * dur))
        ph = rng.uniform(0, 2 * np.pi)
        out += amp * np.sin(2 * np.pi * k * x / dur + ph)
    # slow tremolo (periodic over loop)
    trem = 0.82 + 0.18 * np.sin(2 * np.pi * 2 * x / dur + rng.uniform(0, 6))
    return out * trem


def wind_loop(dur, seed=3, cutoff=0.04, level=0.35):
    n = int(SR * dur)
    w = np.random.default_rng(seed).standard_normal(n)
    f = lowpass(w, cutoff)
    # crossfade tail into head for seamless noise loop
    fade = int(SR * 1.5)
    f[:fade] = f[:fade] * np.linspace(0, 1, fade) + f[-fade:] * np.linspace(1, 0, fade)
    f = f[: n - 0] if len(f) == n else f[:n]
    f -= f.mean()
    f /= max(1e-9, np.abs(f).max())
    x = np.linspace(0, dur, n, endpoint=False)
    swell = 0.7 + 0.3 * np.sin(2 * np.pi * 1 * x / dur)
    return f * level * swell


def gen_loops():
    dur = 24.0
    # menu — deep drone + sparse bells
    m = drone_loop(dur, 55, 0.25, seed=5) * 0.5 + wind_loop(dur, 6, 0.02, 0.18)
    x = t(dur)
    # periodic bells: exact loop alignment
    for f, at in ((220.0, 6.0), (261.63, 12.0), (174.61, 18.0)):
        n_bell = int(SR * 3.0)
        start = int(at * SR)
        b = bell(f, 3.0, 2.0) * 0.22
        end = min(len(m), start + n_bell)
        m[start:end] += b[: end - start]
    write_wav("music_menu.wav", m * 0.9)
    # forest ambience
    fo = drone_loop(dur, 62, 0.3, seed=7) * 0.42 + wind_loop(dur, 8, 0.05, 0.3)
    for f, at in ((196.0, 4.0), (233.08, 13.5)):
        start = int(at * SR)
        b = bell(f, 2.5, 2.4) * 0.15
        end = min(len(fo), start + int(SR * 2.5))
        fo[start:end] += b[: end - start]
    write_wav("amb_forest.wav", fo)
    # cave — colder, lower
    ca = drone_loop(dur, 49, 0.15, seed=9) * 0.5 + wind_loop(dur, 10, 0.015, 0.22)
    write_wav("amb_cave.wav", ca)
    # kingdom — ember warmth
    ki = drone_loop(dur, 65.4, 0.5, seed=11) * 0.45 + wind_loop(dur, 12, 0.03, 0.2)
    write_wav("amb_kingdom.wav", ki)
    # temple — mystic
    te = drone_loop(dur, 58.3, 0.4, seed=13) * 0.48 + wind_loop(dur, 14, 0.02, 0.2)
    write_wav("amb_temple.wav", te)
    # boss — pulsing menace (12s loop)
    bd = 12.0
    x = t(bd)
    pulse = (np.sin(2 * np.pi * 2 * x / bd) > 0).astype(float)
    b = drone_loop(bd, 46.2, 0.35, seed=15) * (0.55 + 0.45 * pulse)
    b += sine(46.2 * 2, bd) * 0.2 * pulse
    # periodic slam
    for at in (0.0, 6.0):
        start = int(at * SR)
        sl = sine(55, 0.5) * np.exp(-10 * t(0.5)) * 0.9
        end = min(len(b), start + len(sl))
        b[start:end] += sl[: end - start]
    write_wav("music_boss.wav", b * 0.95)
    # victory / defeat stings
    v = np.zeros(int(SR * 3.0))
    for i, f in enumerate((523.25, 659.25, 783.99, 1046.5)):
        st = bell(f, 2.2, 2.0)
        s0 = int(i * 0.18 * SR)
        v[s0:s0 + len(st)] += st * 0.35
    write_wav("sting_victory.wav", v)
    df = mix(bell(220, 2.5, 1.6) * 0.5, bell(207.65, 2.5, 1.4) * 0.5, bell(110, 2.8, 1.2) * 0.6)
    write_wav("sting_defeat.wav", df * 0.8)
    print("loops done:", sorted(os.listdir(OUT)))


if __name__ == "__main__":
    gen_sfx()
    gen_loops()
    total = sum(os.path.getsize(os.path.join(OUT, f)) for f in os.listdir(OUT))
    print("audio total MB:", round(total / 1e6, 1))
