# SHADOW LEGENDS

Premium 2D dark-fantasy side-scrolling action platformer for **native Android**,
built with **Godot 4.3 + GDScript**. Persian (فارسی) RTL-first UI, offline
single-player, Cafe Bazaar (Poolakey) and Myket in-app billing.

> **Delivery status — read this first:** this repository contains the complete
> Godot 4 source project, original procedurally-generated art (112 PNGs) and
> audio (34 WAVs), full gameplay implementation, Android export presets and
> billing plugin source. It has **not** been compiled into an APK in the
> environment where it was written (no Godot binary / Android SDK available
> there — see `documentation/TESTING_REPORT.md` for the honest test matrix and
> `documentation/BUILD_AND_INSTALL.md` for how to build it in the cloud from
> your phone).

---

## What is implemented

| System | Status |
| --- | --- |
| Shadow Ninja player (move / double jump / shadow dash / 3-hit katana combo / special burst / hurt / death / victory) | ✅ implemented, art + code |
| 5 enemies (Shadow Wolf, Dark Knight, Blood Archer, Abyss Mage, Shadow Assassin) with AI, hurt/death, loot | ✅ implemented |
| THE ABYSS LORD boss — entrance cinematic, 3 phases, slam / charge / orb-barrage patterns, slow-mo defeat | ✅ implemented |
| World 1 "The Forgotten Forest" — 3 authored levels, parallax (sky/far/mid/fog/near), spike-flora traps, checkpoints, exit portal | ✅ implemented |
| Endless Abyss — procedural room assembly from 6 validated templates, depth scaling, boss every 4th room, score/record | ✅ implemented |
| Progression — XP curve, levels, gold, gems, 12-node skill tree (3 branches), 6 attributes, achievements (12), daily challenge | ✅ implemented |
| Inventory/equipment — weapons/armor/accessories/potions, 5 rarities, +upgrade levels, shop | ✅ implemented |
| Save system — versioned JSON, MD5 checksum, atomic swap + .bak recovery, autosave, crash-recovery for pending purchases | ✅ implemented |
| Persian RTL UI (Vazirmatn OFL font), Persian digits, English fallback | ✅ implemented |
| Touch controls — multi-touch joystick + 4 buttons, adjustable scale, keyboard fallback | ✅ implemented |
| HUD — HP/XP bars, level, gold/gems, boss bar, special/dash indicators, toasts | ✅ implemented |
| Audio — 34 original synthesized files (combo swishes, hits, boss roar, 5 world ambience loops, menu/boss music, stings) | ✅ implemented (synthesized; composed music = missing asset) |
| Cafe Bazaar billing — Poolakey Kotlin plugin + GDScript state machine | ✅ source complete, ❌ not tested against live Bazaar |
| Myket billing — IAB-v3-style Kotlin plugin + GDScript state machine | ✅ source complete, ❌ AAR dependency + AIDL constants must be verified against the official sample |
| APK/AAB builds | ❌ not built here — use the included GitHub Actions workflow (`Build Android`) |

## Quick start

1. **Open in Godot 4.3+** (or run the CI workflow — see below). First import
   takes a minute; Godot generates `.godot/` import caches.
2. Press **F5** to run. Desktop testing uses keyboard:
   `A/D` move, `W/Space` jump (×2 = double jump), `J` attack, `K` dash,
   `L` special, `Esc` pause. Mouse clicks emulate touch.
3. **Android:** see `documentation/BUILD_AND_INSTALL.md`.

## Project layout

```
SHADOW_LEGENDS/
├── project.godot            # engine config (landscape, gl_compatibility, autoloads)
├── export_presets.cfg       # shadow_legends_bazaar / shadow_legends_myket
├── scenes/                  # thin scene wrappers (trees built in code for reliability)
├── scripts/
│   ├── autoload/            # EventBus, Globals, AudioManager
│   ├── save/                # SaveSystem (atomic + checksummed)
│   ├── localization/        # Localization (fa/en)
│   ├── progression/         # GameDB (skills/items/worlds/products/achievements)
│   ├── billing/             # BillingBridge (Part 19 state machine)
│   ├── player/              # Player, CameraController, SpriteLib
│   ├── combat/              # Vfx, Projectile
│   ├── enemies/             # EnemyBase + 5 enemies
│   ├── bosses/              # AbyssLord
│   ├── levels/              # LevelBuilder, LevelDefs (W1), EndlessMode, GameWorld
│   ├── ui/                  # HUD, TouchControls, all screens, UIKit
│   └── main/                # Main (screen manager)
├── assets/                  # all art (generated) + audio (synthesized) + Vazirmatn fonts
├── android/                 # billing plugin sources (Kotlin), gradle modules, catalog
├── android/plugins/         # .gdap plugin configs + built AARs (CI refreshes them)
├── .github/workflows/       # build_android.yml (cloud APK build)
├── documentation/           # build, marketplace, testing report, asset spec
└── tests/                   # headless validation scripts + QA checklist
```

## Fair-monetization model (Part 15)

- IAP: gem packs, gold packs (consumables), cosmetic + remove-ads
  entitlements (non-consumables) — prices always fetched live from the store.
- **No forced or intrusive ads.** Rewarded ads are wired off by default; see
  `documentation/MARKETPLACE_INTEGRATION.md` § Ads for the requirements to
  enable an approved provider.
- No pay-to-win: purchasable items are currency and cosmetics only; power
  progression is earned through play.

## Licensing

- Code: MIT (see `LICENSE-MIT` placeholder — replace with your own header).
- Art & audio: original, procedurally generated for this project by the
  generator scripts in `/scripts` of the delivery bundle.
- Font: Vazirmatn — SIL Open Font License (`assets/fonts/Vazirmatn-OFL-LICENSE.txt`).
- Poolakey / Myket SDKs: their own licenses, loaded only at build time.
