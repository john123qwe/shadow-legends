# SHADOW LEGENDS — headless test runner
#
# Runs inside Godot (no UI needed):
#   godot --headless --path . --script tests/run_checks.gd
#
# IMPORTANT (Godot 4.3 script mode): `-s` scripts compile BEFORE the autoload
# singletons instantiate, and autoload global names (SaveSystem, AudioManager,
# ...) only become resolvable identifiers once instantiated. Class_name scripts
# that reference autoloads (e.g. LevelBuilder's coin-pickup lambda) therefore
# FAIL to compile if loaded during the script's own parse. So this runner does
# NOT reference game classes statically — it defers to the first process frame
# (autoloads are ready by then) and loads everything with load().
#
# Validates:
#   - level data fairness (jump reachability) for all campaign levels
#   - Endless Abyss room templates for depths 1..20
#   - sprite sheet frame math (sheet widths match expected frame counts)
#   - product catalog integrity (ids, grant fields)
#   - xp curve sanity
extends SceneTree

var _failed := 0


func _init() -> void:
	# First frame: autoload singletons are instantiated by now.
	process_frame.connect(_run_checks, CONNECT_ONE_SHOT)


func _run_checks() -> void:
	print("=== SHADOW LEGENDS headless checks ===")

	var level_defs: GDScript = load("res://scripts/levels/LevelDefs.gd")
	var endless_mode: GDScript = load("res://scripts/levels/EndlessMode.gd")
	var level_builder: GDScript = load("res://scripts/levels/LevelBuilder.gd")
	var game_db: GDScript = load("res://scripts/progression/GameDB.gd")

	# --- level fairness ---
	var defs := [
		level_defs.get_campaign(1, 1),
		level_defs.get_campaign(1, 2),
		level_defs.get_campaign(1, 3),
	]
	for d in defs:
		var issues: Array[String] = level_builder.validate(d)
		if issues.is_empty():
			print("OK  level %s reachable" % d["key"])
		else:
			for i in issues:
				printerr("FAIL %s: %s" % [d["key"], i])
				_failed += 1

	# --- endless rooms ---
	for depth in range(1, 21):
		var rd: Dictionary = endless_mode.room_def(depth)
		var issues: Array[String] = level_builder.validate(rd)
		if not issues.is_empty():
			for i in issues:
				printerr("FAIL abyss depth %d: %s" % [depth, i])
				_failed += 1
	print("OK  abyss rooms 1..20 validated")

	# --- sprite sheet math ---
	var sheets := {
		"res://assets/characters/ninja_sheet.png": 50,
		"res://assets/enemies/shadow_wolf_sheet.png": 24,
		"res://assets/enemies/dark_knight_sheet.png": 23,
		"res://assets/enemies/blood_archer_sheet.png": 22,
		"res://assets/enemies/abyss_mage_sheet.png": 16,
		"res://assets/enemies/shadow_assassin_sheet.png": 24,
		"res://assets/bosses/abyss_lord_sheet.png": 40,
	}
	for path in sheets.keys():
		var tex: Texture2D = load(path)
		var expect: int = sheets[path]
		var got := int(tex.get_width() / tex.get_height())
		if got != expect:
			printerr("FAIL sheet %s: %d frames, expected %d" % [path, got, expect])
			_failed += 1
	print("OK  sheet frame counts")

	# --- catalog ---
	for pid in game_db.SHOP_PRODUCT_ORDER:
		if not game_db.PRODUCTS.has(pid):
			printerr("FAIL catalog missing product " + str(pid))
			_failed += 1
		else:
			var def: Dictionary = game_db.PRODUCTS[pid]
			if not def.has("type") or not def.has("grant"):
				printerr("FAIL catalog malformed product " + str(pid))
				_failed += 1
	print("OK  product catalog (%d products)" % game_db.SHOP_PRODUCT_ORDER.size())

	# --- xp curve monotonic ---
	var prev := 0
	for lv in range(1, 41):
		var need := int(round(90.0 * pow(lv, 1.32)))
		if need <= prev:
			printerr("FAIL xp curve not monotonic at %d" % lv)
			_failed += 1
		prev = need
	print("OK  xp curve")

	if _failed == 0:
		print("=== ALL CHECKS PASSED ===")
		quit(0)
	else:
		printerr("=== %d FAILURES ===" % _failed)
		quit(1)
