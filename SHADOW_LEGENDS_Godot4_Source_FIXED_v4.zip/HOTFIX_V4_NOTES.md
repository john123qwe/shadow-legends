# SHADOW LEGENDS — source hotfix v4

Changes in this package:
- Scene transitions now remove the old victory / defeat / pause overlay, fixing the
  common case where the next stage remains hidden behind the previous result panel.
- Enemy melee hitboxes are mirrored to the direction the enemy is facing.
- Jump impulse increased to make the jump arc visibly higher; level reach-validator
  limits were updated with it.
- Background layers are brighter and the near-foreground foliage is less opaque.
- Added player arrow and shuriken projectiles, cooldowns, and two touch buttons.
  Keyboard test keys: U = bow, I = shuriken.

Important:
- This source has been edited, but it has NOT been compiled or run in Godot in this
  environment. Build a new APK with GitHub Actions and test on the target phone.
- Live Bazaar / Myket purchases are not verified by this hotfix.
