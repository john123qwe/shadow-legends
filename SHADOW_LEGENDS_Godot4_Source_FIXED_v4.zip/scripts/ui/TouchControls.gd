extends CanvasLayer
class_name TouchControls
## Landscape multi-touch controls: left virtual joystick, right action buttons
## (Jump / Attack / Dash / Special). Adjustable size from settings.
## Keyboard also works for desktop testing (actions mapped in project.godot).

var btn_tex := {}
var scale_mul := 1.0
var _sticks := {}          # touch index -> data {base_pos, knob_pos}
var _base: Control
var _knob: Control
var _held_actions := {}    # action -> touch index
var _queue_press := {}     # action -> true (one-frame edge)
var _root: Control
var _joy_center := Vector2.ZERO
var _joy_radius := 120.0


func _ready() -> void:
	add_to_group("touch_controls")
	layer = 10
	scale_mul = float(SaveSystem.get_setting("button_scale", 1.0))
	for n in ["jump", "attack", "dash", "special", "pause"]:
		btn_tex[n] = load("res://assets/ui/rbtn_%s.png" % n)
	btn_tex["bow"] = load("res://assets/effects/arrow.png")
	btn_tex["shuriken"] = load("res://assets/ui/icon_star_on.png")

	_root = Control.new()
	_root.set_anchors_preset(Control.PRESET_FULL_RECT)
	_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_root)

	_build_joystick()
	_build_buttons()


func _build_joystick() -> void:
	_base = Control.new()
	_base.custom_minimum_size = Vector2.ONE * 260 * scale_mul
	_base.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_base.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
	_base.position = Vector2(70, -320 * scale_mul)
	_base.modulate.a = 0.75
	_root.add_child(_base)

	var ring := TextureRect.new()
	ring.texture = load("res://assets/ui/rbtn_dash.png")  # ring look via round button tex
	ring.modulate = Color(0.4, 0.9, 0.9, 0.35)
	ring.custom_minimum_size = Vector2.ONE * 260 * scale_mul
	ring.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	ring.stretch_mode = TextureRect.STRETCH_SCALE
	ring.size = Vector2.ONE * 260 * scale_mul
	_base.add_child(ring)

	_knob = Control.new()
	_knob.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var kimg := TextureRect.new()
	kimg.texture = load("res://assets/ui/icon_coin.png")
	kimg.modulate = Color(0.5, 0.9, 0.9, 0.55)
	kimg.custom_minimum_size = Vector2.ONE * 96 * scale_mul
	kimg.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	kimg.stretch_mode = TextureRect.STRETCH_SCALE
	kimg.size = Vector2.ONE * 96 * scale_mul
	kimg.position = Vector2.ONE * (260 * scale_mul - 96 * scale_mul) / 2.0
	_knob.add_child(kimg)
	_base.add_child(_knob)
	_joy_center = _base.position + Vector2.ONE * 130 * scale_mul
	_joy_radius = 108.0 * scale_mul


func _build_buttons() -> void:
	# Each action is bound through a helper argument so every button keeps
	# its own action name (avoids loop-closure capture bugs on Android).
	_add_action_button("attack", Vector2(-250, -170), 180)
	_add_action_button("jump", Vector2(-420, -120), 150)
	_add_action_button("dash", Vector2(-330, -330), 120)
	_add_action_button("special", Vector2(-160, -350), 120)
	_add_action_button("bow", Vector2(-270, -440), 82)
	_add_action_button("shuriken", Vector2(-170, -440), 82)

	_add_action_button("pause", Vector2(-76, 20), 56, true)


func _add_action_button(action: String, off: Vector2, base_size: float, top_right := false) -> void:
	var b := TextureButton.new()
	b.name = action.capitalize()
	b.texture_normal = btn_tex[action]
	b.ignore_texture_size = true
	b.stretch_mode = TextureButton.STRETCH_SCALE
	var sz := base_size * scale_mul
	b.size = Vector2.ONE * sz
	b.modulate.a = 0.95
	b.mouse_filter = Control.MOUSE_FILTER_STOP
	b.pressed.connect(func(): _queue_press[action] = true)
	b.button_down.connect(func(): _held_actions[action] = true)
	b.button_up.connect(func(): _held_actions[action] = false)
	_root.add_child(b)
	_anchor_right(b, off, Vector2.ONE * sz, top_right)


func _anchor_right(c: Control, off: Vector2, size_v: Vector2, top_right := false) -> void:
	# Keep action buttons at bottom-right; pause stays at top-right.
	c.set_anchors_preset(Control.PRESET_TOP_LEFT)
	var vp := get_viewport().get_visible_rect().size
	c.position = Vector2(vp.x + off.x * scale_mul, off.y * scale_mul) if top_right else vp + off * scale_mul
	c.set_meta("off", off)
	c.set_meta("size_v", size_v)
	c.set_meta("top_right", top_right)


func _process(_delta: float) -> void:
	var vp := get_viewport().get_visible_rect().size
	# viewport-relative joystick placement (bottom-left)
	_base.position = Vector2(70, vp.y - 320.0 * scale_mul)
	_joy_center = _base.position + Vector2.ONE * 130 * scale_mul
	# reposition right-anchored buttons if viewport changed
	for c in _root.get_children():
		if c.has_meta("off"):
			var off: Vector2 = c.get_meta("off")
			if c.get_meta("top_right", false):
				c.position = Vector2(vp.x + off.x * scale_mul, off.y * scale_mul)
			else:
				c.position = Vector2(vp.x + off.x * scale_mul, vp.y + off.y * scale_mul)
	# knob visuals follow active stick
	if _sticks.is_empty():
		_knob.position = Vector2.ONE * (260 * scale_mul - 96 * scale_mul) / 2.0
	else:
		var d: Vector2 = _sticks.values()[0]["offset"]
		_knob.position = Vector2.ONE * (260 * scale_mul - 96 * scale_mul) / 2.0 + d.limit_length(_joy_radius)


# ----------------------------------------------------------------------------
# Multi-touch joystick: any touch starting on the left third controls movement.
# ----------------------------------------------------------------------------
func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed:
			if event.position.x < get_viewport().get_visible_rect().size.x * 0.42:
				_sticks[event.index] = {"origin": event.position, "offset": Vector2.ZERO}
		else:
			_sticks.erase(event.index)
	elif event is InputEventScreenDrag and _sticks.has(event.index):
		var off: Vector2 = event.position - _sticks[event.index]["origin"]
		_sticks[event.index]["offset"] = off


func axis() -> float:
	if _sticks.is_empty():
		return 0.0
	var off: Vector2 = _sticks.values()[0]["offset"]
	return clampf(off.x / _joy_radius, -1.0, 1.0)


func consume_press(action: String) -> bool:
	if _queue_press.get(action, false):
		_queue_press[action] = false
		return true
	return false


func is_held(action: String) -> bool:
	return _held_actions.get(action, false)


func consume_pause() -> bool:
	return consume_press("pause")
