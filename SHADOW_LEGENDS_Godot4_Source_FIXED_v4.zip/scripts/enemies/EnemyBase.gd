extends CharacterBody2D
class_name EnemyBase
## Shared enemy AI: patrol / chase / windup / attack / stunned / dead,
## hurt reactions, knockback, loot drops, difficulty scaling.

enum ST { PATROL, CHASE, WINDUP, ATTACK, RECOVER, STUN, DEAD }

signal died_signal

var kind := "shadow_wolf"
var display_name := ""
var max_hp := 60.0
var hp := 60.0
var damage := 12.0
var speed := 200.0
var gold_range := Vector2i(8, 16)
var xp_value := 14
var detect_range := 560.0
var attack_range := 96.0
var is_boss := false

var st: int = ST.PATROL
var facing := -1
var patrol_min_x := 0.0
var patrol_max_x := 0.0
var patrol_dir := -1
var _patrol_span := 240.0
var stun_t := 0.0
var windup_t := 0.0
var recover_t := 0.0
var player: Player
var sprite: AnimatedSprite2D
var attack_area: Area2D
var gravity := 2000.0
var _hit_done := false
var _spawn_scale := 1.0
var _anim_done_cb: String = ""

# animation name mapping (subclasses may override)
var anim_idle := "idle"
var anim_move := "run"
var anim_attack := "attack"
var anim_hurt := "hurt"
var anim_death := "death"


func configure(kind_id: String, scale_mult: float, patrol_span := 240.0) -> void:
	kind = kind_id
	_patrol_span = patrol_span
	var base: Dictionary = GameDB.ENEMY_STATS.get(kind_id, {})
	if base.is_empty():
		return  # bosses configure their own stats
	_spawn_scale = scale_mult
	max_hp = float(base["hp"]) * scale_mult
	hp = max_hp
	damage = float(base["damage"]) * scale_mult
	speed = float(base["speed"])
	gold_range = Vector2i(int(base["gold"][0] * scale_mult), int(base["gold"][1] * scale_mult))
	xp_value = int(base["xp"] * scale_mult)
	detect_range = float(base["detect"])
	attack_range = float(base["attack_range"])
	display_name = GameDB.LEVEL_NAMES.get(kind_id, {"fa": kind_id})["fa"] if GameDB.LEVEL_NAMES.has(kind_id) else kind_id


func _ready() -> void:
	collision_layer = Globals.L_ENEMY
	collision_mask = Globals.L_WORLD
	floor_snap_length = 8.0

	sprite = AnimatedSprite2D.new()
	sprite.sprite_frames = SpriteLib.enemy_sheet(kind)
	sprite.position = _sprite_offset()
	sprite.scale = _sprite_scale()
	sprite.animation_finished.connect(_on_anim_finished)
	add_child(sprite)

	var col := CollisionShape2D.new()
	var shape := RectangleShape2D.new()
	shape.size = _body_size()
	col.shape = shape
	col.position = Vector2(0, -shape.size.y / 2.0)
	add_child(col)

	# attack hitbox — player hurtbox is on L_PLAYER
	attack_area = Area2D.new()
	attack_area.collision_layer = 0
	attack_area.collision_mask = Globals.L_PLAYER
	attack_area.monitoring = false
	attack_area.set_meta("kind", "attack")
	attack_area.set_meta("owner", self)
	var ac := CollisionShape2D.new()
	var ash := RectangleShape2D.new()
	ash.size = _attack_size()
	ac.shape = ash
	ac.position = Vector2(_attack_offset().x, 0)
	attack_area.add_child(ac)
	add_child(attack_area)

	sprite.play(anim_idle)
	# patrol bounds anchored on spawn point
	patrol_min_x = global_position.x - _patrol_span
	patrol_max_x = global_position.x + _patrol_span


# --- hooks for subclasses --------------------------------------------------
func _sprite_offset() -> Vector2:
	return Vector2(0, -52)


func _sprite_scale() -> Vector2:
	return Vector2.ONE


func _body_size() -> Vector2:
	return Vector2(52, 96)


func _attack_size() -> Vector2:
	return Vector2(120, 90)


func _attack_offset() -> Vector2:
	return Vector2(66, -46)


func _windup_time() -> float:
	return 0.38


func _perform_attack() -> void:
	pass  # subclass melee/projectile logic; default: enable melee hitbox


func _attack_anim() -> String:
	return anim_attack


func ai_chase(delta: float) -> void:
	# default ground chase
	var dx := player.global_position.x - global_position.x
	velocity.x = move_toward(velocity.x, signf(dx) * speed, 900.0 * delta)


# ---------------------------------------------------------------------------
func _physics_process(delta: float) -> void:
	if st == ST.DEAD:
		velocity.y = minf(velocity.y + gravity * delta, 1500.0)
		velocity.x = move_toward(velocity.x, 0, 600.0 * delta)
		move_and_slide()
		return

	if player == null or not is_instance_valid(player) or player.st == Player.ST.DEAD:
		# idle down when player is gone/dead
		velocity.x = move_toward(velocity.x, 0, 800.0 * delta)
		_apply_gravity(delta)
		move_and_slide()
		_play(anim_idle)
		return

	if st == ST.STUN:
		stun_t -= delta
		velocity.x = move_toward(velocity.x, 0, 700.0 * delta)
		_apply_gravity(delta)
		move_and_slide()
		if stun_t <= 0.0:
			st = ST.CHASE
		return

	match st:
		ST.PATROL:
			_do_patrol(delta)
		ST.CHASE:
			_do_chase(delta)
		ST.WINDUP:
			_do_windup(delta)
		ST.ATTACK:
			_do_attack(delta)
		ST.RECOVER:
			recover_t -= delta
			velocity.x = move_toward(velocity.x, 0, 900.0 * delta)
			_apply_gravity(delta)
			move_and_slide()
			if recover_t <= 0.0:
				st = ST.CHASE

	move_and_slide()
	_update_visual()


func _apply_gravity(delta: float) -> void:
	velocity.y = minf(velocity.y + gravity * delta, 1500.0)


func _do_patrol(delta: float) -> void:
	_apply_gravity(delta)
	var dist := player.global_position.distance_to(global_position)
	if dist < detect_range:
		st = ST.CHASE
		return
	if patrol_max_x > patrol_min_x + 40.0:
		velocity.x = patrol_dir * speed * 0.4
		if global_position.x > patrol_max_x:
			patrol_dir = -1
		elif global_position.x < patrol_min_x:
			patrol_dir = 1
	else:
		velocity.x = 0
	_play(anim_move if absf(velocity.x) > 10 else anim_idle)


func _do_chase(delta: float) -> void:
	_apply_gravity(delta)
	var dist := player.global_position.distance_to(global_position)
	facing = 1 if player.global_position.x > global_position.x else -1
	if dist <= attack_range and _can_attack():
		st = ST.WINDUP
		windup_t = _windup_time()
		_hit_done = false
		_play(_attack_anim(), true)
		velocity.x = 0
		return
	ai_chase(delta)
	_play(anim_move)


func _can_attack() -> bool:
	return st == ST.CHASE


func _do_windup(delta: float) -> void:
	_apply_gravity(delta)
	velocity.x = move_toward(velocity.x, 0, 1200.0 * delta)
	facing = 1 if player.global_position.x > global_position.x else -1
	_face_attack_area()
	windup_t -= delta
	if windup_t <= 0.0:
		st = ST.ATTACK
		_perform_attack()


func _face_attack_area() -> void:
	# The hitbox was originally created on the right side only. Mirror its
	# local X offset when facing left so melee enemies can hit from both sides.
	if is_instance_valid(attack_area) and attack_area.get_child_count() > 0:
		var hit_shape := attack_area.get_child(0) as CollisionShape2D
		if hit_shape:
			hit_shape.position.x = absf(hit_shape.position.x) * float(facing)


func _do_attack(delta: float) -> void:
	_apply_gravity(delta)
	# movement during attack is subclass-driven (lunge etc.)


func _on_anim_finished() -> void:
	if st == ST.DEAD:
		return
	if sprite.animation == _attack_anim() or sprite.animation in ["shoot", "cast", "slam", "charge"]:
		attack_area.set_deferred("monitoring", false)
		recover_t = 0.5
		st = ST.RECOVER


func _update_visual() -> void:
	if sprite.animation in [_attack_anim(), "shoot", "cast", "slam", "charge", anim_hurt, anim_death]:
		sprite.flip_h = facing < 0
		return
	sprite.flip_h = facing < 0


func _play(anim: String, restart := false) -> void:
	if sprite.animation != anim or restart:
		sprite.play(anim)


# ---------------------------------------------------------------------------

func is_dead() -> bool:
	return st == ST.DEAD


func hurt(dmg: float, knockback: Vector2, crit: bool) -> void:
	if st == ST.DEAD:
		return
	hp -= dmg
	Vfx.impact(get_parent(), global_position + Vector2(0, -60), crit)
	Vfx.damage_number(get_parent(), global_position + Vector2(0, -110), int(round(dmg)), crit,
		Color(1.0, 0.9, 0.45) if crit else Color(1.0, 0.75, 0.7))
	AudioManager.sfx("hit_crit" if crit else "hit_1")
	sprite.modulate = Color(3.0, 1.2, 1.2)
	get_tree().create_timer(0.08).timeout.connect(func():
		if is_instance_valid(sprite):
			sprite.modulate = Color.WHITE)
	if hp <= 0.0:
		_die()
		return
	if is_boss:
		EventBus.boss_health_changed.emit(hp, max_hp)
		return
	st = ST.STUN
	stun_t = 0.3
	velocity = knockback
	if absf(velocity.x) > 10:
		facing = 1 if velocity.x > 0 else -1


func _die() -> void:
	if st == ST.DEAD:
		return
	st = ST.DEAD
	velocity = Vector2.ZERO
	collision_layer = 0
	attack_area.set_deferred("monitoring", false)
	_play(anim_death, true)
	AudioManager.sfx("enemy_death")
	EventBus.enemy_killed.emit(kind, global_position)
	_drop_loot()
	if is_boss:
		EventBus.boss_defeated.emit(kind)
	var tw := create_tween()
	tw.tween_interval(0.9)
	tw.tween_property(sprite, "modulate:a", 0.0, 0.6)
	tw.parallel().tween_property(sprite, "modulate", Color(0.6, 0.1, 0.15, 0.0), 0.6)
	tw.tween_callback(queue_free)
	died_signal.emit()


func _drop_loot() -> void:
	var n_coins := randi_range(2, 4)
	var gold_total := randi_range(gold_range.x, gold_range.y)
	for i in range(n_coins):
		Coin.spawn(get_parent(), global_position + Vector2(0, -60),
			gold_total / float(n_coins))
	XpOrb.spawn(get_parent(), global_position + Vector2(0, -70), xp_value)
	# item drop ~7%
	if randf() < 0.07:
		var pool := ["potion_health", "ring_fleet", "katana_crimson", "armor_nightweave", "ring_blood"]
		var iid: String = pool[randi() % pool.size()]
		var rarity := "common" if iid == "potion_health" else GameDB.roll_rarity(0.0)
		SaveSystem.add_item(iid, rarity)
		Vfx.shadow_puff(get_parent(), global_position)
