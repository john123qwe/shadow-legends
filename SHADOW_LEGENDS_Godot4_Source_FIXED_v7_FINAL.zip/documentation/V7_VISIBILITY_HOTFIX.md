# SHADOW LEGENDS v7 — visibility and mobile-control hotfix

Changes based on the v6 device screenshot:
- Parallax background is assigned its own lower CanvasLayer (`-10`) so it cannot cover gameplay.
- Player and animated ninja sprite receive an explicit foreground draw order.
- HUD and touch controls are moved to higher CanvasLayer values (`21` and `20`).
- Touch UI root fills the viewport using anchors and offsets.
- Action buttons are anchored to the bottom-right edge instead of being positioned using a fixed viewport-size calculation.
- Joystick and action buttons are raised to avoid being clipped at the bottom of tall/wide Android displays.

This is a source-level hotfix. It still requires a fresh Android build and on-device verification.
