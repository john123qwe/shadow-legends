# SHADOW LEGENDS v6 — Art update

- Added `assets/backgrounds/forest_moonlit.png`, a new moonlit teal forest / crimson foliage background for World 1.
- World 1 now uses the new artwork as its distant parallax layer while preserving the existing midground and fog layers. Other worlds retain their original backgrounds.
- Increased the existing animated ninja sprite scale from 1.05 to 1.24 and applied a restrained crimson rim shader. The existing animation sheet and animation names are preserved.

This is an art integration update, not a claim that a new character animation sheet was created. Please run the GitHub Actions Android build and test the APK on-device before treating it as verified.
