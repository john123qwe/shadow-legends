shader_type canvas_item;

uniform vec4 rim_color : source_color = vec4(1.0, 0.10, 0.16, 0.92);
uniform float rim_width = 1.35;

void fragment() {
    vec4 texel = texture(TEXTURE, UV);
    float a = texel.a;
    vec2 px = TEXTURE_PIXEL_SIZE * rim_width;
    float around = 0.0;
    around = max(around, texture(TEXTURE, UV + vec2(px.x, 0.0)).a);
    around = max(around, texture(TEXTURE, UV - vec2(px.x, 0.0)).a);
    around = max(around, texture(TEXTURE, UV + vec2(0.0, px.y)).a);
    around = max(around, texture(TEXTURE, UV - vec2(0.0, px.y)).a);
    float edge = (1.0 - step(0.1, a)) * step(0.1, around);
    vec4 base = texel * COLOR;
    COLOR = mix(base, rim_color * COLOR, edge * 0.72);
}
