shader_type canvas_item;

uniform vec4 rim_color : source_color = vec4(1.0, 0.08, 0.16, 1.0);
uniform float rim_width = 1.8;
uniform float body_lift = 0.62;

void fragment() {
    vec4 texel = texture(TEXTURE, UV);
    float a = texel.a;
    vec2 px = TEXTURE_PIXEL_SIZE * rim_width;

    float around = 0.0;
    around = max(around, texture(TEXTURE, UV + vec2(px.x, 0.0)).a);
    around = max(around, texture(TEXTURE, UV - vec2(px.x, 0.0)).a);
    around = max(around, texture(TEXTURE, UV + vec2(0.0, px.y)).a);
    around = max(around, texture(TEXTURE, UV - vec2(0.0, px.y)).a);

    float edge = (1.0 - step(0.1, a)) * step(0.1, around);

    // The original ninja sheet is intentionally very dark. Lift its opaque
    // pixels with a cool steel-blue tint so the silhouette remains readable
    // against the new night scenery while retaining the original red details.
    vec3 lifted = mix(texel.rgb, vec3(0.30, 0.36, 0.48), body_lift);
    vec4 base = vec4(lifted, a) * COLOR;
    vec4 rim = rim_color * COLOR;
    COLOR = mix(base, rim, edge * 0.92);
}
