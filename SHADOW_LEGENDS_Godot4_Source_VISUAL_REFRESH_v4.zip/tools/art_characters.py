"""SHADOW LEGENDS — characters: Shadow Ninja, 5 enemies, Abyss Lord boss.
Pose-driven silhouette sprite sheets. All frames face RIGHT; Godot flips via flip_h.
Sheets are horizontal strips: assets/characters/*.png, assets/enemies/*.png, assets/bosses/*.png
"""
import math

from PIL import Image, ImageDraw

from art_lib import PAL, add_glow, canvas, rng, save

BODY = PAL["body"] + (255,)
DARK = (2, 4, 5, 255)
BLADE = PAL["blade"] + (255,)
EDGE = PAL["blade_edge"] + (255,)
RED = PAL["red"] + (255,)
REDHOT = PAL["red_hot"] + (255,)
TAU = math.tau


# ----------------------------------------------------------------------------
# generic pieces
# ----------------------------------------------------------------------------
def limb(d, p0, a1, l1, a2, l2, w1, w2, col):
    x0, y0 = p0
    jx = x0 + math.sin(math.radians(a1)) * l1
    jy = y0 + math.cos(math.radians(a1)) * l1
    tx = jx + math.sin(math.radians(a2)) * l2
    ty = jy + math.cos(math.radians(a2)) * l2
    d.line([x0, y0, jx, jy], fill=col, width=w1)
    d.line([jx, jy, tx, ty], fill=col, width=w2)
    for px, py, r in ((x0, y0, w1 / 2), (jx, jy, w2 / 2), (tx, ty, w2 / 2)):
        d.ellipse([px - r, py - r, px + r, py + r], fill=col)
    return (tx, ty)


def draw_katana(d, hx, hy, ang, ln=44, col=BLADE, edge=EDGE, tassel=True):
    """Katana from hand at angle ang (deg, 0 = horizontal forward, + = down)."""
    a = math.radians(ang)
    # handle behind hand
    hbx = hx - math.cos(a) * 12
    hby = hy - math.sin(a) * 12
    d.line([hbx, hby, hx, hy], fill=DARK, width=6)
    if tassel:
        d.line([hbx, hby, hbx - 3, hby + 6], fill=RED, width=3)
    # guard
    gx = hx + math.cos(a) * 3
    gy = hy + math.sin(a) * 3
    d.line([gx - math.sin(a) * 5, gy + math.cos(a) * 5,
            gx + math.sin(a) * 5, gy - math.cos(a) * 5], fill=DARK, width=4)
    # blade with light edge
    bx = hx + math.cos(a) * ln
    by = hy + math.sin(a) * ln
    d.line([gx, gy, bx, by], fill=col, width=5)
    d.line([gx + math.sin(a) * 1.5, gy - math.cos(a) * 1.5,
            bx + math.sin(a) * 1.5, by - math.cos(a) * 1.5], fill=edge, width=2)
    # tip
    d.ellipse([bx - 2, by - 2, bx + 2, by + 2], fill=col)


def draw_eyes_glow(img, hx, hy, r=11, forward=1):
    add_glow(img, lambda dd, c: dd.ellipse([hx - 2, hy - 3, hx + 5, hy + 1], fill=c),
             REDHOT, 4, 1.0)
    d = ImageDraw.Draw(img)
    d.ellipse([hx - 1, hy - 3, hx + 4, hy + 1], fill=RED)


# ----------------------------------------------------------------------------
# SHADOW NINJA — 128x128 frames, feet ~y=120
# ----------------------------------------------------------------------------
def ninja_frame(pose):
    img = canvas(128, 128)
    d = ImageDraw.Draw(img)
    cx = pose.get("cx", 62)
    hip_y = 84 + pose.get("bob", 0)
    sho_y = 56 + pose.get("bob", 0)
    lean = pose.get("lean", 0)  # + forward
    sho_x = cx + lean * 0.35
    head_x = sho_x + lean * 0.30 + 2
    head_y = sho_y - 12
    # cloak (behind everything)
    sway = pose.get("sway", 0.0)   # -1 trails back, +1 forward
    lift = pose.get("lift", 0.0)
    w1 = pose.get("wave", 0.0)
    cl = [
        (sho_x - 6, sho_y - 8 - lift * 6),
        (sho_x - 10 - sway * 10 + w1 * 2, sho_y + 8 - lift * 10),
        (sho_x - 8 - sway * 16 + w1 * 4, sho_y + 30 - lift * 16),
        (sho_x - 14 - sway * 12 + w1 * 6, hip_y + 8 - lift * 22),
        (sho_x + 2 + sway * 4, hip_y + 2 - lift * 6),
        (sho_x + 9, sho_y + 6),
    ]
    d.polygon(cl, fill=BODY)
    # back leg
    lB = pose.get("legB", (0, 0))
    limb(d, (cx - 4, hip_y), lB[0], 18, lB[1], 17, 8, 6, BODY)
    # back arm (mostly hidden)
    aB = pose.get("armB", (8, 12))
    limb(d, (sho_x - 4, sho_y + 4), aB[0], 13, aB[1], 12, 7, 5, DARK)
    # torso
    d.polygon([(sho_x - 9, sho_y - 4), (sho_x + 9, sho_y - 4),
               (cx + 7, hip_y + 2), (cx - 7, hip_y + 2)], fill=BODY)
    # front leg
    lF = pose.get("legF", (0, 0))
    limb(d, (cx + 4, hip_y), lF[0], 19, lF[1], 18, 8, 6, BODY)
    # scarf tails
    s1 = pose.get("scarf", 0.0)
    d.line([sho_x + 4, sho_y - 4, sho_x - 10 + s1 * 4, sho_y - 14 + s1 * 3], fill=RED, width=6)
    d.line([sho_x + 4, sho_y - 4, sho_x - 16 + s1 * 6, sho_y - 8 + s1 * 5], fill=RED, width=5)
    # head
    d.ellipse([head_x - 10, head_y - 10, head_x + 10, head_y + 10], fill=BODY)
    d.polygon([(head_x - 8, head_y - 6), (head_x + 6, head_y - 10), (head_x - 2, head_y - 14)],
              fill=BODY)  # hood point
    # eyes
    draw_eyes_glow(img, head_x + 3, head_y - 1)
    # front arm + katana
    aF = pose.get("armF", (20, 15))
    hand = limb(d, (sho_x + 5, sho_y + 5), aF[0], 14, aF[1], 13, 7, 5, BODY)
    if pose.get("kat", True):
        draw_katana(d, hand[0], hand[1], pose.get("kat_ang", 0), pose.get("kat_len", 44))
    return img


def pose_run(t):
    s = math.sin(TAU * t)
    c = math.cos(TAU * t)
    return dict(
        cx=62, bob=-2 + 2.5 * abs(s),
        lean=10,
        legF=(42 * s - 8, 30 + 22 * c),
        legB=(42 * s + 172, -30 - 22 * c),
        armF=(-28 * s, 30), armB=(20 * s, 25),
        sway=-0.9, lift=0.0, wave=s * 2, scarf=-1.2 + s * 0.5,
        kat_ang=-18 + 8 * s, kat=True,
    )


def ninja_sheet():
    frames = []
    # idle 4 — breathing + cloak ripple
    for i in range(4):
        t = i / 4.0
        s = math.sin(TAU * t)
        frames.append(ninja_frame(dict(cx=62, bob=s * 2, lean=2,
                                       legF=(6, -6), legB=(-6, 8),
                                       armF=(14, 18), armB=(10, 14),
                                       sway=0.15 * s, wave=s * 3, scarf=s,
                                       kat_ang=-24 + 4 * s)))
    # run 8
    for i in range(8):
        frames.append(ninja_frame(pose_run(i / 8.0)))
    # jump 2
    frames.append(ninja_frame(dict(cx=62, bob=0, lean=8, legF=(38, -58), legB=(-24, -44),
                                   armF=(-30, 40), armB=(-10, 30), sway=-0.5, lift=0.6,
                                   wave=0, scarf=-1.6, kat_ang=-30)))
    frames.append(ninja_frame(dict(cx=62, bob=0, lean=14, legF=(52, -30), legB=(-30, -60),
                                   armF=(10, 30), armB=(-20, 20), sway=-0.7, lift=0.4,
                                   wave=0, scarf=-1.8, kat_ang=-36)))
    # fall 2
    frames.append(ninja_frame(dict(cx=62, bob=0, lean=6, legF=(18, -18), legB=(-14, -8),
                                   armF=(-40, 20), armB=(-36, 16), sway=-0.4, lift=0.9,
                                   wave=1, scarf=-2.0, kat_ang=-12)))
    frames.append(ninja_frame(dict(cx=62, bob=0, lean=10, legF=(24, -10), legB=(-20, -4),
                                   armF=(-30, 24), armB=(-28, 20), sway=-0.5, lift=0.7,
                                   wave=-1, scarf=-1.8, kat_ang=-8)))
    # attack1 4 (horizontal cut, raised->forward)
    for i, ka in enumerate((-80, -40, 14, 6)):
        ext = (i == 2)
        frames.append(ninja_frame(dict(cx=60 + ext * 6, bob=0, lean=6 + i * 5,
                                       legF=(16 + i * 8, -14 + i * 6), legB=(-18, 14),
                                       armF=(-46 + i * 30, 12 + i * 6), armB=(-30 + i * 10, 20),
                                       sway=-0.6 + i * 0.3, wave=i, scarf=-1.0 + i * 0.4,
                                       kat_ang=ka, kat_len=48)))
    # attack2 4 (reverse cut, low->up)
    for i, ka in enumerate((30, 8, -50, -86)):
        frames.append(ninja_frame(dict(cx=62 + (i == 1) * 6, bob=2 * (i == 0), lean=8 - i * 4,
                                       legF=(20 - i * 6, -10), legB=(-14, 12),
                                       armF=(10 + i * -20, 10 + i * -4), armB=(-16, 18),
                                       sway=-0.5 + i * 0.4, wave=i * 1.5, scarf=-1.0 + i * 0.6,
                                       kat_ang=ka, kat_len=48)))
    # attack3 5 (spin slash)
    for i in range(5):
        ka = -150 + i * 90
        cr = 6 if i in (0, 1) else 0
        frames.append(ninja_frame(dict(cx=62, bob=cr, lean=18 - i * 6,
                                       legF=(30 - i * 10, -20 + i * 8), legB=(-26 + i * 10, 16),
                                       armF=(-70 + i * 40, 8 + i * 8), armB=(-50 + i * 24, 16),
                                       sway=-0.8 + i * 0.35, lift=0.3 if i in (0, 1) else 0.0,
                                       wave=i * 2, scarf=-1.4 + i * 0.5,
                                       kat_ang=ka, kat_len=50)))
    # dash 3
    for i in range(3):
        frames.append(ninja_frame(dict(cx=56, bob=4, lean=34, legF=(-58, -12), legB=(-70, -6),
                                       armF=(64, 6), armB=(58, 4), sway=-1.0, lift=0.15,
                                       wave=0, scarf=-2.2, kat_ang=20, kat_len=44)))
    # special 6 (raise kat, charge, burst)
    for i in range(6):
        s = i / 5.0
        frames.append(ninja_frame(dict(cx=62, bob=-4 * (1 - s), lean=-6 + s * 14,
                                       legF=(26 - s * 12, -24 + s * 10), legB=(-20 + s * 6, 12),
                                       armF=(-90 + s * 60, 6 + s * 10), armB=(-60 + s * 40, 14),
                                       sway=-0.3 + s * 0.6, lift=0.5 - s * 0.5, wave=s * 3,
                                       scarf=-2.0 + s * 1.2, kat_ang=-96 + s * 120, kat_len=50)))
    # hurt 2
    frames.append(ninja_frame(dict(cx=64, bob=-2, lean=-18, legF=(-6, -20), legB=(-30, 6),
                                   armF=(-60, -30), armB=(-54, -24), sway=0.5, lift=0.2,
                                   wave=-2, scarf=1.6, kat_ang=40, kat=True)))
    frames.append(ninja_frame(dict(cx=64, bob=2, lean=-12, legF=(0, -14), legB=(-24, 8),
                                   armF=(-48, -18), armB=(-42, -14), sway=0.3, lift=0.1,
                                   wave=2, scarf=1.2, kat_ang=30, kat=True)))
    # death 6 (kneel -> collapse)
    for i in range(6):
        t = i / 5.0
        frames.append(ninja_frame(dict(cx=64, bob=t * 30, lean=-14 + t * 30,
                                       legF=(40 + t * 30, -70 + t * 40), legB=(-10 - t * 20, 30 + t * 30),
                                       armF=(-30 - t * 40, 30 + t * 40), armB=(-20 - t * 30, 24 + t * 30),
                                       sway=-0.2, lift=0.2 - t * 0.2, wave=t * 3, scarf=-1.0 + t * 2.0,
                                       kat_ang=60 + t * 24, kat=(i < 5), kat_len=40)))
    # victory 4
    for i in range(4):
        s = math.sin(TAU * i / 4.0)
        frames.append(ninja_frame(dict(cx=62, bob=s * 3, lean=-4, legF=(4, -8), legB=(-8, 10),
                                       armF=(-96, -8), armB=(-70, -6), sway=0.1 * s, wave=s,
                                       scarf=0.6 * s, kat_ang=-98, kat_len=50)))
    names = [("idle", 4, 6.0, True), ("run", 8, 13.0, True), ("jump", 2, 8.0, False),
             ("fall", 2, 8.0, True), ("attack1", 4, 16.0, False), ("attack2", 4, 16.0, False),
             ("attack3", 5, 15.0, False), ("dash", 3, 12.0, False), ("special", 6, 12.0, False),
             ("hurt", 2, 10.0, False), ("death", 6, 9.0, False), ("victory", 4, 6.0, True)]
    counts = [n for _, n, _, _ in names]
    assert len(frames) == sum(counts), f"ninja frames {len(frames)} != {sum(counts)}"
    sheet = Image.new("RGBA", (128 * len(frames), 128))
    for i, f in enumerate(frames):
        sheet.alpha_composite(f, (i * 128, 0))
    save(sheet, "characters", "ninja_sheet.png")
    meta = {nm: {"start": sum(counts[:k]), "count": n, "fps": fps, "loop": loop}
            for k, (nm, n, fps, loop) in enumerate(names)}
    return meta


# ----------------------------------------------------------------------------
# Generic humanoid enemy builder
# ----------------------------------------------------------------------------
def enemy_frame_128(cfg, pose):
    img = canvas(128, 128)
    d = ImageDraw.Draw(img)
    col = BODY
    cx = cfg.get("cx", 64)
    hip_y = 88 + pose.get("bob", 0)
    sho_y = 58 + pose.get("bob", 0)
    lean = pose.get("lean", 0)
    sho_x = cx + lean * 0.35
    head_x = sho_x + 2 + lean * 0.3
    head_y = sho_y - 11
    bulk = cfg.get("bulk", 1.0)
    # cape / robe behind
    if cfg.get("robe"):
        d.polygon([(sho_x - 12 * bulk, sho_y - 4), (sho_x + 12 * bulk, sho_y - 4),
                   (cx + 20, hip_y + 26), (cx - 20, hip_y + 26)], fill=col)
    if cfg.get("cape"):
        sway = pose.get("sway", -0.4)
        d.polygon([(sho_x - 8, sho_y - 6), (sho_x + 4, sho_y - 6),
                   (sho_x - 10 + sway * 14, sho_y + 30), (sho_x - 20 + sway * 20, sho_y + 44)],
                  fill=col)
    # legs
    if not cfg.get("float"):
        lB = pose.get("legB", (0, 0))
        limb(d, (cx - 5 * bulk, hip_y), lB[0], 17, lB[1], 16, int(9 * bulk), 7, col)
        lF = pose.get("legF", (0, 0))
        limb(d, (cx + 5 * bulk, hip_y), lF[0], 18, lF[1], 17, int(9 * bulk), 7, col)
    # back arm
    aB = pose.get("armB", (10, 12))
    limb(d, (sho_x - 6 * bulk, sho_y + 5), aB[0], 13, aB[1], 12, int(7 * bulk), 5, DARK)
    # torso
    d.polygon([(sho_x - 11 * bulk, sho_y - 5), (sho_x + 11 * bulk, sho_y - 5),
               (cx + 8 * bulk, hip_y + 3), (cx - 8 * bulk, hip_y + 3)], fill=col)
    # head + helm/hood
    hr = cfg.get("head_r", 10)
    d.ellipse([head_x - hr, head_y - hr, head_x + hr, head_y + hr], fill=col)
    if cfg.get("horns"):
        for s in (-1, 1):
            bx = head_x + s * 4
            d.polygon([(bx, head_y - 6), (bx + s * 14, head_y - 20), (bx + s * 6, head_y - 2)], fill=col)
    if cfg.get("hood"):
        d.polygon([(head_x - hr - 2, head_y - 4), (head_x + hr + 2, head_y - 4),
                   (head_x, head_y - hr - 8)], fill=col)
    # eyes
    ex, ey = head_x + 3, head_y - 1
    eye_c = cfg.get("eye_color", PAL["red_hot"])
    add_glow(img, lambda dd, c: dd.ellipse([ex - 2, ey - 3, ex + 5, ey + 1], fill=c),
             eye_c + (255,), 4, 1.0)
    d2 = ImageDraw.Draw(img)
    d2.ellipse([ex - 1, ey - 3, ex + 4, ey + 1], fill=PAL["red"] + (255,))
    # weapon
    wep = cfg.get("wep")
    aF = pose.get("armF", (20, 15))
    hand = limb(d, (sho_x + 6 * bulk, sho_y + 5), aF[0], 14, aF[1], 12, int(7 * bulk), 5, col)
    if wep == "greatsword":
        draw_katana(d, hand[0], hand[1], pose.get("kat_ang", 10), 56, BLADE, EDGE, False)
        d = ImageDraw.Draw(img)
        hx, hy = hand
        a = math.radians(pose.get("kat_ang", 10))
        d.line([hx - math.sin(a) * 3, hy + math.cos(a) * 3,
                hx + math.sin(a) * 3, hy - math.cos(a) * 3], fill=DARK, width=7)
    elif wep == "bow":
        a = math.radians(pose.get("bow_ang", 0))
        bx, by = hand[0] + 6, hand[1]
        d.arc([bx - 16, by - 18, bx + 16, by + 18], 250, 90, fill=DARK, width=4)
        # string
        d.line([bx + 6, by - 17, bx + 6, by + 17], fill=(150, 160, 160, 200), width=2)
        if pose.get("arrow"):
            d.line([bx - 10, by, bx + 24, by], fill=(170, 60, 60, 255), width=3)
            d.polygon([(bx + 24, by - 3), (bx + 30, by), (bx + 24, by + 3)], fill=RED)
    elif wep == "staff":
        a = math.radians(pose.get("staff_ang", -14))
        sx, sy = hand
        tipx = sx + math.cos(a) * 44
        tipy = sy + math.sin(a) * 44
        d.line([sx - math.cos(a) * 20, sy - math.sin(a) * 20, tipx, tipy], fill=col, width=6)
        add_glow(img, lambda dd, c: dd.ellipse([tipx - 9, tipy - 9, tipx + 9, tipy + 9], fill=c),
                 eye_c + (255,), 10, 1.0)
        d2 = ImageDraw.Draw(img)
        d2.ellipse([tipx - 6, tipy - 6, tipx + 6, tipy + 6], fill=eye_c + (255,))
    elif wep == "daggers":
        for aa in (pose.get("dag1", 20), pose.get("dag2", 40)):
            draw_katana(d, hand[0], hand[1], aa, 22, BLADE, EDGE, False)
            d = ImageDraw.Draw(img)
    return img


def std_walk(t, cx=64):
    s = math.sin(TAU * t)
    c = math.cos(TAU * t)
    return dict(bob=-1 + 2 * abs(s), lean=6,
                legF=(36 * s - 6, 26 + 18 * c), legB=(36 * s + 174, -26 - 18 * c),
                armF=(-20 * s + 6, 20), armB=(16 * s, 18), sway=-0.4, wave=s)


# ----------------------------------------------------------------------------
# Enemy sheets
# ----------------------------------------------------------------------------
def gen_enemies():
    metas = {}

    def strip(frames, path):
        sheet = Image.new("RGBA", (128 * len(frames), 128))
        for i, f in enumerate(frames):
            sheet.alpha_composite(f, (i * 128, 0))
        save(sheet, "enemies", path)

    # --- Dark Knight ---
    cfg = dict(wep="greatsword", horns=True, bulk=1.25, head_r=11, cape=True)
    frames = []
    for i in range(4):
        s = math.sin(TAU * i / 4)
        frames.append(enemy_frame_128(cfg, dict(bob=s * 2, legF=(6, -6), legB=(-6, 8),
                                                armF=(24, 18), armB=(12, 14), kat_ang=16 + 4 * s)))
    for i in range(6):
        frames.append(enemy_frame_128(cfg, std_walk(i / 6.0, cx=62)))
    for i, ka in enumerate((60, 95, 30, -10, 20)):  # overhead slam
        frames.append(enemy_frame_128(cfg, dict(lean=10 + i * 4 - (18 if i == 3 else 0),
                                                legF=(26 - i * 6, -16 + i * 8), legB=(-18, 14),
                                                armF=(30 - i * 16, 10 + i * 6), armB=(20, 16),
                                                kat_ang=ka, sway=-0.4 + i * 0.2, wave=i)))
    for i in range(2):
        frames.append(enemy_frame_128(cfg, dict(lean=-14, legF=(-8, -16), legB=(-24, 8),
                                                armF=(-30, -20), armB=(-24, -16), kat_ang=44,
                                                sway=0.5, wave=-2)))
    for i in range(6):
        t = i / 5.0
        frames.append(enemy_frame_128(cfg, dict(bob=t * 34, lean=-10 + t * 40,
                                                legF=(30 + t * 40, -60 + t * 50), legB=(-16 - t * 20, 24 + t * 30),
                                                armF=(-20 - t * 40, 20 + t * 50), kat_ang=40 + t * 30,
                                                sway=0.2, wave=t * 3, kat=(i < 5))))
    metas["dark_knight"] = dict(anim="idle|walk|attack|hurt|death", counts=[4, 6, 5, 2, 6])
    strip(frames, "dark_knight_sheet.png")

    # --- Blood Archer ---
    cfg = dict(wep="bow", hood=True, bulk=0.9, cape=True)
    frames = []
    for i in range(4):
        s = math.sin(TAU * i / 4)
        frames.append(enemy_frame_128(cfg, dict(bob=s * 2, legF=(4, -6), legB=(-4, 8),
                                                armF=(30, 14), armB=(12, 14), bow_ang=0)))
    for i in range(6):
        frames.append(enemy_frame_128(cfg, std_walk(i / 6.0)))
    for i, pull in enumerate((0, 0.5, 1.0, 0.2)):
        frames.append(enemy_frame_128(cfg, dict(lean=4 + pull * 4, legF=(10, -10), legB=(-12, 10),
                                                armF=(34, 6 - pull * 4), armB=(20 + pull * 22, 8),
                                                bow_ang=0, arrow=(i >= 2), sway=-0.3 - pull * 0.3)))
    for i in range(2):
        frames.append(enemy_frame_128(cfg, dict(lean=-12, legF=(-6, -14), legB=(-20, 8),
                                                armF=(-24, -16), armB=(-20, -12), bow_ang=-30,
                                                sway=0.5, wave=-2)))
    for i in range(6):
        t = i / 5.0
        frames.append(enemy_frame_128(cfg, dict(bob=t * 30, lean=-8 + t * 36,
                                                legF=(26 + t * 36, -54 + t * 46), legB=(-14 - t * 18, 22 + t * 28),
                                                armF=(-18 - t * 36, 16 + t * 44), bow_ang=-20 + t * 30,
                                                sway=0.2, wave=t * 3)))
    metas["blood_archer"] = dict(anim="idle|walk|shoot|hurt|death", counts=[4, 6, 4, 2, 6])
    strip(frames, "blood_archer_sheet.png")

    # --- Abyss Mage (floating) ---
    cfg = dict(wep="staff", hood=True, robe=True, float=True, bulk=0.95)
    frames = []
    for i in range(4):
        s = math.sin(TAU * i / 4)
        frames.append(enemy_frame_128(cfg, dict(bob=s * 4, armF=(26, 16), staff_ang=-12 + s * 4, sway=0.1 * s)))
    for i, a in enumerate((-40, -20, 0, -30)):
        frames.append(enemy_frame_128(cfg, dict(bob=2, lean=6 + i * 3, armF=(40 - i * 10, 20 - i * 6),
                                                staff_ang=a, sway=-0.2 + i * 0.15, wave=i)))
    for i in range(2):
        frames.append(enemy_frame_128(cfg, dict(lean=-14, armF=(-30, -20), staff_ang=30, sway=0.6, wave=-2)))
    for i in range(6):
        t = i / 5.0
        frames.append(enemy_frame_128(cfg, dict(bob=2 + t * 6, lean=-10 + t * 20, armF=(-20 - t * 40, 10 + t * 30),
                                                staff_ang=20 + t * 40, sway=0.3, wave=t * 4)))
    metas["abyss_mage"] = dict(anim="idle|cast|hurt|death", counts=[4, 4, 2, 6])
    strip(frames, "abyss_mage_sheet.png")

    # --- Shadow Assassin ---
    cfg = dict(wep="daggers", hood=True, bulk=0.85, head_r=9)
    frames = []
    for i in range(4):
        s = math.sin(TAU * i / 4)
        frames.append(enemy_frame_128(cfg, dict(bob=s * 2, lean=4, legF=(4, -8), legB=(-6, 8),
                                                armF=(16, 24), armB=(8, 18), dag1=24 + s * 6, dag2=44 + s * 6)))
    for i in range(8):
        s = math.sin(TAU * i / 8)
        frames.append(enemy_frame_128(cfg, dict(bob=-1 + 2 * abs(s), lean=12,
                                                legF=(44 * s - 4, 28 + 20 * math.cos(TAU * i / 8)),
                                                legB=(44 * s + 176, -28 - 20 * math.cos(TAU * i / 8)),
                                                armF=(-20 * s, 24), armB=(14 * s, 20),
                                                dag1=20 - 14 * s, dag2=40 - 14 * s, sway=-0.7, wave=s)))
    for i, (d1, d2) in enumerate(((-60, -30), (10, 30), (60, 84), (30, 50))):
        frames.append(enemy_frame_128(cfg, dict(lean=16 + i * 4, legF=(30 - i * 8, -18 + i * 8),
                                                legB=(-20, 14), armF=(d1, 10), armB=(d2, 10),
                                                dag1=d1, dag2=d2, sway=-0.5 + i * 0.3, wave=i)))
    for i in range(2):
        frames.append(enemy_frame_128(cfg, dict(lean=-16, legF=(-6, -16), legB=(-22, 8),
                                                armF=(-30, -22), armB=(-26, -18), dag1=-40, dag2=-20,
                                                sway=0.6, wave=-2)))
    for i in range(6):
        t = i / 5.0
        frames.append(enemy_frame_128(cfg, dict(bob=t * 30, lean=-12 + t * 40,
                                                legF=(28 + t * 38, -56 + t * 48), legB=(-16 - t * 18, 22 + t * 28),
                                                armF=(-24 - t * 40, 10 + t * 44), dag1=-40 + t * 60, dag2=-10 + t * 50,
                                                sway=0.2, wave=t * 3)))
    metas["shadow_assassin"] = dict(anim="idle|run|attack|hurt|death", counts=[4, 8, 4, 2, 6])
    strip(frames, "shadow_assassin_sheet.png")

    return metas


# ----------------------------------------------------------------------------
# Shadow Wolf — quadruped
# ----------------------------------------------------------------------------
def wolf_frame(pose):
    img = canvas(128, 128)
    d = ImageDraw.Draw(img)
    col = BODY
    cx = pose.get("cx", 60)
    cy = pose.get("cy", 74)
    stretch = pose.get("stretch", 1.0)
    # tail
    tw = pose.get("tail_wave", 0)
    d.arc([cx - 44, cy - 26 + tw, cx - 4, cy + 18 + tw], 200, 340, fill=col, width=7)
    # body
    d.ellipse([cx - 34 * stretch, cy - 18, cx + 34 * stretch, cy + 16], fill=col)
    d.polygon([(cx - 30 * stretch, cy - 4), (cx + 30 * stretch, cy - 8),
               (cx + 36 * stretch, cy + 10), (cx - 36 * stretch, cy + 12)], fill=col)
    # legs (4)
    legs = pose.get("legs", [(0, 0), (0, 0), (0, 0), (0, 0)])
    xs = (cx - 24 * stretch, cx - 12 * stretch, cx + 12 * stretch, cx + 24 * stretch)
    for (x, (a1, a2)) in zip(xs, legs):
        limb(d, (x, cy + 10), a1, 14, a2, 13, 7, 5, col)
    # head + snout + ears
    hx = pose.get("hx", cx + 34 * stretch)
    hy = pose.get("hy", cy - 10)
    d.ellipse([hx - 12, hy - 11, hx + 12, hy + 11], fill=col)
    d.polygon([(hx + 6, hy - 4), (hx + 26, hy + 2), (hx + 8, hy + 6)], fill=col)  # snout
    for s in (-1, 1):
        d.polygon([(hx + s * 3 - 2, hy - 8), (hx + s * 3 + 3, hy - 20), (hx + s * 3 + 8, hy - 6)], fill=col)
    # eyes
    draw_eyes_glow(img, hx + 6, hy - 3, r=12)
    return img


def gen_wolf():
    frames = []
    # idle 4
    for i in range(4):
        s = math.sin(TAU * i / 4)
        frames.append(wolf_frame(dict(cy=74 + s * 2, tail_wave=s * 4,
                                      legs=[(2, 2), (-2, 2), (2, -2), (-2, -2)])))
    # run 8
    for i in range(8):
        t = i / 8.0
        s = math.sin(TAU * t)
        legs = [(34 * s, -10), (-34 * s, -14), (-30 * s, 12), (30 * s, 8)]
        frames.append(wolf_frame(dict(cy=72 + 2 * abs(s), cx=58, stretch=1.1, tail_wave=s * 6, legs=legs)))
    # attack 4 (crouch -> lunge)
    for i in range(4):
        if i == 0:
            frames.append(wolf_frame(dict(cy=84, stretch=0.85, hx=88, hy=66, tail_wave=2,
                                          legs=[(30, 30), (-20, 20), (-24, 24), (20, -20)])))
        else:
            frames.append(wolf_frame(dict(cy=70 - i * 2, cx=56, stretch=1.25, hx=94, hy=64 - i * 2,
                                          tail_wave=-6, legs=[(-40, -20), (-50, -30), (36, 20), (44, 26)])))
    # hurt 2
    for i in range(2):
        frames.append(wolf_frame(dict(cy=76, cx=64, stretch=0.9, hx=84, hy=68, tail_wave=-8,
                                      legs=[(-16, 6), (-20, 10), (-14, 8), (-18, 12)])))
    # death 6
    for i in range(6):
        t = i / 5.0
        frames.append(wolf_frame(dict(cy=74 + t * 30, cx=60, stretch=1.0 - t * 0.15,
                                      hx=88 - t * 8, hy=66 + t * 22, tail_wave=t * 10,
                                      legs=[(20 + t * 40, 10), (-10 - t * 30, 14 + t * 20),
                                            (-16 - t * 30, 12 + t * 20), (14 + t * 40, 16)])))
    sheet = Image.new("RGBA", (128 * len(frames), 128))
    for i, f in enumerate(frames):
        sheet.alpha_composite(f, (i * 128, 0))
    save(sheet, "enemies", "shadow_wolf_sheet.png")
    return dict(anim="idle|run|attack|hurt|death", counts=[4, 8, 4, 2, 6])


# ----------------------------------------------------------------------------
# BOSS — THE ABYSS LORD (256x256 frames)
# ----------------------------------------------------------------------------
def boss_frame(pose):
    S = 256
    img = canvas(S, S)
    d = ImageDraw.Draw(img)
    col = BODY
    cx = pose.get("cx", 118)
    hip_y = pose.get("hip", 168) + pose.get("bob", 0)
    sho_y = pose.get("sho", 108) + pose.get("bob", 0)
    lean = pose.get("lean", 0)
    sho_x = cx + lean * 0.4
    head_x = sho_x + 6 + lean * 0.3
    head_y = sho_y - 22
    bulk = 2.1
    # massive cape behind
    sway = pose.get("sway", -0.5)
    wave = pose.get("wave", 0)
    d.polygon([(sho_x - 26, sho_y - 12), (sho_x + 12, sho_y - 12),
               (sho_x - 20 + sway * 30 + wave, sho_y + 60),
               (sho_x - 44 + sway * 44 + wave * 2, sho_y + 96),
               (sho_x - 30 + sway * 20, hip_y + 30)], fill=col)
    # legs
    lB = pose.get("legB", (0, 0))
    limb(d, (cx - 10, hip_y), lB[0], 38, lB[1], 36, 18, 14, col)
    lF = pose.get("legF", (0, 0))
    limb(d, (cx + 10, hip_y), lF[0], 40, lF[1], 38, 18, 14, col)
    # back arm
    aB = pose.get("armB", (10, 12))
    limb(d, (sho_x - 14, sho_y + 10), aB[0], 28, aB[1], 26, 14, 11, DARK)
    # torso
    d.polygon([(sho_x - 24, sho_y - 8), (sho_x + 24, sho_y - 8),
               (cx + 16, hip_y + 6), (cx - 16, hip_y + 6)], fill=col)
    # pauldrons
    for s in (-1, 1):
        d.ellipse([sho_x + s * 22 - 16, sho_y - 16, sho_x + s * 22 + 16, sho_y + 8], fill=col)
    # head + crown of horns
    d.ellipse([head_x - 16, head_y - 16, head_x + 16, head_y + 16], fill=col)
    for s, l in ((-1, 30), (1, 30), (0.35, 20)):
        bx = head_x + s * 8
        d.polygon([(bx, head_y - 8), (bx + s * l * 0.7, head_y - 8 - l), (bx + s * 5, head_y + 2)], fill=col)
    # eyes (two, larger)
    for ex_off in (2, 11):
        ex, ey = head_x + ex_off, head_y - 3
        add_glow(img, lambda dd, c, ex=ex, ey=ey: dd.ellipse([ex - 4, ey - 5, ex + 6, ey + 3], fill=c),
                 REDHOT, 6, 1.0)
    d2 = ImageDraw.Draw(img)
    for ex_off in (2, 11):
        ex, ey = head_x + ex_off, head_y - 3
        d2.ellipse([ex - 3, ey - 4, ex + 5, ey + 2], fill=PAL["red"] + (255,))
    # chest rune
    rx, ry = sho_x, sho_y + 22
    add_glow(img, lambda dd, c: dd.polygon([(rx, ry - 10), (rx + 7, ry), (rx, ry + 10), (rx - 7, ry)], fill=c),
             PAL["red"] + (255,), 8, pose.get("rune", 0.7))
    d2 = ImageDraw.Draw(img)
    d2.polygon([(rx, ry - 7), (rx + 5, ry), (rx, ry + 7), (rx - 5, ry)], fill=PAL["red_dark"] + (230,))
    # giant cleaver
    aF = pose.get("armF", (20, 15))
    hand = limb(d, (sho_x + 16, sho_y + 10), aF[0], 28, aF[1], 26, 14, 11, col)
    ka = pose.get("kat_ang", 20)
    a = math.radians(ka)
    hx, hy = hand
    ln = pose.get("cleaver", 96)
    tipx, tipy = hx + math.cos(a) * ln, hy + math.sin(a) * ln
    d.line([hx - math.cos(a) * 24, hy - math.sin(a) * 24, hx + math.cos(a) * 12, hy + math.sin(a) * 12],
           fill=DARK, width=12)
    d.polygon([(hx + math.cos(a) * 10 - math.sin(a) * 8, hy + math.sin(a) * 10 + math.cos(a) * 8),
               (tipx - math.sin(a) * 10, tipy + math.cos(a) * 10),
               (tipx - math.cos(a) * 6, tipy - math.sin(a) * 6),
               (hx + math.cos(a) * 10 + math.sin(a) * 8, hy + math.sin(a) * 10 - math.cos(a) * 8)],
              fill=BLADE)
    d2 = ImageDraw.Draw(img)
    d2.line([hx + math.cos(a) * 12 - math.sin(a) * 8, hy + math.sin(a) * 12 + math.cos(a) * 8,
             tipx - math.sin(a) * 9, tipy + math.cos(a) * 9], fill=EDGE, width=3)
    # red edge glow on cleaver
    add_glow(img, lambda dd, c: dd.line([hx + math.cos(a) * 14, hy + math.sin(a) * 14,
                                         tipx - math.cos(a) * 4, tipy - math.sin(a) * 4], fill=c, width=4),
             PAL["red"] + (180,), 6, 0.8)
    return img


def gen_boss():
    frames = []
    # idle 6
    for i in range(6):
        s = math.sin(TAU * i / 6)
        frames.append(boss_frame(dict(bob=s * 4, legF=(8, -8), legB=(-8, 10),
                                      armF=(26, 18), armB=(12, 14), kat_ang=30 + 6 * s,
                                      sway=-0.4 + s * 0.1, rune=0.6 + 0.3 * s, wave=s)))
    # walk 6
    for i in range(6):
        t = i / 6.0
        s = math.sin(TAU * t)
        frames.append(boss_frame(dict(bob=-2 + 3 * abs(s), lean=10,
                                      legF=(34 * s - 6, 24 + 16 * math.cos(TAU * t)),
                                      legB=(34 * s + 174, -24 - 16 * math.cos(TAU * t)),
                                      armF=(20 - 10 * s, 20), armB=(12 * s, 16),
                                      kat_ang=34, sway=-0.6, wave=s)))
    # slam 6 (cleaver overhead -> ground)
    for i, ka in enumerate((140, 170, 60, 0, 30, 40)):
        frames.append(boss_frame(dict(lean=8 + i * 6 - (16 if i == 3 else 0),
                                      legF=(20 - i * 4, -12 + i * 6), legB=(-14, 12),
                                      armF=(30 - i * 14, 8 + i * 8), armB=(16, 14),
                                      kat_ang=ka, cleaver=96 + (i == 2) * 8, sway=-0.5 + i * 0.15, wave=i)))
    # charge 6 (leaning run)
    for i in range(6):
        t = i / 6.0
        s = math.sin(TAU * t)
        frames.append(boss_frame(dict(bob=-2 + 3 * abs(s), lean=26, sho=104,
                                      legF=(40 * s - 8, 20 + 16 * math.cos(TAU * t)),
                                      legB=(40 * s + 172, -20 - 16 * math.cos(TAU * t)),
                                      armF=(46, 6), armB=(40, 8), kat_ang=10,
                                      sway=-0.9, wave=s, rune=0.9)))
    # cast 6 (raise cleaver, runes flare)
    for i in range(6):
        s = i / 5.0
        frames.append(boss_frame(dict(bob=-4 * s, lean=-6 + s * 8,
                                      legF=(14, -14), legB=(-12, 12),
                                      armF=(-60 + s * 30, 4 + s * 10), armB=(-40 + s * 20, 10),
                                      kat_ang=170 - s * 60, cleaver=96, sway=0.2,
                                      rune=0.5 + s * 0.5, wave=s * 3)))
    # hurt 2
    for i in range(2):
        frames.append(boss_frame(dict(lean=-16, legF=(-6, -14), legB=(-18, 8),
                                      armF=(-30, -20), armB=(-24, -16), kat_ang=60,
                                      sway=0.6, wave=-2, rune=0.4)))
    # death 8
    for i in range(8):
        t = i / 7.0
        frames.append(boss_frame(dict(hip=168 + t * 60, sho=108 + t * 44, lean=-10 + t * 34,
                                      legF=(30 + t * 40, -50 + t * 46), legB=(-12 - t * 24, 22 + t * 34),
                                      armF=(-20 - t * 50, 14 + t * 40), armB=(-14 - t * 40, 12 + t * 34),
                                      kat_ang=50 + t * 30, cleaver=(96 - int(t * 20)) if i < 6 else 40,
                                      sway=0.2, wave=t * 4, rune=max(0.0, 0.6 - t), kat=(i < 7))))
    counts = [6, 6, 6, 6, 6, 2, 8]
    names = ["idle", "walk", "slam", "charge", "cast", "hurt", "death"]
    sheet = Image.new("RGBA", (256 * len(frames), 256))
    for i, f in enumerate(frames):
        sheet.alpha_composite(f, (i * 256, 0))
    save(sheet, "bosses", "abyss_lord_sheet.png")
    meta = {nm: {"start": sum(counts[:k]), "count": c} for k, (nm, c) in enumerate(zip(names, counts))}
    return meta


if __name__ == "__main__":
    m1 = ninja_sheet()
    m2 = gen_enemies()
    m3 = gen_wolf()
    m4 = gen_boss()
    print("ninja meta:", m1)
    print("enemy metas:", m2, m3)
    print("boss meta:", m4)
