# SHADOW LEGENDS — Visual refresh v4

- World 1 background refreshed with a misty teal forest, dark tree silhouettes,
  hanging vines and crimson thorn accents inspired by the two supplied references.
- Corrected the World 1 background lookup to use the asset key (`w1`) instead of
  the display theme name (`forest`). The shipped background file is `sky_w1.png`.
- Ninja sprite enlarged slightly and repositioned for clearer visibility.
- Ninja scarf changed to crimson while retaining the animated sprite sheet.
- Level platform art and collision geometry remain in place.

This is a source-package update. A new Android export and on-device visual test
are still required before the APK can be called verified.
